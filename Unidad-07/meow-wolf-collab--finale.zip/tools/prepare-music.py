#!/usr/bin/env python3
"""Turns the two original tracks into the loop-ready files in client/public/audio.
Needs: ffmpeg (with libmp3lame), numpy.   Usage: python3 tools/prepare-music.py <Browser_History.mp3> <backroom_labyrinth.mp3>

For each track: cut on the beat, drop leading silence and the fade-out ending, bake a 0.25 s equal-power crossfade at the
loop point (the end blends into the audio that precedes the loop start), match loudness to -17 LUFS, encode 128 kbps MP3.
The loop points printed at the end go into client/src/game/musicTracks.ts.
"""
import subprocess, sys, wave, os, tempfile
import numpy as np
SR = 44100
def dec(path):
    raw = subprocess.run(['ffmpeg','-v','error','-i',path,'-f','s16le','-ac','2','-ar',str(SR),'-'],capture_output=True,check=True).stdout
    return np.frombuffer(raw,dtype=np.int16).reshape(-1,2).astype(np.float64)/32768
def wav(path,a):
    w=wave.open(path,'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((np.clip(a,-1,1)*32767).astype(np.int16).tobytes()); w.close()
def bake(src,out_mp3,trim_start,loop_start,loop_len,c=0.25,pad=0.15):
    x=dec(src)[int(round(trim_start*SR)):]
    ls=loop_start-trim_start; le=ls+loop_len
    S,E,C=int(round(ls*SR)),int(round(le*SR)),int(round(c*SR))
    out=x[:E+int(pad*SR)].copy(); t=np.linspace(0,np.pi/2,C)
    out[E-C:E]=x[E-C:E]*np.cos(t)[:,None]+x[S-C:S]*np.sin(t)[:,None]
    out[E:]=x[S:S+len(out)-E]
    tmp=tempfile.mkdtemp(); raw=os.path.join(tmp,'r.wav'); wav(raw,out[S:E])
    r=subprocess.run(['ffmpeg','-nostats','-hide_banner','-i',raw,'-af','ebur128','-f','null','-'],capture_output=True,text=True).stderr
    lufs=float([l for l in r.splitlines() if 'I:' in l and 'LUFS' in l][-1].split('I:')[1].split('LUFS')[0])
    out*=min(10**((-17-lufs)/20),0.98/np.abs(out).max())
    full=os.path.join(tmp,'f.wav'); wav(full,out)
    subprocess.run(['ffmpeg','-v','error','-y','-i',full,'-c:a','libmp3lame','-b:a','128k','-joint_stereo','1',out_mp3],check=True)
    print(os.path.basename(out_mp3),'loopStart',round(ls,6),'loopEnd',round(le,6))
if __name__=='__main__':
    bh,bl=sys.argv[1],sys.argv[2]; here=os.path.join(os.path.dirname(__file__),'..','client','public','audio'); os.makedirs(here,exist_ok=True)
    bar105=4*60/105; bar180=4*60/180
    # Browser History: 105 BPM, beat grid starts ~0.009 s; 4-bar intro, then a 52-bar loop
    bake(bh,os.path.join(here,'browser-history.mp3'),0.009,0.009+4*bar105,52*bar105)
    # Backroom Labyrinth: 180 BPM, grid starts 0.245 s; trim the 2.2 s of silence; loop 72 bars from the plateau (~40 s)
    bake(bl,os.path.join(here,'backroom-labyrinth.mp3'),2.245,0.245+30*bar180,72*bar180)
