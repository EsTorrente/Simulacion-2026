"""Dev tool: search seeds for a 15x15 braided maze (many loops, a few dead ends) and print grid + placements.
Output is pasted into shared/maze.ts. Usage: python3 tools/gen-maze.py"""
import random, collections
N=7; G=2*N+1
def build(seed):
    random.seed(seed)
    g=[[1]*G for _ in range(G)]
    def carve(cx,cy):
        g[2*cy+1][2*cx+1]=0
        dirs=[(1,0),(-1,0),(0,1),(0,-1)]; random.shuffle(dirs)
        for dx,dy in dirs:
            nx,ny=cx+dx,cy+dy
            if 0<=nx<N and 0<=ny<N and g[2*ny+1][2*nx+1]==1:
                g[2*cy+1+dy][2*cx+1+dx]=0; carve(nx,ny)
    carve(0,0)
    def nb(x,y): return [(x+dx,y+dy) for dx,dy in((1,0),(-1,0),(0,1),(0,-1)) if g[y+dy][x+dx]==0]
    for y in range(1,G-1):
        for x in range(1,G-1):
            if g[y][x]==0 and len(nb(x,y))==1 and random.random()<0.5:
                c=[(dx,dy) for dx,dy in((1,0),(-1,0),(0,1),(0,-1)) if 1<=x+2*dx<G-1 and 1<=y+2*dy<G-1 and g[y+dy][x+dx]==1 and g[y+2*dy][x+2*dx]==0]
                if c: dx,dy=random.choice(c); g[y+dy][x+dx]=0
    return g,nb
def stats(g,nb):
    opens=[(x,y) for y in range(G) for x in range(G) if g[y][x]==0]
    edges=sum(len(nb(*p)) for p in opens)//2
    dead=[p for p in opens if len(nb(*p))==1]
    return opens,len(dead),edges-len(opens)+1,dead
best=None
for seed in range(1,4000):
    g,nb=build(seed); opens,nd,cyc,dead=stats(g,nb)
    if 4<=nd<=9 and cyc>=1 and (best is None or cyc>best[0]): best=(cyc,seed)
cyc,seed=best; g,nb=build(seed); opens,nd,cyc,dead=stats(g,nb)
def bfs(s):
    d={s:0}; q=collections.deque([s])
    while q:
        c=q.popleft()
        for n in nb(*c):
            if n not in d: d[n]=d[c]+1; q.append(n)
    return d
D=bfs((1,1)); assert len(D)==len(opens)
print('seed',seed,'open',len(opens),'dead ends',nd,'loops',cyc)
for r in g: print('  ['+','.join(map(str,r))+'],')
# 6 pickups: far from start and from each other; dead ends preferred
cands=sorted(opens,key=lambda p:-(D[p]+(8 if p in dead else 0)))
pick=[]
for p in cands:
    if D[p]>=10 and all(abs(p[0]-q[0])+abs(p[1]-q[1])>=5 for q in pick): pick.append(p)
    if len(pick)==6: break
print('pickups',pick,'dead?',[p in dead for p in pick])
# enemy homes: junction cells roughly mid-distance from start, apart from pickups and each other
mid=[p for p in opens if 12<=D[p]<=30 and len(nb(*p))>=3 and p not in pick]
en=[]
for p in sorted(mid,key=lambda p:-D[p]):
    if all(abs(p[0]-q[0])+abs(p[1]-q[1])>=5 for q in en): en.append(p)
    if len(en)==4: break
print('enemy homes',en,[D[p] for p in en])
