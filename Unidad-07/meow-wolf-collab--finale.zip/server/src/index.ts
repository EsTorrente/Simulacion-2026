import express, { Request, Response } from 'express';
import { createServer } from 'http';
import { randomUUID } from 'crypto';
import { Server, Socket } from 'socket.io';
import { GameSession } from '../../shared/rules.js';
import { ENEMY_STEP_MS, WOLF_STEP_MS } from '../../shared/maze.js';
import type { ActionResult, PlayerRole } from '../../shared/types.js';

const PORT = Number(process.env.PORT ?? 4000);
const GRACE_MS = 30_000;       // how long a dropped player's seat is held
const MOVE_COOLDOWN_MS = WOLF_STEP_MS - 20; // paces the Wolf (a little slack for network jitter); also stops message floods

const app = express();
const httpServer = createServer(app);

// Only allow browsers that were loaded from localhost or a private Wi-Fi/LAN address.
const PRIVATE_HOST = /^(localhost|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|[\w-]+\.local)$/;
const io = new Server(httpServer, {
  maxHttpBufferSize: 200_000, // ~200 KB: rejects absurdly large messages
  cors: {
    origin: (origin, cb) => {
      if (!origin) return cb(null, true);
      try { cb(null, PRIVATE_HOST.test(new URL(origin).hostname)); } catch { cb(null, false); }
    },
    methods: ['GET', 'POST'],
  },
});

const session = new GameSession(randomUUID); // one in-memory session; a restart resets it

interface Seat { socketId: string | null; graceTimer: NodeJS.Timeout | null; }
const seats: Record<PlayerRole, Seat> = {
  Cat: { socketId: null, graceTimer: null },
  Wolf: { socketId: null, graceTimer: null },
};
const roleOf = new Map<string, PlayerRole>(); // socket.id -> role
const lastMove = new Map<string, number>();

app.get('/health', (_req: Request, res: Response) => {
  res.send({ status: 'ok', milestone: 2 });
});

/** Send the world to everyone. Strokes are heavy, so only include them when they changed. */
function broadcast(includeLetters: boolean) {
  const state = session.getState() as unknown as Record<string, unknown>;
  if (!includeLetters) { delete state.letters; delete state.stickers; }
  io.emit('state', state);
}

function bind(socket: Socket, role: PlayerRole) {
  const seat = seats[role];
  if (seat.graceTimer) { clearTimeout(seat.graceTimer); seat.graceTimer = null; }
  if (seat.socketId && seat.socketId !== socket.id) {
    // Same player opened a second tab/connection: the newer one wins.
    const old = io.sockets.sockets.get(seat.socketId);
    roleOf.delete(seat.socketId);
    old?.emit('notice', { kind: 'error', message: 'This seat was taken over by another tab.' });
    old?.emit('seat:lost');
  }
  seat.socketId = socket.id;
  roleOf.set(socket.id, role);
}

function freeSeat(role: PlayerRole) {
  const seat = seats[role];
  if (seat.graceTimer) clearTimeout(seat.graceTimer);
  if (seat.socketId) roleOf.delete(seat.socketId);
  seat.socketId = null; seat.graceTimer = null;
  session.release(role);
}

type Ack = (r: unknown) => void;
const reply = (ack: unknown, r: unknown) => { if (typeof ack === 'function') (ack as Ack)(r); };

io.on('connection', (socket: Socket) => {
  // Wrap every handler so one bad message can never crash the server.
  const on = (event: string, fn: (payload: any, role: PlayerRole | undefined) => ActionResult<any> | void, includeLetters = false) => {
    socket.on(event, (payload: unknown, ack?: unknown) => {
      try {
        const result = fn(payload, roleOf.get(socket.id)) ?? { ok: true };
        reply(ack, result);
        if ((result as { ok: boolean }).ok) broadcast(includeLetters);
      } catch (err) {
        console.error(`Handler error in ${event}:`, err);
        reply(ack, { ok: false, error: 'Server error.' });
      }
    });
  };

  socket.emit('state', session.getState());

  on('lobby:join', (p) => {
    if (roleOf.has(socket.id)) return { ok: false, error: 'You already have a seat.' };
    const r = session.join(p?.role);
    if (r.ok) { bind(socket, r.role); }
    return r;
  });

  on('lobby:rejoin', (p) => {
    const r = session.rejoin(p?.token);
    if (r.ok) bind(socket, r.role);
    return r.ok ? { ok: true, role: r.role } : r;
  }, true);

  on('lobby:leave', (_p, role) => {
    if (!role) return { ok: false, error: 'You have no seat.' };
    freeSeat(role);
  }, true);

  // Resync just this client with the full authoritative state
  socket.on('state:request', () => { socket.emit('state', session.getState()); });

  on('cat:stroke', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.addStroke(role, p?.letterId, p?.stroke);
  }, true);

  on('cat:clear', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.clearLetter(role, p?.letterId);
  }, true);

  on('cat:undo', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.undo(role, p?.letterId);
  }, true);

  on('cat:redo', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.redo(role, p?.letterId);
  }, true);

  on('cat:sticker:add', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.addSticker(role, p?.letterId, p?.sticker);
  }, true);

  on('cat:sticker:update', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.updateSticker(role, p?.letterId, p?.id, p?.placement);
  }, true);

  on('cat:sticker:remove', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    return session.removeSticker(role, p?.letterId, p?.id);
  }, true);

  on('wolf:move', (p, role) => {
    if (!role) return { ok: false, error: 'Join a seat first.' };
    const now = Date.now();
    if (now - (lastMove.get(socket.id) ?? 0) < MOVE_COOLDOWN_MS) return { ok: false, error: 'Too fast.' };
    lastMove.set(socket.id, now);
    return session.moveWolf(role, p?.dx, p?.dy);
  });

  on('finalize:confirm', (_p, role) => role ? session.confirm(role) : { ok: false, error: 'Join a seat first.' });
  on('finalize:cancel', (_p, role) => role ? session.cancelConfirm(role) : { ok: false, error: 'Join a seat first.' });

  on('finale:replay', (_p, role) => role ? session.replayFinale(role) : { ok: false, error: 'Join a seat first.' });
  on('finale:reopen', (_p, role) => role ? session.reopenStudio(role) : { ok: false, error: 'Join a seat first.' });

  socket.on('disconnect', () => {
    lastMove.delete(socket.id);
    const role = roleOf.get(socket.id);
    if (!role || seats[role].socketId !== socket.id) return;
    // Keep the seat and the artwork for a while so the player can come back.
    session.setConnected(role, false);
    seats[role].graceTimer = setTimeout(() => {
      console.log(`${role} did not return; seat released.`);
      freeSeat(role);
      broadcast(true);
    }, GRACE_MS);
    roleOf.delete(socket.id);
    broadcast(false);
  });
});

// Enemies move on the server's clock only, so both screens always see the same chase.
setInterval(() => { try { if (session.tick()) broadcast(false); } catch (e) { console.error('tick error', e); } }, ENEMY_STEP_MS);

// Defensive: keep the process alive even on unexpected errors.
process.on('uncaughtException', e => console.error('uncaughtException', e));

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Socket.IO server on port ${PORT} (all network interfaces)`);
});
