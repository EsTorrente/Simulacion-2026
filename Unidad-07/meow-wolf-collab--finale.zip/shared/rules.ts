// The authoritative game rules. Pure TypeScript: no Socket.IO, no React.
import { ENEMY_DEFS, INITIAL_COLLECTIBLES, INVULN_TICKS, MAX_LIVES, MAZE_GRID, START_COLOR, START_POS, STUN_TICKS } from './maze.js';
import { distanceMap, stepEnemy } from './enemies.js';
import {
  LETTER_IDS, type ActionResult, type Collectible, type Enemy, type GameState, type LetterID,
  type PlacedSticker, type PlayerRole, type SessionStatus, type Stroke,
} from './types.js';
import { MAX_STICKERS_PER_LETTER, MAX_STROKES_PER_LETTER, isLetterId, isPlayerRole, parseMove, parsePlacement, parseStroke } from './validation.js';

type Fail = { ok: false; error: string };
const fail = (error: string): Fail => ({ ok: false, error });
const emptyLetters = () =>
  Object.fromEntries(LETTER_IDS.map(id => [id, [] as Stroke[]])) as Record<LetterID, Stroke[]>;

const emptyStickers = () =>
  Object.fromEntries(LETTER_IDS.map(id => [id, [] as PlacedSticker[]])) as Record<LetterID, PlacedSticker[]>;

/** One undoable drawing edit on a letter: a stroke that was added, or a whole drawing that was cleared. */
type DrawOp = { k: 'add'; stroke: Stroke } | { k: 'clear'; prev: Stroke[] };
export const MAX_HISTORY = 100;
const emptyHistory = () =>
  Object.fromEntries(LETTER_IDS.map(id => [id, [] as DrawOp[]])) as Record<LetterID, DrawOp[]>;

export class GameSession {
  // Secrets stay in here; getState() never exposes them.
  private tokens: Record<PlayerRole, string | null> = { Cat: null, Wolf: null };
  private connected: Record<PlayerRole, boolean> = { Cat: false, Wolf: false };
  private finalized = false;
  private finalSeed = 0;
  private version = 0;

  private letters = emptyLetters();
  private stickers = emptyStickers();
  private undoStack = emptyHistory();
  private redoStack = emptyHistory();
  private nextStickerId = 1;
  private wolfPos = { ...START_POS };
  private collectibles: Collectible[] = INITIAL_COLLECTIBLES.map(c => ({ ...c, pos: { ...c.pos } }));
  private enemies: Enemy[] = this.freshEnemies();
  private lives = MAX_LIVES;
  private invuln = 0;          // ticks of safety left
  private stun = 0;            // ticks the Wolf is frozen (after losing the last life)
  private catches = 0;
  private ticks = 0;
  private started = false;     // enemies stay put until the Wolf first moves (after join / after every catch)
  private facing = { x: 1, y: 0 };
  private wolfFrom: { x: number; y: number } | null = null; // where the Wolf stood before its last step (to catch "swapping places")
  private unlockedColors = [START_COLOR];
  private unlockedStickers: string[] = [];
  private confirmed: Record<PlayerRole, boolean> = { Cat: false, Wolf: false };

  constructor(
    private makeToken: () => string = () => Math.random().toString(36).slice(2) + Date.now().toString(36),
    private makeSeed: () => number = () => 1 + Math.floor(Math.random() * 0xfffffffe),
    private rng: () => number = Math.random,
  ) {}

  private freshEnemies(): Enemy[] {
    return ENEMY_DEFS.map(d => ({ id: d.id, kind: d.kind, pos: { ...d.home }, dir: { x: 0, y: 1 }, alert: false }));
  }

  // ---------- seats ----------
  join(role: unknown): ActionResult<{ role: PlayerRole; token: string }> {
    if (!isPlayerRole(role)) return fail('Unknown role.');
    if (this.tokens[role]) return fail(`The ${role} seat is already taken.`);
    const token = this.makeToken();
    this.tokens[role] = token;
    this.connected[role] = true;
    this.version++;
    return { ok: true, role, token };
  }

  /** A returning browser proves who it is with its private token. */
  rejoin(token: unknown): ActionResult<{ role: PlayerRole }> {
    if (typeof token !== 'string' || !token) return fail('Missing session token.');
    const role = this.roleForToken(token);
    if (!role) return fail('That seat is no longer reserved for you.');
    this.connected[role] = true;
    this.version++;
    return { ok: true, role };
  }

  roleForToken(token: unknown): PlayerRole | null {
    if (typeof token !== 'string') return null;
    return (['Cat', 'Wolf'] as const).find(r => this.tokens[r] === token) ?? null;
  }

  setConnected(role: PlayerRole, value: boolean) {
    if (this.tokens[role] && this.connected[role] !== value) { this.connected[role] = value; this.version++; }
  }

  /** Frees a seat (explicit leave, or grace period ran out). */
  release(role: PlayerRole) {
    this.tokens[role] = null;
    this.connected[role] = false;
    this.confirmed = { Cat: false, Wolf: false };
    this.finalized = false;
    this.finalSeed = 0;
    this.version++;
  }

  private bothSeated() { return !!this.tokens.Cat && !!this.tokens.Wolf; }
  private status(): SessionStatus {
    if (!this.bothSeated()) return 'lobby';
    return this.finalized ? 'finalizing' : 'playing';
  }
  private requirePlaying(role: PlayerRole): Fail | null {
    if (!this.bothSeated()) return fail('Waiting for both players to join.');
    if (this.finalized) return fail('The artwork is already finalized.');
    if (!this.connected[role]) return fail('Not connected.');
    return null;
  }
  private artworkChanged() { this.confirmed = { Cat: false, Wolf: false }; this.version++; }

  // ---------- Cat ----------
  addStroke(role: PlayerRole, letterId: unknown, rawStroke: unknown): ActionResult {
    if (role !== 'Cat') return fail('Only the Cat can draw.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    if (this.letters[letterId].length >= MAX_STROKES_PER_LETTER) return fail('This letter is full.');
    const stroke = parseStroke(rawStroke, this.unlockedColors);
    if (typeof stroke === 'string') return fail(stroke);
    this.letters[letterId].push(stroke);
    this.record(letterId, { k: 'add', stroke });
    this.artworkChanged();
    return { ok: true };
  }

  /** New edits become undoable and make the redo list obsolete. */
  private record(letterId: LetterID, op: DrawOp) {
    const u = this.undoStack[letterId]; u.push(op);
    if (u.length > MAX_HISTORY) u.shift();
    this.redoStack[letterId] = [];
  }

  /** Undo the Cat's last drawing edit on this letter (a stroke, or a Clear). Stickers are not part of it. */
  undo(role: PlayerRole, letterId: unknown): ActionResult {
    if (role !== 'Cat') return fail('Only the Cat can undo.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    const op = this.undoStack[letterId].pop();
    if (!op) return fail('Nothing to undo.');
    if (op.k === 'add') this.letters[letterId] = this.letters[letterId].slice(0, -1);
    else this.letters[letterId] = op.prev.map(s => ({ ...s, points: s.points.map(p => ({ ...p })) }));
    this.redoStack[letterId].push(op);
    this.artworkChanged();
    return { ok: true };
  }

  redo(role: PlayerRole, letterId: unknown): ActionResult {
    if (role !== 'Cat') return fail('Only the Cat can redo.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    const op = this.redoStack[letterId].pop();
    if (!op) return fail('Nothing to redo.');
    if (op.k === 'add') this.letters[letterId].push(op.stroke); else this.letters[letterId] = [];
    this.undoStack[letterId].push(op);
    this.artworkChanged();
    return { ok: true };
  }

  clearLetter(role: PlayerRole, letterId: unknown): ActionResult {
    if (role !== 'Cat') return fail('Only the Cat can clear letters.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    if (this.letters[letterId].length === 0) return { ok: true };
    this.record(letterId, { k: 'clear', prev: this.letters[letterId] });
    this.letters[letterId] = [];
    this.artworkChanged();
    return { ok: true };
  }

  // Stickers: the server checks ownership (unlocked), role, letter and bounds.
  addSticker(role: PlayerRole, letterId: unknown, raw: unknown): ActionResult<{ id: string }> {
    if (role !== 'Cat') return fail('Only the Cat can place stickers.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    const kind = (raw as { kind?: unknown } | null)?.kind;
    if (typeof kind !== 'string' || !this.unlockedStickers.includes(kind)) return fail('That sticker is not unlocked.');
    if (this.stickers[letterId].length >= MAX_STICKERS_PER_LETTER) return fail('This letter has too many stickers.');
    const placement = parsePlacement(raw);
    if (typeof placement === 'string') return fail(placement);
    const id = `st${this.nextStickerId++}`;
    this.stickers[letterId].push({ id, kind, ...placement });
    this.artworkChanged();
    return { ok: true, id };
  }

  updateSticker(role: PlayerRole, letterId: unknown, id: unknown, raw: unknown): ActionResult {
    if (role !== 'Cat') return fail('Only the Cat can move stickers.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    const sticker = this.stickers[letterId].find(s => s.id === id);
    if (!sticker) return fail('Sticker not found.');
    const placement = parsePlacement(raw);
    if (typeof placement === 'string') return fail(placement);
    Object.assign(sticker, placement);
    this.artworkChanged();
    return { ok: true };
  }

  removeSticker(role: PlayerRole, letterId: unknown, id: unknown): ActionResult {
    if (role !== 'Cat') return fail('Only the Cat can remove stickers.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    if (!isLetterId(letterId)) return fail('Unknown letter.');
    const before = this.stickers[letterId].length;
    this.stickers[letterId] = this.stickers[letterId].filter(s => s.id !== id);
    if (this.stickers[letterId].length === before) return fail('Sticker not found.');
    this.artworkChanged();
    return { ok: true };
  }

  // ---------- Wolf ----------
  moveWolf(role: PlayerRole, dx: unknown, dy: unknown): ActionResult<{ collected?: Collectible; caught?: boolean }> {
    if (role !== 'Wolf') return fail('Only the Wolf can move.');
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    const step = parseMove(dx, dy);
    if (typeof step === 'string') return fail(step);
    if (this.stun > 0) return fail('Stunned.');

    const nx = this.wolfPos.x + step.dx, ny = this.wolfPos.y + step.dy;
    if (MAZE_GRID[ny]?.[nx] !== 0) return fail('Wall.');
    this.wolfFrom = { ...this.wolfPos };
    this.wolfPos = { x: nx, y: ny };
    this.facing = { x: step.dx, y: step.dy };
    this.started = true;

    const item = this.collectibles.find(c => !c.collected && c.pos.x === nx && c.pos.y === ny);
    if (item) {
      item.collected = true;
      if (item.type === 'color' && !this.unlockedColors.includes(item.value)) this.unlockedColors.push(item.value);
      if (item.type === 'sticker' && !this.unlockedStickers.includes(item.value)) this.unlockedStickers.push(item.value);
    }
    const caught = this.enemies.some(e => e.pos.x === nx && e.pos.y === ny) && this.invuln === 0 && this.stun === 0;
    if (caught) this.catchWolf();
    this.version++;
    return { ok: true, ...(item ? { collected: { ...item, pos: { ...item.pos } } } : {}), ...(caught ? { caught: true } : {}) };
  }

  /** Lose a life, go back to the start, enemies go home. Out of lives: frozen for a few seconds, then refilled. Items already found are kept. */
  private catchWolf() {
    this.catches++;
    this.lives = Math.max(0, this.lives - 1);
    this.wolfPos = { ...START_POS }; this.wolfFrom = null;
    this.enemies = this.freshEnemies();
    this.started = false;
    if (this.lives === 0) this.stun = STUN_TICKS; else this.invuln = INVULN_TICKS;
  }

  /** Advance the enemies one step. The server (and the offline adapter) call this on a fixed timer. Returns true if anything changed. */
  tick(): boolean {
    if (this.status() !== 'playing' || !this.connected.Wolf) return false;
    let changed = false;
    if (this.stun > 0) { this.stun--; if (this.stun === 0) { this.lives = MAX_LIVES; this.invuln = INVULN_TICKS; } changed = true; }
    else if (this.invuln > 0) { this.invuln--; changed = true; }
    if (this.stun > 0 || !this.started) { if (changed) this.version++; return changed; }

    this.ticks++;
    const wolfMap = distanceMap(this.wolfPos);
    const before = this.enemies.map(e => ({ ...e.pos }));
    this.enemies = this.enemies.map(e => (e.kind === 'stalker' && this.ticks % 3 === 0) ? e : stepEnemy(e, { // the cunning Stalker is slow: it rests every third step
      wolf: this.wolfPos, facing: this.facing, wolfMap, rng: this.rng,
      home: ENEMY_DEFS.find(d => d.id === e.id)!.home,
    }));
    if (this.invuln === 0) {
      const hit = this.enemies.some((e, i) =>
        (e.pos.x === this.wolfPos.x && e.pos.y === this.wolfPos.y) ||
        // the Wolf stepped onto the cell the enemy left while the enemy stepped onto the Wolf's old cell
        (this.wolfFrom && e.pos.x === this.wolfFrom.x && e.pos.y === this.wolfFrom.y && before[i].x === this.wolfPos.x && before[i].y === this.wolfPos.y));
      if (hit) this.catchWolf();
    }
    this.wolfFrom = null;
    this.version++;
    return true;
  }

  // ---------- finishing ----------
  confirm(role: PlayerRole): ActionResult {
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    this.confirmed[role] = true;
    if (this.confirmed.Cat && this.confirmed.Wolf) { this.finalized = true; this.finalSeed = this.makeSeed(); }
    this.version++;
    return { ok: true };
  }

  cancelConfirm(role: PlayerRole): ActionResult {
    const blocked = this.requirePlaying(role); if (blocked) return blocked;
    this.confirmed[role] = false;
    this.version++;
    return { ok: true };
  }

  // ---------- after the finale begins ----------
  private requireFinale(role: PlayerRole): Fail | null {
    if (!this.bothSeated() || !this.finalized) return fail('The finale has not started.');
    if (!this.connected[role]) return fail('Not connected.');
    return null;
  }

  /** Grow a brand-new world from the same artwork. */
  replayFinale(role: PlayerRole): ActionResult {
    const blocked = this.requireFinale(role); if (blocked) return blocked;
    this.finalSeed = this.makeSeed();
    this.version++;
    return { ok: true };
  }

  /** Go back to the studio; the artwork is kept, confirmations start over. */
  reopenStudio(role: PlayerRole): ActionResult {
    const blocked = this.requireFinale(role); if (blocked) return blocked;
    this.finalized = false; this.finalSeed = 0;
    this.confirmed = { Cat: false, Wolf: false };
    this.version++;
    return { ok: true };
  }

  // ---------- read ----------
  getState(): GameState {
    return JSON.parse(JSON.stringify({
      status: this.status(),
      players: {
        Cat: { occupied: !!this.tokens.Cat, connected: this.connected.Cat },
        Wolf: { occupied: !!this.tokens.Wolf, connected: this.connected.Wolf },
      },
      version: this.version,
      seed: this.finalSeed,
      letters: this.letters,
      stickers: this.stickers,
      wolfPos: this.wolfPos,
      collectibles: this.collectibles,
      enemies: this.enemies,
      lives: this.lives,
      maxLives: MAX_LIVES,
      wolfCondition: this.stun > 0 ? 'stunned' : this.invuln > 0 ? 'invulnerable' : 'ok',
      catches: this.catches,
      history: Object.fromEntries(LETTER_IDS.map(id => [id, { undo: this.undoStack[id].length, redo: this.redoStack[id].length }])),
      unlockedColors: this.unlockedColors,
      unlockedStickers: this.unlockedStickers,
      catConfirmed: this.confirmed.Cat,
      wolfConfirmed: this.confirmed.Wolf,
    }));
  }
}
