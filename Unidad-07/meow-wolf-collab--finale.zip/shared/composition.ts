// Layout of the whole MEOW WOLF composition. Each letter keeps its own 800x800 square cell (data model unchanged),
// but the cell is centred on that letter's REAL position in the official logo (see logo.ts), so spacing matches.
// COL/ROW below are only the letter's reading order.
//   M E O W
//   W O L F
// Each cell is an 800x800 letter space (strokes) with stickers in 0..1 letter coordinates.
import type { LetterID } from './types.js';
import { LOGO, LOGO_VIEW, LOGO_CELL_PX } from './logo.js';

export const COMP_COLS = 4;
export const COMP_ROWS = 2;
export const COMP_ASPECT = COMP_COLS / COMP_ROWS; // width / height = 2
export const LETTER_SPACE = 800;
/** Size of one letter cell as a fraction of the composition (cells are square on screen, and overlap a little). */
export const CELL_W = LOGO_CELL_PX / LOGO_VIEW.w;
export const CELL_H = LOGO_CELL_PX / LOGO_VIEW.h;

export const LETTER_CELL: Record<LetterID, { col: number; row: number }> = {
  M: { col: 0, row: 0 }, E: { col: 1, row: 0 }, O1: { col: 2, row: 0 }, W1: { col: 3, row: 0 },
  W2: { col: 0, row: 1 }, O2: { col: 1, row: 1 }, L: { col: 2, row: 1 }, F: { col: 3, row: 1 },
};

/** Letter-space point (0..800) -> composition coordinates (0..1 in both axes). */
export function letterPointToComp(id: LetterID, x: number, y: number) {
  const { cx, cy } = LOGO[id];
  // Cells overhang the padded logo frame slightly at the edges; clamp so everything stays inside 0..1.
  const clamp01 = (n: number) => Math.min(1, Math.max(0, n));
  return { x: clamp01(cx + ((x - LETTER_SPACE / 2) / LETTER_SPACE) * CELL_W), y: clamp01(cy + ((y - LETTER_SPACE / 2) / LETTER_SPACE) * CELL_H) };
}

/** Composition point (0..1) -> letter space of the given letter (inverse of the above). */
export function compToLetterPoint(id: LetterID, x: number, y: number) {
  const { cx, cy } = LOGO[id];
  return { x: LETTER_SPACE / 2 + ((x - cx) / CELL_W) * LETTER_SPACE, y: LETTER_SPACE / 2 + ((y - cy) / CELL_H) * LETTER_SPACE };
}

/** Which letter does a composition point belong to? Inside a glyph wins; otherwise the nearest glyph box. */
export function nearestLetter(x: number, y: number, inGlyph?: (id: LetterID, lx: number, ly: number) => boolean): LetterID {
  let best: LetterID = 'M', bestD = Infinity;
  for (const id of Object.keys(LOGO) as LetterID[]) {
    const { x: lx, y: ly } = compToLetterPoint(id, x, y);
    if (inGlyph?.(id, lx, ly)) return id;
    const [x0, y0, x1, y1] = LOGO[id].bbox;
    const dx = Math.max(x0 - lx, 0, lx - x1), dy = Math.max(y0 - ly, 0, ly - y1);
    const d = dx * dx + dy * dy + 1e-6 * ((lx - 400) ** 2 + (ly - 400) ** 2);
    if (d < bestD) { bestD = d; best = id; }
  }
  return best;
}

/** Sticker position (0..1 inside its letter) -> composition coordinates. */
export function stickerToComp(id: LetterID, u: number, v: number) {
  return letterPointToComp(id, u * LETTER_SPACE, v * LETTER_SPACE);
}

/** Largest rectangle of the given aspect that fits the viewport (with a margin), centered. */
export function fitRect(vw: number, vh: number, aspect: number, fill = 0.8) {
  const maxW = vw * fill, maxH = vh * fill;
  const w = Math.min(maxW, maxH * aspect);
  const h = w / aspect;
  return { x: (vw - w) / 2, y: (vh - h) / 2, w, h };
}
