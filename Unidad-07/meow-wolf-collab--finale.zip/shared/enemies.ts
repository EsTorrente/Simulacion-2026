// Enemy behaviour. Pure functions on the shared maze: no timers, no randomness except the injected rng.
import { MAZE_GRID } from './maze.js';
import type { Enemy, Position } from './types.js';

const ROWS = MAZE_GRID.length, COLS = MAZE_GRID[0].length;
const DIRS = [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }];
export const isOpen = (x: number, y: number) => MAZE_GRID[y]?.[x] === 0;
const idx = (p: Position) => p.y * COLS + p.x;
export const neighbors = (p: Position): Position[] =>
  DIRS.map(d => ({ x: p.x + d.x, y: p.y + d.y })).filter(q => isOpen(q.x, q.y));

/** Steps from `from` to every open cell (-1 = unreachable). */
export function distanceMap(from: Position): Int16Array {
  const d = new Int16Array(ROWS * COLS).fill(-1);
  const q = [from]; d[idx(from)] = 0;
  for (let i = 0; i < q.length; i++) {
    const c = q[i];
    for (const n of neighbors(c)) if (d[idx(n)] < 0) { d[idx(n)] = d[idx(c)] + 1; q.push(n); }
  }
  return d;
}
export const pathDistance = (map: Int16Array, p: Position) => map[idx(p)];

type Rng = () => number;
const pick = <T,>(a: T[], rng: Rng) => a[Math.floor(rng() * a.length)];
const move = (e: Enemy, to: Position, alert: boolean): Enemy => ({ ...e, pos: to, dir: { x: to.x - e.pos.x, y: to.y - e.pos.y }, alert });

/** Neighbour with the smallest distance in `map`; ties broken at random. */
function descend(e: Enemy, map: Int16Array, rng: Rng, alert: boolean): Enemy {
  const ns = neighbors(e.pos).filter(n => map[idx(n)] >= 0);
  if (!ns.length) return { ...e, alert };
  const best = Math.min(...ns.map(n => map[idx(n)]));
  return move(e, pick(ns.filter(n => map[idx(n)] === best), rng), alert);
}

/** Random walk that never turns back unless it is a dead end. */
function wander(e: Enemy, rng: Rng): Enemy {
  const ns = neighbors(e.pos);
  const ahead = ns.filter(n => !(n.x === e.pos.x - e.dir.x && n.y === e.pos.y - e.dir.y));
  return move(e, pick(ahead.length ? ahead : ns, rng), false);
}

export interface Sense { wolf: Position; facing: Position; wolfMap: Int16Array; home: Position; rng: Rng; }

export const HUNTER_RANGE = 7;    // follows you by the shortest path once you are this close
export const DRIFTER_RANGE = 4;   // usually aimless, but snaps onto you when you get near
export const GUARD_RANGE = 4;     // leaves its post only when you approach it
export const STALKER_RANGE = 9;

export function stepEnemy(e: Enemy, s: Sense): Enemy {
  const d = pathDistance(s.wolfMap, e.pos);
  switch (e.kind) {
    case 'hunter':
      return d >= 0 && d <= HUNTER_RANGE ? descend(e, s.wolfMap, s.rng, true) : wander(e, s.rng);
    case 'drifter':
      return d >= 0 && d <= DRIFTER_RANGE ? descend(e, s.wolfMap, s.rng, true) : wander(e, s.rng);
    case 'stalker': {
      if (d < 0 || d > STALKER_RANGE) return wander(e, s.rng);
      if (d <= 2) return descend(e, s.wolfMap, s.rng, true);
      // Aim for the cell the Wolf is about to run into: up to 3 cells ahead of where it is facing.
      let t = { ...s.wolf };
      for (let i = 0; i < 3; i++) { const n = { x: t.x + s.facing.x, y: t.y + s.facing.y }; if (isOpen(n.x, n.y)) t = n; else break; }
      return descend(e, distanceMap(t), s.rng, true);
    }
    case 'guardian': {
      if (d >= 0 && d <= GUARD_RANGE) return descend(e, s.wolfMap, s.rng, true);
      if (e.pos.x === s.home.x && e.pos.y === s.home.y) return { ...e, alert: false };
      return descend(e, distanceMap(s.home), s.rng, false); // walk back to the post
    }
  }
}
