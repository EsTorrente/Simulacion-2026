// Shared by client AND server. No React, no Socket.IO in here.
export type Role = 'Cat' | 'Wolf' | null;
export type PlayerRole = 'Cat' | 'Wolf';

export type LetterID = 'M' | 'E' | 'O1' | 'W1' | 'W2' | 'O2' | 'L' | 'F';
export const LETTER_IDS: LetterID[] = ['M', 'E', 'O1', 'W1', 'W2', 'O2', 'L', 'F'];

export interface Point { x: number; y: number; }

export interface Stroke {
  points: Point[];
  color: string;
  brushSize: number;
}

export type Position = Point;

export interface Collectible {
  id: string;
  pos: Position;
  type: 'color' | 'sticker';
  value: string;
  collected: boolean;
}

export type EnemyKind = 'hunter' | 'stalker' | 'drifter' | 'guardian';
export interface Enemy { id: string; kind: EnemyKind; pos: Position; dir: Point; /** true while it is actively going after the Wolf */ alert: boolean; }
export type WolfCondition = 'ok' | 'invulnerable' | 'stunned';

/** A sticker placed on a letter. x/y are normalized 0..1 inside the letter box (resize-safe). */
export interface StickerPlacement { x: number; y: number; scale: number; rotation: number; }
export interface PlacedSticker extends StickerPlacement { id: string; kind: string; }

export type SessionStatus = 'lobby' | 'playing' | 'finalizing';

/** What everybody may know about a seat. Never contains the secret token. */
export interface SeatInfo { occupied: boolean; connected: boolean; }

export interface GameState {
  status: SessionStatus;
  players: Record<PlayerRole, SeatInfo>;
  version: number;
  /** 0 until both players confirm; then a server-chosen number that both clients grow the same world from. */
  seed: number;
  letters: Record<LetterID, Stroke[]>;
  stickers: Record<LetterID, PlacedSticker[]>;
  wolfPos: Position;
  collectibles: Collectible[];
  enemies: Enemy[];
  lives: number;
  maxLives: number;
  wolfCondition: WolfCondition;
  /** Total times the Wolf has been caught (clients use the change to flash/play a sound). */
  catches: number;
  /** How many strokes edits can be undone / redone per letter (the Cat's undo history lives on the server). */
  history: Record<LetterID, { undo: number; redo: number }>;
  unlockedColors: string[];
  unlockedStickers: string[];
  catConfirmed: boolean;
  wolfConfirmed: boolean;
}

/** Result of every action: either it worked, or here is why not. */
export type ActionResult<T = object> = ({ ok: true } & T) | { ok: false; error: string };
