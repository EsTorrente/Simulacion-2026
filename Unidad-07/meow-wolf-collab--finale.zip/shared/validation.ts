import { LETTER_IDS, type LetterID, type PlayerRole, type StickerPlacement, type Stroke } from './types.js';

export const CANVAS_SIZE = 800;        // logical drawing coordinates, not screen pixels
export const MAX_POINTS_PER_STROKE = 2000;
export const MAX_STROKES_PER_LETTER = 500;

export const isPlayerRole = (v: unknown): v is PlayerRole => v === 'Cat' || v === 'Wolf';
export const isLetterId = (v: unknown): v is LetterID =>
  typeof v === 'string' && (LETTER_IDS as string[]).includes(v);

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null;
const inCanvas = (n: unknown): n is number =>
  typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= CANVAS_SIZE;

/** Returns a clean Stroke (extra fields stripped) or an error string. */
export function parseStroke(raw: unknown, allowedColors: string[]): Stroke | string {
  if (!isObj(raw)) return 'Stroke must be an object.';
  const { points, color, brushSize } = raw;
  if (!Array.isArray(points) || points.length < 1 || points.length > MAX_POINTS_PER_STROKE)
    return `A stroke needs 1–${MAX_POINTS_PER_STROKE} points.`;
  if (typeof color !== 'string' || !allowedColors.includes(color))
    return 'That color is not unlocked.';
  if (typeof brushSize !== 'number' || !Number.isFinite(brushSize) || brushSize < 1 || brushSize > 50)
    return 'Invalid brush size.';
  const clean = [];
  for (const p of points) {
    if (!isObj(p) || !inCanvas(p.x) || !inCanvas(p.y)) return 'Invalid point in stroke.';
    clean.push({ x: p.x, y: p.y });
  }
  return { points: clean, color, brushSize };
}

/** Returns a unit step or an error string. */
export function parseMove(dx: unknown, dy: unknown): { dx: number; dy: number } | string {
  if (!Number.isInteger(dx) || !Number.isInteger(dy)) return 'Invalid move.';
  const x = dx as number, y = dy as number;
  if (Math.abs(x) + Math.abs(y) !== 1) return 'Move one step at a time.';
  return { dx: x, dy: y };
}

export const MAX_STICKERS_PER_LETTER = 40;

/** Validates a sticker's position (0..1 in the letter box), scale and rotation. */
export function parsePlacement(raw: unknown): StickerPlacement | string {
  if (!isObj(raw)) return 'Invalid sticker placement.';
  const { x, y, scale, rotation } = raw;
  const unit = (n: unknown): n is number => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 1;
  if (!unit(x) || !unit(y)) return 'Sticker must stay inside the letter.';
  if (typeof scale !== 'number' || !Number.isFinite(scale) || scale < 0.3 || scale > 3) return 'Invalid sticker size.';
  if (typeof rotation !== 'number' || !Number.isFinite(rotation) || rotation < -360 || rotation > 360) return 'Invalid sticker rotation.';
  return { x, y, scale, rotation };
}
