// Reads the finished artwork and turns it into numbers that steer the procedural world.
// Pure functions: same artwork -> same profile. No canvas, no React.
import { letterPointToComp, stickerToComp } from './composition.js';
import { LETTER_IDS, type GameState } from './types.js';

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type TraitName = 'growth' | 'fire' | 'electric' | 'watching' | 'flow';
export type Traits = Record<TraitName, number>;
export const TRAIT_NAMES: TraitName[] = ['growth', 'fire', 'electric', 'watching', 'flow'];
export const TRAIT_COLOR: Record<TraitName, string> = {
  growth: '#ccff00', fire: '#ff5e00', electric: '#00ffff', watching: '#8a2be2', flow: '#ff007f',
};

/** What each sticker type "means" for the world. Add a line here for every new sticker. */
export const STICKER_TRAITS: Record<string, { traits: Partial<Traits>; colors: string[] }> = {
  flower: { traits: { growth: 1 }, colors: ['#ff007f', '#ccff00'] },
  skull: { traits: { fire: 1 }, colors: ['#ff3b1f', '#f8f8f8'] },
  bolt: { traits: { electric: 1 }, colors: ['#ccff00', '#f8f8f8'] },
  eye: { traits: { watching: 1, flow: 0.2 }, colors: ['#00ffff', '#8a2be2'] },
};

export interface Source { x: number; y: number; kind: string; color: string; } // x,y in composition 0..1
export interface ArtworkProfile {
  palette: { color: string; weight: number }[];
  traits: Traits;
  ink: Source[];
  stickers: Source[];
  inkLength: number;
}

export function hexToHsl(hex: string): { h: number; s: number; l: number } {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex);
  const n = m ? parseInt(m[1], 16) : 0xff007f;
  const r = ((n >> 16) & 255) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
  if (d === 0) return { h: 0, s: 0, l };
  const s = d / (1 - Math.abs(2 * l - 1));
  let h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  h = (h * 60 + 360) % 360;
  return { h, s, l };
}

/** Which traits a color encourages (sums to about 1). */
export function colorTraits(hex: string): Partial<Traits> {
  const { h, s, l } = hexToHsl(hex);
  if (l > 0.88 || s < 0.15) return l < 0.25 ? { fire: 0.6, flow: 0.4 } : { electric: 0.6, flow: 0.4 }; // white/grey vs black
  if (l < 0.22) return { fire: 0.7, watching: 0.3 };                // near-black
  if (h >= 55 && h < 170) return { growth: 1 };                     // yellow-green, greens
  if (h >= 170 && h < 255) return { electric: 0.6, watching: 0.4 }; // cyan, blue
  if (h >= 255 && h < 335) return { flow: 0.7, watching: 0.3 };     // violet, magenta, pink
  return { fire: 1 };                                               // reds, oranges
}

function strokeLength(pts: { x: number; y: number }[]) {
  let len = 0;
  for (let i = 1; i < pts.length; i++) len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  return Math.max(len, 6); // a dot still counts a little
}

export function analyzeArtwork(letters: GameState['letters'], stickers: GameState['stickers']): ArtworkProfile {
  const byColor = new Map<string, number>();
  const ink: Source[] = [];
  let inkLength = 0, totalPoints = 0;
  for (const id of LETTER_IDS) for (const s of letters[id] ?? []) totalPoints += s.points.length;
  const stride = Math.max(1, Math.ceil(totalPoints / 500)); // keep at most ~500 ink sources

  for (const id of LETTER_IDS) {
    for (const s of letters[id] ?? []) {
      const len = strokeLength(s.points);
      inkLength += len;
      byColor.set(s.color, (byColor.get(s.color) ?? 0) + len);
      s.points.forEach((p, i) => {
        if (i % stride === 0) ink.push({ ...letterPointToComp(id, p.x, p.y), kind: 'ink', color: s.color });
      });
    }
  }

  const stickerSources: Source[] = [];
  const kindCount = new Map<string, number>();
  for (const id of LETTER_IDS) {
    for (const st of stickers[id] ?? []) {
      kindCount.set(st.kind, (kindCount.get(st.kind) ?? 0) + 1);
      stickerSources.push({ ...stickerToComp(id, st.x, st.y), kind: st.kind, color: STICKER_TRAITS[st.kind]?.colors[0] ?? '#8a2be2' });
    }
  }

  // Stickers also contribute their signature colors to the palette.
  const STICKER_INK = 350; // a sticker counts like this much drawn line
  for (const [kind, n] of kindCount) {
    for (const c of STICKER_TRAITS[kind]?.colors ?? []) byColor.set(c, (byColor.get(c) ?? 0) + (STICKER_INK * n) / 2);
  }

  const palette = [...byColor.entries()].map(([color, weight]) => ({ color, weight })).sort((a, b) => b.weight - a.weight).slice(0, 4);
  if (palette.length === 0) palette.push({ color: '#ff007f', weight: 1 });
  const totalW = palette.reduce((n, p) => n + p.weight, 0);

  // Blend: colors vote by how much ink they cover, stickers vote by how many there are.
  const raw: Traits = { growth: 0, fire: 0, electric: 0, watching: 0, flow: 0.12 };
  for (const p of palette) {
    const t = colorTraits(p.color);
    for (const k of TRAIT_NAMES) raw[k] += (t[k] ?? 0) * (p.weight / totalW) * 0.9;
  }
  for (const [kind, n] of kindCount) {
    const def = STICKER_TRAITS[kind] ?? { traits: { flow: 0.5 } };
    for (const k of TRAIT_NAMES) raw[k] += (def.traits[k] ?? 0) * Math.min(n, 4) * 0.5;
  }
  const max = Math.max(1, ...TRAIT_NAMES.map(k => raw[k]));
  const traits = Object.fromEntries(TRAIT_NAMES.map(k => [k, raw[k] / max])) as Traits;

  return { palette, traits, ink, stickers: stickerSources, inkLength };
}
