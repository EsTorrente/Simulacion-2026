# MEOW WOLF — Collaborative Interactive Typography (Milestone 2: multiplayer)

Two players, two computers, one Wi-Fi network. **The Cat** draws on the letters; **the Wolf** explores a maze and collects colors/stickers that unlock for the Cat. When both press "We're done", the artwork is finalized.

## Folder map
- `shared/` — types, maze data, validation and the **game rules** (`rules.ts`). Pure TypeScript, used by BOTH server and client. No React/Socket.IO here.
- `server/` — Node + Socket.IO. Holds the one authoritative game session in memory.
- `client/` — React + Vite. `game/socketAdapter.ts` talks to the server; `game/mockStateAdapter.ts` is the offline version (open `http://localhost:3000/?mock=1`).

## Install & run
```
npm run install:all
npm run dev:server     # terminal 1  (port 4000)
npm run dev:client     # terminal 2  (port 3000)
```
Three different things are involved:
- **Vite dev server (port 3000)** serves the web page.
- **Node/Socket.IO server (port 4000)** holds the game and keeps both players in sync.
- **Your local network address** (e.g. `192.168.1.23`) is how the other computer finds the host.

## Connect the second computer
1. On the host computer find its Wi-Fi IP (Windows: `ipconfig` → "IPv4 Address"; Mac: `ipconfig getifaddr en0`).
2. Host browser: `http://localhost:3000`. Second computer: `http://<host-ip>:3000`.
3. The page automatically connects to `<host-ip>:4000`. To override, create `client/.env` with `VITE_SERVER_URL=http://<host-ip>:4000`.
4. **Firewall:** the host must allow incoming connections on ports **3000 and 4000** (Windows will usually pop up a prompt the first time; choose "Private networks"). Both computers must be on the same network, and some public/guest Wi-Fi blocks device-to-device traffic.
5. Check the server is reachable from the second computer: `http://<host-ip>:4000/health` should show `{"status":"ok"}`.

## How to test the collaboration
1. Computer A picks Cat, computer B picks Wolf. The game starts when both seats are filled; a second Cat is refused.
2. Cat draws → the Wolf's "artwork" panel shows it. Cat "Clear Letter" removes it for both.
3. Wolf walks onto the colored dots/square → toast on the Wolf, new color/sticker on the Cat's side. Each item works only once.
4. Both press "We're done" → "BOTH PLAYERS AGREED" screen. If the Cat draws after the Wolf confirmed, confirmations reset.
5. Refresh a tab: it reclaims its seat (token kept in that tab's `sessionStorage`). Unplug Wi-Fi: a banner appears; the other player sees "disconnected — holding seat 30 seconds".
   Tip: two tabs on one computer also work for a quick test.

## Rules of the multiplayer model
- **Server is the boss.** Clients only *ask* (draw, move, confirm); the server validates and sends back the real state. Nothing shows success until the server says so.
- Seats: one Cat, one Wolf. Each player gets a secret server-made token (never broadcast) to reclaim their seat. Disconnect → seat + artwork held **30 s**, then the seat is released.
- Strokes use the 800×800 logical canvas, not screen pixels. Only the Cat can draw; only the Wolf can move; only unlocked colors are accepted.
- Limits: 2000 points per stroke, 500 strokes per letter, ~200 KB per message, moves throttled to ~14/s.

## Known limitations
- **Server memory only:** restarting the server resets everything.
- Only **completed strokes** sync (the Wolf sees a stroke when the Cat lifts the pen, not while drawing).
- The selected letter is local to the Cat.
- The server broadcasts the whole state on changes (strokes only when they changed) — simple over optimized.
- Not tested by me on two physical computers (see report).

## Tests
`npm run test:client` runs Vitest, including `client/src/game/rules.test.ts` (shared rules).

## For Milestone 3 to preserve
Strokes stay as data in `shared/types.ts` (boil is a render-time effect only); resource definitions live in `shared/maze.ts`; all state changes go through `shared/rules.ts`; screens talk only to the `StateAdapter` interface.

## Milestone 3 notes
- **Shared letter layout:** `features/common/LetterGuide.tsx` draws the reference letter in the 800x800 logical space; Cat canvas, strokes, stickers and Wolf previews all use it.
- **Stickers:** `shared/types.ts` (`PlacedSticker`: id, kind, x/y in 0..1 inside the letter, scale, rotation). Server events: `cat:sticker:add|update|remove`. Artwork/animation lives in `features/common/stickerArt.tsx` + `stickers.css`; add a sticker = one entry there + one collectible in `shared/maze.ts`.
- **Boil:** `game/boil.ts` (one 8 fps timer, render-only offsets; stroke data untouched; off under reduced-motion).
- **Sound:** `game/audio.ts` is the one audio engine: synthesized effects + the music tracks + the finale drone, on two buses (music / effects) under one master volume. Starts after the first click/keypress; mute, volume and the music/effects balance are saved in localStorage.
- **Music:** `client/public/audio/*.mp3` (about 4.2 MB total, loaded lazily). `game/musicTracks.ts` maps each screen (lobby, cat, wolf, finale) to a track; screens that share a track never restart it, different tracks crossfade (1.8 s). Tracks play their intro once, then loop seamlessly on the beat. `tools/prepare-music.py` rebuilds the files from the originals. The finale reads the music through an AnalyserNode (`getMusicPulse()`): bloom swells with the bass, the logo glows on beats, strong beats send a soft ring. In reduced-motion mode the visuals ignore the music.
- **Music credits:** "Browser History" and "Backroom Labyrinth" (supplied by the project owner; add composer/licence here).
- "Clear Drawing" removes strokes only; stickers are removed individually.

## Milestone 4 notes
- **Composition:** `shared/composition.ts` defines the 4x2 layout (M E O W / W O L F). `features/common/Composition.tsx` renders it for the Cat (editable), the Wolf and the finale.
- **Sticker editing:** pick a sticker, tap the letter to place; tap a placed sticker to select it, then use the on-canvas handles (✕ delete, ● resize, ◯ rotate), drag to move. Esc / "Done placing" cancels. Works with mouse and touch.
- **Finale:** when both confirm, the server picks a `seed`. Each browser analyzes the same artwork (`shared/world.ts`) and grows the same world from that seed (`finale/WorldSim.ts` = Physarum agents, `finale/behaviors.ts` = bloom / fire / electric / watchers / spiral). "Grow another" asks the server for a new seed; "Back to studio" reopens editing with the artwork kept.
- **Add a behavior:** write a class in `behaviors.ts` and add it to `createBehaviors()`. **Add a sticker meaning:** one line in `STICKER_TRAITS` (`shared/world.ts`).
- Both computers run the simulation locally from the same seed + artwork, so worlds are the same *structure* but not frame-for-frame identical (window sizes and frame rates differ).
- The reduced-motion setting (or the "Light mode" button) uses fewer agents, a slower speed, a shorter crossfade, and no lightning flashes.

## Stage A notes (UI/UX pass)
- **Lobby** (`features/lobby/LobbyScreen.tsx`, used for both online and `?mock=1`): the real logo outlines as a wordmark (`features/common/Wordmark.tsx`), role cards with seat state, a "waiting for the other player" status and the address to open on the second computer. A short weirdcore story frames the game; a few easter eggs hide in it (click the letters, the small eye, type `meow` / `wolf` / `house`, the "do not press" button, and click the Cat or Wolf mascot in the top bar). Gameplay is unaffected.
- **Connection**: `ConnectionVeil` (server unreachable / reconnecting, calm purple, says the seat is kept 30 s) and `PartnerAway` (a chip with a countdown when the other player drops). Both live in `features/common/Overlays.tsx`.
- **Notices**: one `Toast` (top-centre, never over the maze or artwork). `Notice.kind` is `info | error | found`; the wording of "found" notices is in `game/notices.ts` so both adapters stay in sync.
- **Hints**: `features/common/Hints.tsx`. First-time cards in the side column of each role, remembered in localStorage (`mw-hint-cat`, `mw-hint-wolf`), reopened with the "?" button.
- **Wolf touch controls**: `features/wolf/useWolfControls.ts` + `DPad.tsx`. Swipe on the maze (a virtual stick anchored where the finger lands) or the on-screen d-pad (auto-shown on touch screens, toggle on the Wolf side panel). Holding repeats one step per `WOLF_STEP_MS`, the server's own pacing, so nothing about speed changed.
- **Cat tools**: undo/redo are server intents (`cat:undo`, `cat:redo`; `GameSession.undo/redo`, history per letter, max 100, `GameState.history` gives the counts). Clear can be undone. Ctrl/Cmd+Z, Ctrl+Shift+Z, Ctrl+Y. The brush now stays on its own letter: leaving the shape (plus a little slack) ends the stroke, coming back in starts a new one. Sticker handles are no longer clipped at a cell's edge.
- **Layout**: shared kit in `styles/ui.css` (buttons `.btn .primary .ghost .small .icon-btn`, panels, toast, veil, lobby). The sound control is now a compact top-bar icon with a volume popover (floating in the lobby and finale). The "We're done" panel is pinned to the bottom of each side column so it is always visible.

## Finale (Stage C notes)
- Vines are grown in colors taken from the artwork, with a neon-tube look (glow, colored body, bright core), eased growth, a shining tip and a gentle sway; blooms have outlined two-layer petals and open with a small overshoot.
- Silhouettes (`scenery.ts`): organic mushrooms (curved stems, ruffled gills, babies), ferns, roots, crystals with facets, plus a mid-ground of grass tufts and tiny growths; sizes vary much more, with a few giants.
- Exposure: particle trails, bloom and the physarum layer are dimmer, and a soft pool behind the logo keeps it readable.
- Logo letters assemble one after another from scattered, spinning positions (plain fade in reduced-motion mode).
- Eyes have lids, lashes, iris fibres; they glance around by themselves when the pointer is away.
- Easter eggs in the finale: click an eye (it startles), type `meow` (every eye wakes, a ring), `awoo` (lightning), `eyes` (new eyes open). The lobby and mascot eggs from Stage A are unchanged.
