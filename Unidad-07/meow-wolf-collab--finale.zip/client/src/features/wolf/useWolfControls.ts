import { useCallback, useEffect, useRef } from 'react';
import { WOLF_STEP_MS } from '../../../../shared/maze';
import type { StateAdapter } from '../../game/stateAdapter';

export type Dir = 'up' | 'down' | 'left' | 'right';
const VEC: Record<Dir, [number, number]> = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };

/**
 * Touch / pointer steering for the Wolf. Holding a direction repeats one step per WOLF_STEP_MS, exactly the pace the
 * server allows, so this adds no new speed: it only saves the player from tapping 15 times.
 */
export function useDirectionRepeater(adapter: StateAdapter) {
  const timer = useRef<number | undefined>(undefined);
  const dir = useRef<Dir | null>(null);
  const stop = useCallback(() => { window.clearInterval(timer.current); timer.current = undefined; dir.current = null; }, []);
  const press = useCallback((d: Dir) => {
    if (dir.current === d) return;
    window.clearInterval(timer.current);
    dir.current = d;
    const [dx, dy] = VEC[d];
    adapter.moveWolf(dx, dy);
    timer.current = window.setInterval(() => adapter.moveWolf(dx, dy), WOLF_STEP_MS);
  }, [adapter]);
  useEffect(() => {
    const off = () => stop();
    window.addEventListener('blur', off); document.addEventListener('visibilitychange', off);
    return () => { off(); window.removeEventListener('blur', off); document.removeEventListener('visibilitychange', off); };
  }, [stop]);
  return { press, release: stop };
}

/** Swipe/drag steering on an element: acts like a virtual stick anchored where the finger went down. */
export function swipeHandlers(press: (d: Dir) => void, release: () => void, threshold = 26) {
  let ax = 0, ay = 0, active = false;
  return {
    onPointerDown: (e: React.PointerEvent) => { if (e.pointerType === 'mouse') return; active = true; ax = e.clientX; ay = e.clientY; try { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } catch { /* pointer already gone */ } },
    onPointerMove: (e: React.PointerEvent) => {
      if (!active) return;
      const dx = e.clientX - ax, dy = e.clientY - ay;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < threshold) return;
      press(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
      ax = e.clientX; ay = e.clientY; // re-anchor so a change of direction is just another swipe
    },
    onPointerUp: () => { active = false; release(); },
    onPointerCancel: () => { active = false; release(); },
  };
}
