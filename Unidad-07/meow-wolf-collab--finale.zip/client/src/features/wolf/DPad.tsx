import type { Dir } from './useWolfControls';

const ARROW: Record<Dir, string> = { up: 'M12 6l7 9H5z', down: 'M12 18l-7-9h14z', left: 'M6 12l9-7v14z', right: 'M18 12l-9 7V5z' };

/** On-screen d-pad (shown on touch screens, or switched on from the top bar). Hold to keep running. */
export default function DPad({ press, release }: { press: (d: Dir) => void; release: () => void }) {
  return (
    <div className="dpad" role="group" aria-label="Move the Wolf">
      {(['up', 'left', 'right', 'down'] as Dir[]).map(d => (
        <button key={d} className={`dpad-btn ${d}`} aria-label={`Move ${d}`}
          onPointerDown={e => { e.preventDefault(); try { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } catch { /* pointer already gone */ } press(d); }}
          onPointerUp={release} onPointerCancel={release} onContextMenu={e => e.preventDefault()}>
          <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden><path d={ARROW[d]} fill="currentColor" /></svg>
        </button>
      ))}
    </div>
  );
}
