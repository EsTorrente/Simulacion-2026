import { useEffect, useRef, useState } from 'react';
import type { Collectible, Enemy, Position, WolfCondition } from '../../game/types';
import { STICKERS } from '../common/stickerArt';

interface Props { grid: number[][]; wolfPos: Position; collectibles: Collectible[]; enemies: Enemy[]; wolfCondition: WolfCondition; catches: number; }

const C = 56; // cell size in SVG units
const hash = (x: number, y: number) => { const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return n - Math.floor(n); };

export function WolfIcon({ size = 28 }: { size?: number }) {
  return (
    <svg viewBox="-26 -28 52 52" width={size} height={size} style={{ filter: 'drop-shadow(0 0 5px #ccff00)' }}>
      <path d="M-18-4 L-17-24 L-6-13 L6-13 L17-24 L18-4 L14 10 L4 21 L-4 21 L-14 10Z" fill="#0c1a06" stroke="#ccff00" strokeWidth="2.6" strokeLinejoin="round" />
      <path d="M-12-1 L-5 3 L-12 5Z M12-1 L5 3 L12 5Z" fill="#ccff00" />
      <path d="M-4 12 H4 L0 17Z" fill="#ff2d9b" />
    </svg>
  );
}

/** The Wolf's maze. Same grid and rules as before; this is only how it is drawn. */
const ENEMY_COLOR: Record<Enemy['kind'], string> = { hunter: '#ff3b3b', stalker: '#c452ff', drifter: '#4dff88', guardian: '#ffb020' };
export const ENEMY_NAME: Record<Enemy['kind'], string> = { hunter: 'Hunter', stalker: 'Stalker', drifter: 'Drifter', guardian: 'Guardian' };
const spikes = (n: number, ro: number, ri: number) => Array.from({ length: n * 2 }, (_, i) => { const a = (i / (n * 2)) * Math.PI * 2, r = i % 2 ? ri : ro; return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`; }).join(' ');

/** Each enemy has its own silhouette so it can be told apart at a glance, and none look like a pickup (no cyan halo, no sticker art). */
export function EnemyArt({ kind, dir, alert }: { kind: Enemy['kind']; dir: Position; alert: boolean }) {
  const c = ENEMY_COLOR[kind], px = dir.x * 2.6, py = dir.y * 2.6;
  const eye = (x: number, y: number, r = 5) => <g><circle cx={x} cy={y} r={r} fill="#fff" /><circle cx={x + px} cy={y + py} r={r * 0.55} fill={alert ? '#c00' : '#111'} /></g>;
  return (
    <g style={{ filter: `drop-shadow(0 0 ${alert ? 8 : 4}px ${c})` }}>
      {kind === 'hunter' && <><polygon points={spikes(9, 19, 12.5)} fill="#2a0508" stroke={c} strokeWidth="2" strokeLinejoin="round" />{eye(0, 0, 7)}</>}
      {kind === 'stalker' && <>
        {[-1, 1].flatMap(sx => [-9, 0, 9].map((y, i) => <path key={`${sx}${i}`} d={`M${sx * 8} ${y * 0.5} L${sx * 16} ${y - 3} L${sx * 20} ${y + 6}`} stroke={c} strokeWidth="2" fill="none" strokeLinecap="round" />))}
        <ellipse rx="12" ry="11" fill="#1d0535" stroke={c} strokeWidth="2" />{eye(-4.5, -3, 3.6)}{eye(4.5, -3, 3.6)}<circle cx="0" cy="5" r="2.4" fill={c} />
      </>}
      {kind === 'drifter' && <g className="mw-fx" style={{ animation: 'mw-pulse 1.1s ease-in-out infinite' }}>
        <path d="M-17 8 C-19 -8 -8 -17 0 -17 C9 -17 19 -8 17 8 C14 16 8 12 5 17 C2 12 -3 17 -7 12 C-12 17 -16 13 -17 8Z" fill="#0a2a12" stroke={c} strokeWidth="2" />
        {eye(-6, -3, 4.5)}{eye(6, -3, 4.5)}</g>}
      {kind === 'guardian' && <>
        <polygon points={spikes(3, 20, 20).split(' ').filter((_, i) => i % 2 === 0).join(' ')} fill="#2b1a02" stroke={c} strokeWidth="3" strokeLinejoin="round" transform="rotate(-90)" />
        <polygon points={spikes(3, 20, 20).split(' ').filter((_, i) => i % 2 === 0).join(' ')} fill="none" stroke={c} strokeWidth="1" opacity="0.5" transform="rotate(-90) scale(0.55)" />
        <ellipse cx="0" cy="2" rx="9" ry="4.5" fill={alert ? '#ff3b3b' : c} /><ellipse cx={px} cy={2 + py} rx="2" ry="4" fill="#111" /></>}
    </g>
  );
}

export default function Maze({ grid, wolfPos, collectibles, enemies, wolfCondition, catches }: Props) {
  const lastCatch = useRef(catches);
  const [flash, setFlash] = useState(0);
  useEffect(() => { if (catches > lastCatch.current) setFlash(k => k + 1); lastCatch.current = catches; }, [catches]);
  const rows = grid.length, cols = grid[0].length, W = cols * C, H = rows * C;
  const wall = (x: number, y: number) => (grid[y]?.[x] ?? 1) === 1;

  // Burst effect where something was just collected.
  const seen = useRef<Set<string> | null>(null);
  const [bursts, setBursts] = useState<{ k: number; x: number; y: number; color: string }[]>([]);
  useEffect(() => {
    const now = new Set(collectibles.filter(c => c.collected).map(c => c.id));
    if (seen.current) {
      const fresh = collectibles.filter(c => c.collected && !seen.current!.has(c.id));
      if (fresh.length) {
        const add = fresh.map(c => ({ k: Math.random(), x: c.pos.x, y: c.pos.y, color: c.type === 'color' ? c.value : '#00ffff' }));
        setBursts(b => [...b, ...add]);
        window.setTimeout(() => setBursts(b => b.filter(o => !add.includes(o))), 800);
      }
    }
    seen.current = now;
  }, [collectibles]);

  const edges: JSX.Element[] = [];
  const decor: JSX.Element[] = [];
  const dots: JSX.Element[] = [];
  const items = collectibles.filter(c => !c.collected);
  for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
    const px = x * C, py = y * C;
    if (wall(x, y)) {
      if (!wall(x, y - 1) && y > 0) edges.push(<line key={`t${x}_${y}`} x1={px} y1={py} x2={px + C} y2={py} />);
      if (!wall(x, y + 1) && y < rows - 1) edges.push(<line key={`b${x}_${y}`} x1={px} y1={py + C} x2={px + C} y2={py + C} />);
      if (!wall(x - 1, y) && x > 0) edges.push(<line key={`l${x}_${y}`} x1={px} y1={py} x2={px} y2={py + C} />);
      if (!wall(x + 1, y) && x < cols - 1) edges.push(<line key={`r${x}_${y}`} x1={px + C} y1={py} x2={px + C} y2={py + C} />);
      // quiet texture inside thick wall masses (dim, never bright enough to be mistaken for an item)
      const interior = wall(x - 1, y) && wall(x + 1, y) && wall(x, y - 1) && wall(x, y + 1);
      if (interior) {
        const h = hash(x, y);
        decor.push(h < 0.5
          ? <circle key={`d${x}_${y}`} cx={px + C / 2} cy={py + C / 2} r={3 + h * 6} fill="none" stroke="#8a5bff" strokeWidth="1" opacity="0.35" />
          : <path key={`d${x}_${y}`} d={`M${px + 12} ${py + C - 12} Q${px + C / 2} ${py + 6} ${px + C - 12} ${py + C - 12}`} fill="none" stroke="#2f7bff" strokeWidth="1.2" opacity="0.35" />);
      }
    } else if (!(wolfPos.x === x && wolfPos.y === y) && !items.some(c => c.pos.x === x && c.pos.y === y)) {
      dots.push(<circle key={`p${x}_${y}`} cx={px + C / 2} cy={py + C / 2} r="1.8" fill="#7fe7ff" opacity="0.28" />);
    }
  }

  return (
    <svg viewBox={`-6 -6 ${W + 12} ${H + 12}`} style={{ width: 'min(68dvh, 52vw)', aspectRatio: '1', display: 'block' }} role="img" aria-label="Maze">
      <defs>
        <linearGradient id="mz-neon" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2={W} y2={H}>
          <stop offset="0" stopColor="#2f7bff" /><stop offset="0.5" stopColor="#9b4dff" /><stop offset="1" stopColor="#ff2d9b" />
        </linearGradient>
        <radialGradient id="mz-floor" cx="50%" cy="50%" r="70%"><stop offset="0" stopColor="#1a0f3d" /><stop offset="1" stopColor="#07050f" /></radialGradient>
        <radialGradient id="mz-halo"><stop offset="0" stopColor="#fff" stopOpacity="0.35" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></radialGradient>
        <clipPath id="mz-clip"><rect x="0" y="0" width={W} height={H} rx="14" /></clipPath>
      </defs>
      <rect x="-6" y="-6" width={W + 12} height={H + 12} rx="18" fill="#05040c" />
      <g clipPath="url(#mz-clip)">
        <rect width={W} height={H} fill="url(#mz-floor)" />
        {/* wall masses */}
        {grid.map((row, y) => row.map((c, x) => c === 1 && <rect key={`w${x}_${y}`} x={x * C} y={y * C} width={C + 0.5} height={C + 0.5} fill="#0f0833" />))}
        <g>{decor}</g>
        {/* layered neon edges: wide soft glow -> mid -> crisp core */}
        <g stroke="url(#mz-neon)" strokeLinecap="round" fill="none">
          <g strokeWidth="14" opacity="0.14">{edges}</g>
          <g strokeWidth="7" opacity="0.3">{edges}</g>
          <g strokeWidth="2.6">{edges}</g>
        </g>
        <g stroke="#fff" strokeWidth="0.8" opacity="0.45" strokeLinecap="round">{edges}</g>
        <g>{dots}</g>

        {/* collectibles */}
        {items.map(c => {
          const cx = c.pos.x * C + C / 2, cy = c.pos.y * C + C / 2;
          if (c.type === 'sticker') {
            const Art = (STICKERS[c.value] ?? STICKERS.skull).Art;
            return (
              <g key={c.id} transform={`translate(${cx} ${cy})`}>
                <circle r="26" fill="url(#mz-halo)" />
                <circle r="23" fill="none" stroke="#00ffff" strokeWidth="1.5" strokeDasharray="3 5" className="mw-fx" style={{ animation: 'mw-spin 9s linear infinite' }} />
                <g transform="scale(0.4)"><Art /></g>
              </g>
            );
          }
          return (
            <g key={c.id} transform={`translate(${cx} ${cy})`}>
              <circle r="17" fill="none" stroke={c.value} strokeWidth="2" className="mw-fx" style={{ animation: 'mw-pulse 1.8s ease-in-out infinite' }} />
              <circle r="9" fill={c.value} style={{ filter: `drop-shadow(0 0 6px ${c.value})` }} />
              <circle r="3" cx="-3" cy="-3" fill="#fff" opacity="0.8" />
            </g>
          );
        })}

        {bursts.map(b => (
          <circle key={b.k} cx={b.x * C + C / 2} cy={b.y * C + C / 2} r="22" fill="none" stroke={b.color} strokeWidth="3" className="mw-fx" style={{ animation: 'mw-burst .8s ease-out forwards' }} />
        ))}

        {/* enemies */}
        {enemies.map(e => (
          <g key={e.id} style={{ transform: `translate(${e.pos.x * C + C / 2}px, ${e.pos.y * C + C / 2}px)`, transition: 'transform 190ms linear' }}>
            {e.alert && <circle r="25" fill="none" stroke="#ff2020" strokeWidth="2" className="mw-fx" style={{ animation: 'mw-pulse 0.5s ease-in-out infinite' }} />}
            <g transform="scale(1)"><EnemyArt kind={e.kind} dir={e.dir} alert={e.alert} /></g>
          </g>
        ))}

        {/* the Wolf */}
        <g className="mw-wolf" style={{ transform: `translate(${wolfPos.x * C + C / 2}px, ${wolfPos.y * C + C / 2}px)`, transition: 'transform 110ms ease-out' }}>
          <circle r="24" fill="url(#mz-halo)" style={{ fill: '#ccff00', opacity: 0.18 }} />
          {wolfCondition === 'invulnerable' && <circle r="22" fill="none" stroke="#7fe7ff" strokeWidth="2.5" strokeDasharray="6 4" className="mw-fx" style={{ animation: 'mw-spin 1.4s linear infinite' }} />}
          <g transform="scale(0.62)" className={wolfCondition === 'invulnerable' ? 'mw-fx' : undefined}
            style={{ filter: wolfCondition === 'stunned' ? 'grayscale(1) brightness(0.6)' : 'drop-shadow(0 0 6px #ccff00)', animation: wolfCondition === 'invulnerable' ? 'mw-blink 0.35s steps(2) infinite' : undefined }}>
            <path d="M-18-4 L-17-24 L-6-13 L6-13 L17-24 L18-4 L14 10 L4 21 L-4 21 L-14 10Z" fill="#0c1a06" stroke="#ccff00" strokeWidth="3" strokeLinejoin="round" />
            <path d="M-12-1 L-5 3 L-12 5Z M12-1 L5 3 L12 5Z" fill="#ccff00" />
            <path d="M-4 12 H4 L0 17Z" fill="#ff2d9b" />
          </g>
        </g>
        {flash > 0 && <rect key={flash} width={W} height={H} fill="#ff1030" className="mw-fx" style={{ animation: 'mw-hit 0.7s ease-out forwards', pointerEvents: 'none' }} />}
        {wolfCondition === 'stunned' && (
          <g><rect width={W} height={H} fill="#05040c" opacity="0.55" />
            <text x={W / 2} y={H / 2 - 6} textAnchor="middle" fontSize="30" fontWeight="700" fill="#ff5577" letterSpacing="4" style={{ filter: 'drop-shadow(0 0 8px #ff1030)' }}>OUT OF LIVES</text>
            <text x={W / 2} y={H / 2 + 26} textAnchor="middle" fontSize="16" fill="#cfd">Recovering… found items are kept</text></g>
        )}
        {/* vignette */}
        <rect width={W} height={H} fill="none" stroke="#000" strokeWidth="26" opacity="0.5" />
      </g>
      <rect x="0" y="0" width={W} height={H} rx="14" fill="none" stroke="url(#mz-neon)" strokeWidth="2.5" opacity="0.9" />
    </svg>
  );
}
