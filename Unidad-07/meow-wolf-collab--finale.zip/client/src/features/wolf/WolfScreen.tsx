import { useEffect, useState } from 'react';
import { MAZE_GRID } from '../../../../shared/maze';
import { DRIFTER_RANGE, GUARD_RANGE, HUNTER_RANGE } from '../../../../shared/enemies';
import type { StateAdapter } from '../../game/stateAdapter';
import { useGameState } from '../../game/useAdapter';
import Maze, { WolfIcon, EnemyArt, ENEMY_NAME } from './Maze';
import { STICKERS } from '../common/stickerArt';
import Composition from '../common/Composition';
import FinishPanel from '../common/FinishPanel';
import TopBar from '../common/TopBar';
import { HintCard, useHint } from '../common/Hints';
import DPad from './DPad';
import { swipeHandlers, useDirectionRepeater } from './useWolfControls';
import { sfx } from '../../game/audio';

const coarse = () => window.matchMedia('(pointer: coarse)').matches;
const HOWL = ['awoo.', 'the halls answer.', 'something moved in the walls.', 'good dog. (it said that)'];

export default function WolfScreen({ adapter, onExit }: { adapter: StateAdapter; onExit: () => void }) {
  const gameState = useGameState(adapter);
  const hint = useHint('wolf');
  const [touch, setTouch] = useState(coarse);
  const [howl, setHowl] = useState('');
  const { press, release } = useDirectionRepeater(adapter);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      switch (key) {
        case 'ArrowUp': case 'w': e.preventDefault(); adapter.moveWolf(0, -1); break;
        case 'ArrowDown': case 's': e.preventDefault(); adapter.moveWolf(0, 1); break;
        case 'ArrowLeft': case 'a': e.preventDefault(); adapter.moveWolf(-1, 0); break;
        case 'ArrowRight': case 'd': e.preventDefault(); adapter.moveWolf(1, 0); break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [adapter]);
  useEffect(() => { if (!howl) return; const t = window.setTimeout(() => setHowl(''), 2600); return () => clearTimeout(t); }, [howl]);

  if (!gameState) return null;

  const totalCol = gameState.collectibles.length;
  const collectedCount = gameState.collectibles.filter(c => c.collected).length;
  const stickerItems = gameState.collectibles.filter(c => c.type === 'sticker');
  const colorItems = gameState.collectibles.filter(c => c.type === 'color');
  const swipe = swipeHandlers(press, release);
  const foes = [
    ['hunter', `Chases you by the shortest path once you are within ${HUNTER_RANGE} steps`],
    ['stalker', 'Aims where you are heading, not where you are. Rests every third step'],
    ['drifter', `Wanders aimlessly, then snaps onto you within ${DRIFTER_RANGE} steps`],
    ['guardian', `Stays at its post until you come within ${GUARD_RANGE} steps, then goes home`],
  ] as const;

  return (
    <div className={`screen-container theme-wolf ${touch ? 'has-dpad' : ''}`}>
      <TopBar icon={<WolfIcon size={34} />} title="WOLF" tagline={howl || 'Collect the stickers. Help the Cat create.'}
        onIcon={() => { sfx.howl(); setHowl(HOWL[Math.floor(Math.random() * HOWL.length)]); }} onHelp={hint.show} onExit={onExit}>
        <div className="lives" role="img" aria-label={`Lives: ${gameState.lives} of ${gameState.maxLives}`}>
          {Array.from({ length: gameState.maxLives }, (_, i) => <span key={i} className={`mw-heart ${i < gameState.lives ? '' : 'lost'}`} style={{ color: '#ff2d9b' }}>{i < gameState.lives ? '♥' : '♡'}</span>)}
        </div>
        <span className="mw-pill" title="Items found">✦ {collectedCount}/{totalCol}</span>
        <div className="slots" aria-label="Inventory">
          {stickerItems.map(c => {
            const Art = (STICKERS[c.value] ?? STICKERS.skull).Art;
            return <div key={c.id} className={`mw-slot ${c.collected ? 'on' : 'off'}`} title={c.collected ? STICKERS[c.value]?.label : 'Not found yet'}>
              <svg viewBox="-55 -55 110 110" width="24" height="24" style={{ filter: c.collected ? 'none' : 'grayscale(1) brightness(0.4)' }}><Art /></svg>
            </div>;
          })}
          {colorItems.map(c => (
            <div key={c.id} className={`mw-slot ${c.collected ? 'on' : 'off'}`} title={c.collected ? 'Color found' : 'Not found yet'}>
              <div style={{ width: 16, height: 16, borderRadius: '50%', background: c.collected ? c.value : '#555', boxShadow: c.collected ? `0 0 9px ${c.value}` : 'none' }} />
            </div>
          ))}
        </div>
      </TopBar>

      <div className="wolf-body">
        <div className="maze-wrap" {...swipe}>
          <div className="maze-frame">
            <Maze grid={MAZE_GRID} wolfPos={gameState.wolfPos} collectibles={gameState.collectibles} enemies={gameState.enemies} wolfCondition={gameState.wolfCondition} catches={gameState.catches} />
          </div>
        </div>
        <div className="wolf-side">
          <div className="side-scroll">
      {hint.open && (
        <HintCard title="How to run the halls" onClose={hint.dismiss} steps={[
          { icon: '⌨', text: <>Move with <b>arrow keys</b> or <b>WASD</b>. On a touchscreen, swipe on the maze or use the d-pad.</> },
          { icon: '✦', text: <>Touch the <b>spinning stickers</b> and <b>glowing dots</b>. Each one unlocks something for the Cat.</> },
          { icon: '☠', text: <>Four creatures hunt differently (see <b>Beware</b>). They stay still until your first step.</> },
          { icon: '♥', text: <>Caught = lose a heart and start over, with a moment of safety. Found items are kept.</> },
          { icon: '✔', text: <>When the Cat&rsquo;s sign is ready, press <b>We&rsquo;re done</b>.</> },
        ]} />
      )}
          <div className="mw-panel">
            <h3>The Cat&rsquo;s artwork</h3>
            <Composition letters={gameState.letters} stickers={gameState.stickers} />
          </div>
          <div className="mw-panel">
            <h3>Beware</h3>
            <div className="beware">
              {foes.map(([k, d]) => (
                <div key={k} className="foe">
                  <svg viewBox="-26 -26 52 52" width="34" height="34" aria-hidden><EnemyArt kind={k} dir={{ x: 0, y: 1 }} alert={false} /></svg>
                  <span><b>{ENEMY_NAME[k]}</b><span className="muted">{d}</span></span>
                </div>
              ))}
            </div>
            <p className="muted"><span className="alert-ring" aria-hidden /> Red pulsing ring = it is chasing you. You are faster than all of them.</p>
          </div>
          <button className="btn small ghost" aria-pressed={touch} onClick={() => setTouch(t => !t)}>{touch ? 'Hide' : 'Show'} on-screen d-pad</button>
          </div>
          <FinishPanel role="Wolf" state={gameState} adapter={adapter} />
        </div>
      </div>
      {touch && <DPad press={press} release={release} />}
    </div>
  );
}
