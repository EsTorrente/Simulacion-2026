// Sticker artwork. Each sticker is a small SVG drawn around (0,0), about 100 units wide,
// animated with CSS (see stickers.css). To add a sticker: add an entry to STICKERS and a
// matching collectible in shared/maze.ts.
import type { CSSProperties, ReactElement } from 'react';
import type { PlacedSticker } from '../../game/types';
import './stickers.css';

const Skull = () => (
  <g className="st-anim st-skull">
    <circle cx="0" cy="-8" r="32" fill="#f8f8f8" stroke="#09090b" strokeWidth="3" />
    <rect x="-18" y="16" width="36" height="22" rx="5" fill="#f8f8f8" stroke="#09090b" strokeWidth="3" />
    <circle cx="-13" cy="-8" r="9" fill="#09090b" /><circle cx="13" cy="-8" r="9" fill="#09090b" />
    <path d="M0 6 l-5 10 h10 z" fill="#09090b" />
    <path d="M-9 24 v12 M0 24 v12 M9 24 v12" stroke="#09090b" strokeWidth="2.5" />
  </g>
);

const Eye = () => (
  <g className="st-anim st-eye">
    <ellipse rx="40" ry="27" fill="#f8f8f8" stroke="#ff007f" strokeWidth="5" />
    <g className="st-anim st-pupil"><circle r="14" fill="#00ffff" /><circle r="6.5" fill="#09090b" /></g>
  </g>
);

const Flower = () => (
  <g className="st-anim st-flower">
    <g className="st-anim st-bloom">
      {[0, 1, 2, 3, 4, 5].map(i => (
        <ellipse key={i} cy="-22" rx="12" ry="21" fill="#ff007f" stroke="#09090b" strokeWidth="2.5" transform={`rotate(${i * 60})`} />
      ))}
    </g>
    <circle r="12" fill="#ccff00" stroke="#09090b" strokeWidth="2.5" />
  </g>
);

const Bolt = () => (
  <g className="st-anim st-bolt">
    <polygon points="8,-48 -24,6 -3,6 -12,48 26,-8 4,-8" fill="#ccff00" stroke="#f8f8f8" strokeWidth="4" strokeLinejoin="round" />
  </g>
);

const Fallback = () => <polygon points="0,-40 12,-12 42,-12 18,8 28,38 0,20 -28,38 -18,8 -42,-12 -12,-12" fill="#8a2be2" stroke="#f8f8f8" strokeWidth="3" />;

export const STICKERS: Record<string, { label: string; Art: () => ReactElement }> = {
  skull: { label: 'Skull', Art: Skull },
  eye: { label: 'Eye', Art: Eye },
  flower: { label: 'Flower', Art: Flower },
  bolt: { label: 'Bolt', Art: Bolt },
};

const BASE_SCALE = 1.2; // art is ~100 units; 1.2 => ~120 of the 800-unit letter box

export function stickerTransform(s: { x: number; y: number; scale: number; rotation: number }) {
  return `translate(${s.x * 800} ${s.y * 800}) rotate(${s.rotation}) scale(${s.scale * BASE_SCALE})`;
}

/** One sticker, positioned in letter space. Animation start is offset per sticker id. */
export function StickerShape({ s, override }: { s: PlacedSticker; override?: { x: number; y: number } }) {
  const Art = (STICKERS[s.kind] ?? { Art: Fallback }).Art;
  let h = 0; for (const ch of s.id) h = (h * 31 + ch.charCodeAt(0)) % 3000;
  return (
    <g transform={stickerTransform({ ...s, ...override })} style={{ '--d': `-${h}ms` } as CSSProperties}>
      <Art />
    </g>
  );
}

/** Read-only sticker layer (Wolf's preview). */
export function StickerLayer({ stickers }: { stickers: PlacedSticker[] }) {
  return (
    <svg viewBox="0 0 800 800" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
      {stickers.map(s => <StickerShape key={s.id} s={s} />)}
    </svg>
  );
}
