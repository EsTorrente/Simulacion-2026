import type { ReactNode } from 'react';
import { COMP_COLS, COMP_ROWS, CELL_W, CELL_H } from '../../../../shared/composition';
import { LOGO } from '../../../../shared/logo';
import { LETTER_IDS, type GameState, type LetterID } from '../../game/types';
import StrokePreview from './StrokePreview';
import { pickLetter } from './glyphHit';

interface Props {
  letters: GameState['letters'];
  stickers: GameState['stickers'];
  selected?: LetterID;
  onSelect?: (id: LetterID) => void;
  editing?: ReactNode; // the Cat's drawing + sticker layers, shown inside the selected cell
  style?: React.CSSProperties;
}

/** All of MEOW WOLF at once, laid out exactly like the official logo. Used by the Cat (editable), the Wolf and the finale. */
export default function Composition({ letters, stickers, selected, onSelect, editing, style }: Props) {
  return (
    <div style={{ position: 'relative', width: '100%', aspectRatio: `${COMP_COLS} / ${COMP_ROWS}`, ...style }}>
      {/* One click layer for the whole wordmark: picks by real glyph shape, not by overlapping boxes. */}
      {onSelect && (
        <div style={{ position: 'absolute', inset: 0, cursor: 'pointer', zIndex: 0 }}
          onPointerDown={e => {
            const r = e.currentTarget.getBoundingClientRect();
            onSelect(pickLetter((e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height));
          }} />
      )}
      {LETTER_IDS.map(id => {
        const isSel = selected === id;
        const { cx, cy } = LOGO[id];
        return (
          <div key={id} style={{
            position: 'absolute', left: `${(cx - CELL_W / 2) * 100}%`, top: `${(cy - CELL_H / 2) * 100}%`,
            width: `${CELL_W * 100}%`, height: `${CELL_H * 100}%`, zIndex: isSel ? 2 : 1, pointerEvents: 'none',
          }}>
            <StrokePreview bare letter={id} selected={isSel} strokes={letters[id]} stickers={stickers[id]} />
            {isSel && editing && <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>{editing}</div>}
          </div>
        );
      })}
    </div>
  );
}
