import { useEffect, useState } from 'react';
import type { GameState, Role } from '../../game/types';
import type { ConnStatus } from '../../game/socketAdapter';
import type { Notice } from '../../game/stateAdapter';

const GRACE_S = 30; // matches the server's seat-holding time

/** Connection trouble: calm, centred, and clear about what is safe. Nothing here is red. */
export function ConnectionVeil({ conn, hasRole }: { conn: ConnStatus; hasRole: boolean }) {
  if (conn === 'connected') return null;
  const first = conn === 'connecting' && !hasRole;
  return (
    <div className="veil" role="status" aria-live="polite">
      <div className="veil-card">
        <div className="signal" aria-hidden><i /><i /><i /></div>
        <h2>{first ? 'Finding the house…' : 'The signal wavers'}</h2>
        <p>{first ? 'Connecting to the game server.'
          : hasRole ? 'Reconnecting. Your seat and your artwork are kept for 30 seconds.' : 'The server is out of reach. Trying again…'}</p>
        <p className="muted">Both computers must be on the same Wi-Fi, and the server must be running.</p>
      </div>
    </div>
  );
}

/** The other player dropped: a small chip with the seat-hold countdown (never blocks the game). */
export function PartnerAway({ state, role, conn }: { state: GameState | null; role: Role; conn: ConnStatus }) {
  const other = role === 'Cat' ? 'Wolf' : 'Cat';
  const away = !!state && !!role && conn === 'connected' && state.players[other].occupied && !state.players[other].connected;
  const [left, setLeft] = useState(GRACE_S);
  useEffect(() => {
    if (!away) return;
    setLeft(GRACE_S);
    const t = window.setInterval(() => setLeft(n => Math.max(0, n - 1)), 1000);
    return () => clearInterval(t);
  }, [away]);
  if (!away) return null;
  return (
    <div className="away-chip" role="status" aria-live="polite">
      <span className="dot" aria-hidden /> The {other} wandered off. Holding their seat for {left}s…
    </div>
  );
}

/** One short message, top-centre (over the top bar's tagline, so it never covers the maze or the artwork). */
export function Toast({ notice }: { notice: Notice | null }) {
  if (!notice) return null;
  const icon = notice.kind === 'found' ? '✦' : notice.kind === 'error' ? '!' : 'i';
  return (
    <div key={notice.message} className={`toast ${notice.kind}`} style={notice.color ? { ['--tc' as string]: notice.color } : undefined} role={notice.kind === 'error' ? 'alert' : 'status'}>
      <span className="toast-ico" aria-hidden>{icon}</span>{notice.message}
    </div>
  );
}
