import { useState } from 'react';
import { getMusicLevel, getSfxLevel, getVolume, isMuted, setMusicLevel, setMuted, setSfxLevel, setVolume } from '../../game/audio';
import { TRACKS } from '../../game/musicTracks';

/** Compact sound control: one icon button (mute) with a popover for master volume and the music / effects balance. Sits in the top bar, or floats in a corner on full-screen scenes. */
export default function SoundControl({ floating }: { floating?: 'tl' | 'tr' | 'bl' | 'br' }) {
  const [muted, setM] = useState(isMuted());
  const [vol, setV] = useState(getVolume());
  const [music, setMusic] = useState(getMusicLevel());
  const [fx, setFx] = useState(getSfxLevel());
  return (
    <div className={`sound ${floating ? `floating ${floating}` : ''}`}>
      <button className="icon-btn" aria-pressed={muted} aria-label={muted ? 'Unmute sound' : 'Mute sound'} title={muted ? 'Unmute' : 'Mute'}
        onClick={() => { setMuted(!muted); setM(!muted); }}>
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M4 9h4l5-4v14l-5-4H4z" />
          {muted ? <path d="M17 9l5 6M22 9l-5 6" /> : <><path d="M16.5 9a4 4 0 0 1 0 6" />{vol > 0.5 && <path d="M19 6.5a8 8 0 0 1 0 11" />}</>}
        </svg>
      </button>
      <div className="sound-pop">
        <label>Volume
          <input type="range" min={0} max={1} step={0.05} value={vol} aria-label="Volume"
            onChange={e => { const v = Number(e.target.value); setVolume(v); setV(v); }} />
        </label>
        <label>Music
          <input type="range" min={0} max={1} step={0.05} value={music} aria-label="Music level"
            onChange={e => { const v = Number(e.target.value); setMusicLevel(v); setMusic(v); }} />
        </label>
        <label>Effects
          <input type="range" min={0} max={1} step={0.05} value={fx} aria-label="Sound effects level"
            onChange={e => { const v = Number(e.target.value); setSfxLevel(v); setFx(v); }} />
        </label>
        <p className="sound-credit">♪ {Object.values(TRACKS).map(t => t.title).join(' · ')}</p>
      </div>
    </div>
  );
}
