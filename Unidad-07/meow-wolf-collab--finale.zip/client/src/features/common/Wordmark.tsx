// MEOW WOLF drawn from the official logo outlines (shared/logo.ts, generated from the PNG). Never a font.
import { LOGO, LOGO_CELL_PX, LOGO_VIEW } from '../../../../shared/logo';
import { LETTER_IDS, type LetterID } from '../../game/types';

interface Props {
  className?: string;
  style?: React.CSSProperties;
  /** Clicking a letter (lobby easter eggs). Makes the letters pointer-reactive. */
  onLetter?: (id: LetterID) => void;
  /** Letters that are currently "glitching". */
  glitching?: ReadonlySet<LetterID>;
  /** Single-colour version (e.g. white). Default: each letter keeps its own logo colour. */
  mono?: string;
}

const S = LOGO_CELL_PX / 800; // one letter-space unit in logo pixels

export default function Wordmark({ className, style, onLetter, glitching, mono }: Props) {
  return (
    <svg viewBox={`0 0 ${LOGO_VIEW.w} ${LOGO_VIEW.h}`} className={`wordmark ${className ?? ''}`} style={style} role="img" aria-label="MEOW WOLF">
      {LETTER_IDS.map((id, i) => {
        const g = LOGO[id];
        const color = mono ?? g.color;
        return (
          // The outer <g> places the letter (SVG attribute); the inner one is free to animate with CSS transforms.
          <g key={id} transform={`translate(${g.cx * LOGO_VIEW.w - 400 * S} ${g.cy * LOGO_VIEW.h - 400 * S}) scale(${S})`}>
            <g className={`wm-letter ${onLetter ? 'live' : ''} ${glitching?.has(id) ? 'glitch' : ''}`}
              style={{ ['--i' as string]: i, ['--lc' as string]: color }}
              onPointerDown={onLetter ? () => onLetter(id) : undefined}>
              <path d={g.d} fill={color} style={{ filter: `drop-shadow(0 0 ${14 / S}px ${color})` }} />
            </g>
          </g>
        );
      })}
    </svg>
  );
}
