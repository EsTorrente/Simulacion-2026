import { useEffect, useRef, useState } from 'react';
import type { GameState, PlayerRole } from '../../game/types';
import type { StateAdapter } from '../../game/stateAdapter';

/** Both players must press "We're done". Says what happens, who is ready, and lets either player take it back. */
export default function FinishPanel({ role, state, adapter }: { role: PlayerRole; state: GameState; adapter: StateAdapter }) {
  const mine = role === 'Cat' ? state.catConfirmed : state.wolfConfirmed;
  const theirs = role === 'Cat' ? state.wolfConfirmed : state.catConfirmed;
  const other: PlayerRole = role === 'Cat' ? 'Wolf' : 'Cat';
  const otherAway = !state.players[other].connected;
  const empty = Object.values(state.letters).every(a => a.length === 0) && Object.values(state.stickers).every(a => a.length === 0);

  // If my "ready" disappears without me cancelling, the artwork changed: tell me why (inline, for a few seconds).
  const [note, setNote] = useState('');
  const was = useRef(mine), cancelled = useRef(false);
  useEffect(() => {
    if (was.current && !mine && !cancelled.current && state.status === 'playing') setNote(role === 'Cat' ? 'You changed the artwork, so you both need to confirm again.' : 'The Cat changed the artwork, so you both need to confirm again.');
    if (mine) setNote('');
    was.current = mine; cancelled.current = false;
  }, [mine]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!note) return; const t = window.setTimeout(() => setNote(''), 7000); return () => clearTimeout(t); }, [note]);

  const row = (label: string, on: boolean, away = false) => (
    <li className={`ready ${on ? 'on' : ''} ${away ? 'away' : ''}`}>
      <i aria-hidden />{label}<b>{away ? 'away' : on ? 'ready' : 'not ready'}</b>
    </li>
  );
  return (
    <section className="mw-panel finish" aria-label="Finish the artwork">
      <h3>Finish the artwork</h3>
      <p className="muted first">When you both agree, the sign comes alive and a world grows from your colors and stickers.</p>
      <ul className="ready-list" aria-live="polite">{row('You', mine)}{row(`The ${other}`, theirs, otherAway)}</ul>
      {mine
        ? <button className="btn" onClick={() => { cancelled.current = true; adapter.cancelFinish(role); }}>Not yet. Keep working</button>
        : <button className="btn primary" onClick={() => adapter.confirmFinish(role)}>We&rsquo;re done</button>}
      {mine && !theirs && <p className="muted" role="status">{otherAway ? `The ${other} is away. You can wait, or take your “done” back.` : `Waiting for the ${other}…`}</p>}
      {!mine && theirs && <p className="muted" role="status">The {other} is ready and waiting for you.</p>}
      {!mine && !theirs && empty && role === 'Cat' && <p className="muted">Nothing drawn yet. The world will be bare.</p>}
      {note && <p className="note" role="status">{note}</p>}
    </section>
  );
}
