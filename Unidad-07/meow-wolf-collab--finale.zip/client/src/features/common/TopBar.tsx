import { useEffect, useState, type ReactNode } from 'react';
import SoundControl from './SoundControl';

interface Props {
  icon: ReactNode; title: string; tagline: string;
  onIcon?: () => void;           // easter egg: clicking the mascot
  children?: ReactNode;          // status widgets (lives, counters, presence)
  onHelp?: () => void; onExit: () => void;
}

/** The top bar shared by the Cat and the Wolf screens. Exit needs a second click so it can't be hit by accident. */
export default function TopBar({ icon, title, tagline, onIcon, children, onHelp, onExit }: Props) {
  const [sure, setSure] = useState(false);
  useEffect(() => { if (!sure) return; const t = window.setTimeout(() => setSure(false), 2500); return () => clearTimeout(t); }, [sure]);
  return (
    <header className="top-bar">
      <h2><button className="mascot" aria-label={`${title} (click me)`} onClick={onIcon}>{icon}</button>{title}</h2>
      <div className="tagline">{tagline}</div>
      <div className="top-status">{children}</div>
      <div className="top-actions">
        {onHelp && <button className="icon-btn" onClick={onHelp} aria-label="How to play" title="How to play">?</button>}
        <SoundControl />
        <button className={`btn small ${sure ? 'danger-on' : ''}`} onClick={() => (sure ? onExit() : setSure(true))}>{sure ? 'Sure? Leave' : 'Leave'}</button>
      </div>
    </header>
  );
}
