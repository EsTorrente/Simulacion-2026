import type { LetterID } from '../../game/types';
import { LOGO } from '../../../../shared/logo';
import { nearestLetter, compToLetterPoint, letterPointToComp } from '../../../../shared/composition';

// Real glyph hit-testing (Path2D on a 1x1 scratch canvas), so overlapping letter cells still pick the right letter.
const paths: Partial<Record<LetterID, Path2D>> = {};
let ctx: CanvasRenderingContext2D | null = null;
const inGlyph = (id: LetterID, x: number, y: number) => {
  ctx ??= document.createElement('canvas').getContext('2d');
  if (!ctx) return false;
  paths[id] ??= new Path2D(LOGO[id].d);
  return ctx.isPointInPath(paths[id]!, x, y);
};

/** Letter under a composition point (0..1). */
export const pickLetter = (x: number, y: number) => nearestLetter(x, y, inGlyph);
/** Letter that owns a point given in another letter's space (used by the Cat's canvas to hand over to a neighbour). */
export const ownerOfLetterPoint = (id: LetterID, lx: number, ly: number) => {
  const c = letterPointToComp(id, lx, ly);
  return pickLetter(c.x, c.y);
};
export { compToLetterPoint };

/** The letter whose actual shape contains this composition point, or null (used by the finale's logo hover). */
export const letterAtComp = (x: number, y: number): LetterID | null => {
  for (const id of Object.keys(LOGO) as LetterID[]) {
    const p = compToLetterPoint(id, x, y);
    if (inGlyph(id, p.x, p.y)) return id;
  }
  return null;
};

/** Is this letter-space point on the letter's shape, or within `pad` units of its edge? Used to keep the brush on its own letter. */
export const nearGlyph = (id: LetterID, x: number, y: number, pad: number) => {
  ctx ??= document.createElement('canvas').getContext('2d');
  if (!ctx) return true;
  paths[id] ??= new Path2D(LOGO[id].d);
  if (ctx.isPointInPath(paths[id]!, x, y)) return true;
  ctx.lineWidth = pad * 2;
  return ctx.isPointInStroke(paths[id]!, x, y);
};
