import { useEffect, useRef } from 'react';
import type { LetterID, PlacedSticker, Stroke } from '../../game/types';
import { boilAmplitude, boilOffset, useBoilPose } from '../../game/boil';
import LetterGuide from './LetterGuide';
import { StickerLayer } from './stickerArt';

/** Draws strokes on an 800x800 logical canvas. pose/amp add the boil wobble (data is untouched). */
export function paintStrokes(ctx: CanvasRenderingContext2D, strokes: Stroke[], pose = 0, amp = 0, minWidth = 0) {
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  for (const { points: pts, color, brushSize } of strokes) {
    if (pts.length === 0) continue;
    const w = Math.max(brushSize, minWidth);
    if (pts.length === 1) {
      ctx.beginPath(); ctx.fillStyle = color;
      ctx.arc(pts[0].x, pts[0].y, w / 2, 0, Math.PI * 2); ctx.fill();
      continue;
    }
    const seed = pts[0].x * 0.013 + pts[0].y * 0.017;
    ctx.beginPath(); ctx.strokeStyle = color; ctx.lineWidth = w;
    pts.forEach((p, i) => {
      const o = amp ? boilOffset(i, seed, pose, amp) : { dx: 0, dy: 0 };
      if (i === 0) ctx.moveTo(p.x + o.dx, p.y + o.dy); else ctx.lineTo(p.x + o.dx, p.y + o.dy);
    });
    ctx.stroke();
  }
}

interface Props { strokes: Stroke[]; stickers: PlacedSticker[]; letter: LetterID; selected?: boolean; size?: number; bare?: boolean; }

/** Read-only letter tile for the Wolf. Same guide + coordinates as the Cat's canvas. */
export default function StrokePreview({ strokes, stickers, letter, selected, size, bare }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const pose = useBoilPose();
  useEffect(() => {
    const ctx = ref.current?.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(0.5, 0, 0, 0.5, 0, 0); // 400px backing canvas for 800 logical units (cheaper to redraw)
    ctx.clearRect(0, 0, 800, 800);
    paintStrokes(ctx, strokes, pose, boilAmplitude(), 12); // min width keeps thin lines visible when small
  }, [strokes, pose]);
  return (
    <div style={{ position: 'relative', width: size ?? '100%', height: size ?? '100%', border: bare ? 'none' : '1px solid var(--accent, var(--color-gray))' }}>
      <LetterGuide id={letter} selected={selected} />
      <canvas ref={ref} width={400} height={400} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
      <StickerLayer stickers={stickers} />
    </div>
  );
}
