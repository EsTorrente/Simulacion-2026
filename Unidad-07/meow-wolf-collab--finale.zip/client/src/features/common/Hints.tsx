import { useState } from 'react';

const key = (id: string) => `mw-hint-${id}`;
const read = (id: string) => { try { return localStorage.getItem(key(id)) === 'seen'; } catch { return false; } };
const write = (id: string) => { try { localStorage.setItem(key(id), 'seen'); } catch { /* private mode: it just shows again */ } };

/** First-time guidance: open until dismissed once (remembered), reopenable from the "?" button. */
export function useHint(id: string) {
  const [open, setOpen] = useState(() => !read(id));
  return { open, show: () => setOpen(true), dismiss: () => { write(id); setOpen(false); } };
}

export function HintCard({ title, steps, onClose }: { title: string; steps: { icon: string; text: React.ReactNode }[]; onClose: () => void }) {
  return (
    <section className="mw-panel hint" aria-label={title}>
      <h3><span>{title}</span><button className="icon-btn tiny" onClick={onClose} aria-label="Dismiss hints">✕</button></h3>
      <ol>{steps.map((s, i) => <li key={i}><span className="hint-ico" aria-hidden>{s.icon}</span><span>{s.text}</span></li>)}</ol>
      <button className="btn small primary" onClick={onClose}>Got it</button>
    </section>
  );
}
