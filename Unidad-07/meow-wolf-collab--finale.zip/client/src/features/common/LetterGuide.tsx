// The real logo outline for one letter, drawn in the SAME 800x800 letter space as strokes and stickers,
// so the Cat's big canvas and the Wolf's small previews always match at any size.
// Paths come from the official logo PNG (shared/logo.ts); nothing here is a font.
import type { LetterID } from '../../game/types';
import { LOGO } from '../../../../shared/logo';

interface Props { id: LetterID; selected?: boolean; }

export default function LetterGuide({ id, selected }: Props) {
  const g = LOGO[id];
  return (
    <svg viewBox="0 0 800 800" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', overflow: 'visible',
      filter: `drop-shadow(0 0 ${selected ? 7 : 3}px ${g.color})` }}>
      <path d={g.d} fill={g.color} opacity={selected ? 0.16 : 0.07} />
      <path d={g.d} fill="none" stroke={g.color} strokeWidth={selected ? 7 : 5} strokeLinecap="round" strokeLinejoin="round"
        strokeDasharray="0.1 15" opacity={selected ? 1 : 0.75} />
    </svg>
  );
}
