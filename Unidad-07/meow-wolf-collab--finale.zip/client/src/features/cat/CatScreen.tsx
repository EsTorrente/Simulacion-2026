import { useEffect, useRef, useState } from 'react';
import type { LetterID } from '../../game/types';
import type { StateAdapter } from '../../game/stateAdapter';
import { useGameState } from '../../game/useAdapter';
import DrawingCanvas from './DrawingCanvas';
import StickerEditor from './StickerEditor';
import FinishPanel from '../common/FinishPanel';
import TopBar from '../common/TopBar';
import { HintCard, useHint } from '../common/Hints';
import { sfx } from '../../game/audio';
import Composition from '../common/Composition';
import { STICKERS } from '../common/stickerArt';
import { LOGO } from '../../../../shared/logo';

const LETTERS: LetterID[] = ['M', 'E', 'O1', 'W1', 'W2', 'O2', 'L', 'F'];

const Ico = ({ d, size = 22 }: { d: string; size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
);
const ICON = {
  brush: 'M18.4 2.6a2 2 0 0 1 2.8 2.8L10 16.6 6 17.5l.9-4zM6 17.5c0 2.5-1.5 3.5-4 3.5 2 0 6 0 6-3.5',
  star: 'M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z',
  undo: 'M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3',
  redo: 'M15 14l5-5-5-5M20 9H10a6 6 0 0 0 0 12h3',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6',
};
export function CatIcon({ size = 34 }: { size?: number }) {
  return (
    <svg viewBox="-26 -26 52 52" width={size} height={size} style={{ filter: 'drop-shadow(0 0 5px #ff2d9b)' }}>
      <path d="M-19 8 L-20 -22 L-7 -12 L7 -12 L20 -22 L19 8 C19 18 8 22 0 22 C-8 22 -19 18 -19 8Z" fill="#1a0615" stroke="#ff2d9b" strokeWidth="2.6" strokeLinejoin="round" />
      <path d="M-12 -2 Q-8 -6 -4 -2 M12 -2 Q8 -6 4 -2" stroke="#ff2d9b" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      <path d="M-3 8 H3 L0 12Z" fill="#ff2d9b" /><path d="M-14 6 H-24 M-14 10 L-23 14 M14 6 H24 M14 10 L23 14" stroke="#ff2d9b" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

export default function CatScreen({ adapter, onExit }: { adapter: StateAdapter; onExit: () => void }) {
  const gameState = useGameState(adapter);
  const [activeLetter, setActiveLetter] = useState<LetterID>('M');
  const [activeColor, setActiveColor] = useState<string>('#ff007f');
  const [tool, setTool] = useState<'draw' | 'sticker'>('draw');
  const [armedKind, setArmedKind] = useState<string | null>(null); // sticker type waiting to be placed
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [brush, setBrush] = useState(14);
  const [confirmClear, setConfirmClear] = useState(false);
  const justPlaced = useRef(false);
  const hint = useHint('cat');
  const [purr, setPurr] = useState('');
  const stickers = gameState?.stickers[activeLetter] ?? [];
  const prevCount = useRef(0);

  // After placing, select the new sticker once the server confirms it.
  useEffect(() => {
    if (justPlaced.current && stickers.length > prevCount.current) {
      setSelectedId(stickers[stickers.length - 1].id); justPlaced.current = false;
    }
    prevCount.current = stickers.length;
  }, [stickers]);
  useEffect(() => { setSelectedId(null); setConfirmClear(false); }, [activeLetter]);
  useEffect(() => { if (!purr) return; const t = window.setTimeout(() => setPurr(''), 2400); return () => clearTimeout(t); }, [purr]);
  useEffect(() => { if (!confirmClear) return; const t = window.setTimeout(() => setConfirmClear(false), 2500); return () => clearTimeout(t); }, [confirmClear]);

  const selected = stickers.find(s => s.id === selectedId) ?? null;
  const remove2 = (id: string) => { adapter.removeSticker(activeLetter, id); setSelectedId(null); };
  const remove = () => { if (selected) remove2(selected.id); };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.target as HTMLElement | null)?.tagName !== 'INPUT') {
        const k = e.key.toLowerCase();
        if (k === 'z') { e.preventDefault(); if (e.shiftKey) adapter.redo(activeLetter); else adapter.undo(activeLetter); return; }
        if (k === 'y') { e.preventDefault(); adapter.redo(activeLetter); return; }
      }
      if (tool !== 'sticker') return;
      if ((e.key === 'Delete' || e.key === 'Backspace') && selected) remove();
      if (e.key === 'Escape') { if (armedKind) setArmedKind(null); else setSelectedId(null); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (!gameState) return null;
  const tweak = (patch: { scale?: number; rotation?: number }) => {
    if (!selected) return;
    const scale = Math.min(3, Math.max(0.3, selected.scale * (patch.scale ?? 1)));
    const rotation = Math.max(-360, Math.min(360, selected.rotation + (patch.rotation ?? 0)));
    adapter.updateSticker(activeLetter, selected.id, { x: selected.x, y: selected.y, scale, rotation });
  };

  const allStickerKinds = gameState.collectibles.filter(c => c.type === 'sticker').map(c => c.value);
  const colorSlots = 1 + gameState.collectibles.filter(c => c.type === 'color').length;
  const unlockedCount = gameState.unlockedStickers.length + gameState.unlockedColors.length - 1;
  const totalCount = allStickerKinds.length + colorSlots - 1;
  const wolfOnline = gameState.players.Wolf.connected;
  const pickTool = (t: 'draw' | 'sticker') => { setTool(t); if (t === 'draw') setArmedKind(null); };
  const letterName = activeLetter.replace(/\d/, '');
  const hist = gameState.history?.[activeLetter] ?? { undo: 0, redo: 0 };
  const hasInk = gameState.letters[activeLetter].length > 0;

  return (
    <div className="screen-container theme-cat">
      <TopBar icon={<CatIcon />} title="CAT" tagline={purr || 'Draw, place stickers, make it yours.'} onHelp={hint.show} onExit={onExit}
        onIcon={() => { sfx.meow(); setPurr(['mrrp.', 'purrrr…', 'the Cat is judging your brushwork.', 'you may pet the Cat. once.'][Math.floor(Math.random() * 4)]); }}>
        <span className="mw-pill" style={{ ['--accent' as string]: wolfOnline ? '#7CFF6B' : '#888' }} title={wolfOnline ? 'The Wolf is in the halls' : 'The Wolf is away'}>● {wolfOnline ? 'Wolf connected' : 'Wolf away'}</span>
      </TopBar>

      <div className="cat-body">
        {/* tool rail */}
        <div className="cat-rail" role="toolbar" aria-label="Tools">
          <button className={`rail-btn ${tool === 'draw' ? 'on' : ''}`} onClick={() => pickTool('draw')} title="Draw"><Ico d={ICON.brush} /><span>Draw</span></button>
          <button className={`rail-btn ${tool === 'sticker' ? 'on' : ''}`} onClick={() => pickTool('sticker')} title="Stickers: place, move, resize, rotate"><Ico d={ICON.star} /><span>Stickers</span></button>
          <div className="rail-sep" />
          <button className="rail-btn" disabled={!hist.undo} onClick={() => adapter.undo(activeLetter)} title={`Undo on letter ${letterName} (Ctrl+Z)`} aria-label="Undo"><Ico d={ICON.undo} /><span>Undo</span></button>
          <button className="rail-btn" disabled={!hist.redo} onClick={() => adapter.redo(activeLetter)} title="Redo (Ctrl+Shift+Z)" aria-label="Redo"><Ico d={ICON.redo} /><span>Redo</span></button>
          <div style={{ flex: 1 }} />
          <button className={`rail-btn danger ${confirmClear ? 'on' : ''}`} title={`Clear the drawing on letter ${letterName} (Undo brings it back)`} disabled={!hasInk}
            onClick={() => { if (confirmClear) { adapter.clearLetter(activeLetter); setConfirmClear(false); } else setConfirmClear(true); }}>
            <Ico d={ICON.trash} /><span>{confirmClear ? 'Sure?' : 'Clear'}</span>
          </button>
        </div>

        <div className="cat-center">
          {/* stage: the whole MEOW WOLF composition. Click a letter to edit it. */}
          <div className="stage">
            <Composition
              letters={gameState.letters}
              stickers={gameState.stickers}
              selected={activeLetter}
              onSelect={id => { setActiveLetter(id); }}
              style={{ width: 'min(90cqw, 180cqh)' }}
              editing={<>
                <DrawingCanvas
                  letterId={activeLetter}
                  strokes={gameState.letters[activeLetter]}
                  currentColor={activeColor}
                  brushSize={brush}
                  enabled={tool === 'draw'}
                  onSwitch={setActiveLetter}
                  onAddStroke={(s) => adapter.addStroke(activeLetter, s)}
                />
                <StickerEditor
                  letterId={activeLetter}
                  onSwitch={setActiveLetter}
                  stickers={stickers}
                  active={tool === 'sticker'}
                  armedKind={armedKind}
                  selectedId={selectedId}
                  onSelect={setSelectedId}
                  onPlace={(x, y) => { justPlaced.current = true; adapter.addSticker(activeLetter, { kind: armedKind!, x, y, scale: 1.6, rotation: 0 }); }}
                  onUpdate={(id, p) => adapter.updateSticker(activeLetter, id, p)}
                  onRemove={remove2}
                />
              </>}
            />
            <div className="stage-hint">
              <b style={{ color: LOGO[activeLetter].color }}>Letter {letterName}</b>
              {tool === 'draw' ? ' · drag to draw · click another letter to switch' : armedKind ? ' · click the letter to place the sticker' : selected ? ' · drag to move · ◻ resize · ○ rotate · ✕ delete' : ' · pick a sticker below, or click one on the letter'}
            </div>
          </div>

          {/* letters + sticker tray */}
          <div className="cat-tray">
            <div className="tray-group" role="tablist" aria-label="Letters" onKeyDown={e => {
              const i = LETTERS.indexOf(activeLetter), d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
              if (!d) return; e.preventDefault();
              const next = LETTERS[(i + d + LETTERS.length) % LETTERS.length]; setActiveLetter(next);
              (e.currentTarget.querySelectorAll('button')[LETTERS.indexOf(next)] as HTMLElement | undefined)?.focus();
            }}>
              {LETTERS.map(id => {
                const g = LOGO[id], [x0, y0, x1, y1] = g.bbox, used = gameState.letters[id].length + gameState.stickers[id].length > 0;
                return (
                  <button key={id} role="tab" tabIndex={activeLetter === id ? 0 : -1} aria-selected={activeLetter === id} className={`letter-chip ${activeLetter === id ? 'on' : ''}`}
                    style={{ ['--lc' as string]: g.color }} onClick={() => setActiveLetter(id)} aria-label={`Letter ${id.replace(/\d/, '')}${used ? ' (has artwork)' : ''}`} title={`Letter ${id.replace(/\d/, '')}`}>
                    <svg viewBox={`${x0 - 14} ${y0 - 14} ${x1 - x0 + 28} ${y1 - y0 + 28}`} width="34" height="28"><path d={g.d} fill={g.color} opacity={activeLetter === id ? 1 : 0.55} /></svg>
                    {used && <i className="chip-dot" />}
                  </button>
                );
              })}
            </div>
            <div className="tray-sep" />
            <div className="tray-group" aria-label="Sticker inventory">
              {allStickerKinds.map(kind => {
                const open = gameState.unlockedStickers.includes(kind);
                const Art = (STICKERS[kind] ?? STICKERS.skull).Art;
                return open ? (
                  <button key={kind} className={`sticker-slot ${armedKind === kind ? 'on' : ''}`} title={`${STICKERS[kind]?.label ?? kind} — click, then click the letter`}
                    onClick={() => { setTool('sticker'); setArmedKind(armedKind === kind ? null : kind); }}>
                    <svg viewBox="-55 -55 110 110" width="38" height="38"><Art /></svg>
                  </button>
                ) : (
                  <div key={kind} className="sticker-slot locked" title="The Wolf hasn't found this one yet">🔒</div>
                );
              })}
            </div>
          </div>
        </div>

        {/* side panels */}
        <div className="cat-side">
          <div className="side-scroll">
      {hint.open && (
        <HintCard title="How to paint the sign" onClose={hint.dismiss} steps={[
          { icon: '①', text: <>Pick a <b>letter</b>: click it on the sign, or use the chips underneath.</> },
          { icon: '✎', text: <><b>Draw</b> with the mouse, finger or pen. Size and color are on the right. <b>Ctrl+Z</b> undoes.</> },
          { icon: '★', text: <><b>Stickers and colors</b> arrive when the Wolf finds them. Locked slots show what is still out there.</> },
          { icon: '✔', text: <>When you are happy, press <b>We&rsquo;re done</b>. The Wolf has to agree too.</> },
        ]} />
      )}
          <div className="mw-panel">
            <h3 style={{ display: 'flex', justifyContent: 'space-between' }}><span>Inventory</span><span>{unlockedCount}/{totalCount}</span></h3>
            <div className="mini-bar"><i style={{ width: `${totalCount ? (unlockedCount / totalCount) * 100 : 0}%` }} /></div>
            <p className="muted">{unlockedCount < totalCount ? 'The Wolf is out there collecting more…' : 'Everything found!'}</p>
          </div>

          <div className="mw-panel">
            <h3>Color</h3>
            <div className="swatches">
              {gameState.unlockedColors.map(color => (
                <button key={color} aria-label={`Color ${color}`} className={`swatch ${activeColor === color && tool === 'draw' ? 'on' : ''}`}
                  style={{ ['--c' as string]: color }} onClick={() => { setActiveColor(color); pickTool('draw'); }} />
              ))}
              {Array.from({ length: Math.max(0, colorSlots - gameState.unlockedColors.length) }, (_, i) => <div key={i} className="swatch locked" title="Not found yet">?</div>)}
            </div>
          </div>

          <div className="mw-panel">
            <h3>Brush</h3>
            <svg viewBox="0 0 200 50" width="100%" height="50" aria-hidden><path d="M8 34 C40 6 70 6 100 28 S160 46 192 14" fill="none" stroke={activeColor} strokeWidth={Math.max(1.5, brush / 2.2)} strokeLinecap="round" style={{ filter: `drop-shadow(0 0 5px ${activeColor})` }} /></svg>
            <label className="muted" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>Size
              <input type="range" min={4} max={40} value={brush} onChange={e => setBrush(+e.target.value)} style={{ flex: 1, accentColor: activeColor }} aria-label="Brush size" />
            </label>
          </div>

          {tool === 'sticker' && (
            <div className="mw-panel">
              <h3>{selected ? `Selected: ${STICKERS[selected.kind]?.label ?? selected.kind}` : armedKind ? `Placing: ${STICKERS[armedKind]?.label}` : 'Stickers'}</h3>
              {selected ? (
                <div className="tweak-row">
                  <button title="Smaller" onClick={() => tweak({ scale: 0.85 })}>−</button>
                  <button title="Bigger" onClick={() => tweak({ scale: 1.18 })}>+</button>
                  <button title="Rotate left" onClick={() => tweak({ rotation: -15 })}>⟲</button>
                  <button title="Rotate right" onClick={() => tweak({ rotation: 15 })}>⟳</button>
                  <button className="danger" title="Delete (Del)" onClick={remove}>Delete</button>
                </div>
              ) : <p className="muted">{armedKind ? 'Click the letter to place it — you can place several. Esc when done.' : 'Choose a sticker from the tray, or click one on the letter to edit it.'}</p>}
              {armedKind && <button style={{ marginTop: 8, width: '100%' }} onClick={() => setArmedKind(null)}>Done placing</button>}
            </div>
          )}

          </div>
          <FinishPanel role="Cat" state={gameState} adapter={adapter} />
        </div>
      </div>
    </div>
  );
}
