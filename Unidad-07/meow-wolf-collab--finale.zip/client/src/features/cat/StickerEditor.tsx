import { useEffect, useRef, useState } from 'react';
import type { LetterID, PlacedSticker, StickerPlacement } from '../../game/types';
import { ownerOfLetterPoint } from '../common/glyphHit';
import { StickerShape } from '../common/stickerArt';

interface Props {
  letterId: LetterID;
  onSwitch: (id: LetterID) => void;
  stickers: PlacedSticker[];
  active: boolean;                       // sticker tool on?
  armedKind: string | null;              // sticker type that a click on empty space will place
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onPlace: (x: number, y: number) => void;
  onUpdate: (id: string, p: StickerPlacement) => void;
  onRemove: (id: string) => void;
}

const R_BASE = 70; // selection circle radius at scale 1, in letter units (800 per letter)
const clamp = (n: number, a: number, b: number) => Math.min(b, Math.max(a, n));
type Live = StickerPlacement & { id: string };
type Drag = { id: string; mode: 'move' | 'scale' | 'rotate' };

/**
 * Sticker layer over the selected letter. Selecting a sticker shows an outline with three handles:
 * ✕ delete (top right), ● resize (bottom right), ◯ rotate (on a stalk above). The handles exist
 * only here, so they never appear on the Wolf's screen or in the finale.
 * Handle sizes are measured in screen pixels so they stay finger-sized on small screens.
 */
export default function StickerEditor({ letterId, onSwitch, stickers, active, armedKind, selectedId, onSelect, onPlace, onUpdate, onRemove }: Props) {
  const svg = useRef<SVGSVGElement>(null);
  const drag = useRef<Drag | null>(null);
  const [live, setLive] = useState<Live | null>(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const el = svg.current; if (!el) return;
    const ro = new ResizeObserver(() => setWidth(el.getBoundingClientRect().width));
    ro.observe(el); return () => ro.disconnect();
  }, []);
  useEffect(() => { if (!drag.current) setLive(null); }, [stickers]); // the server's version replaces our preview

  const px = width > 0 ? 800 / width : 1; // letter units per screen pixel
  const toLetter = (e: React.PointerEvent) => {
    const r = svg.current!.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * 800, y: ((e.clientY - r.top) / r.height) * 800 };
  };
  const current = (s: PlacedSticker): PlacedSticker => (live && live.id === s.id ? { ...s, ...live } : s);

  const onDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!active) return;
    const target = (e.target as Element).closest('[data-h],[data-sticker-id]');
    const handle = target?.getAttribute('data-h');
    if (handle === 'delete' && selectedId) { onRemove(selectedId); return; }
    if ((handle === 'scale' || handle === 'rotate') && selectedId) {
      drag.current = { id: selectedId, mode: handle }; svg.current!.setPointerCapture(e.pointerId); return;
    }
    const id = target?.getAttribute('data-sticker-id');
    if (id) { onSelect(id); drag.current = { id, mode: 'move' }; svg.current!.setPointerCapture(e.pointerId); return; }
    // Cells overlap, so a click on a neighbouring letter's shape switches to that letter instead of
    // attaching a sticker to this one while it visibly sits on another letter.
    const p = toLetter(e), owner = ownerOfLetterPoint(letterId, p.x, p.y);
    if (owner !== letterId) { onSwitch(owner); return; }
    if (armedKind) onPlace(clamp(p.x / 800, 0, 1), clamp(p.y / 800, 0, 1));
    else onSelect(null);
  };

  const onMove = (e: React.PointerEvent<SVGSVGElement>) => {
    const d = drag.current; if (!d) return;
    const s = stickers.find(st => st.id === d.id); if (!s) return;
    const base = current(s), p = toLetter(e), cx = base.x * 800, cy = base.y * 800;
    let next: StickerPlacement = { x: base.x, y: base.y, scale: base.scale, rotation: base.rotation };
    if (d.mode === 'move') next = { ...next, x: clamp(p.x / 800, 0, 1), y: clamp(p.y / 800, 0, 1) };
    else if (d.mode === 'scale') next = { ...next, scale: clamp(Math.hypot(p.x - cx, p.y - cy) / R_BASE, 0.3, 3) };
    else {
      let deg = (Math.atan2(p.y - cy, p.x - cx) * 180) / Math.PI + 90;
      if (deg > 180) deg -= 360;
      next = { ...next, rotation: deg };
    }
    setLive({ id: d.id, ...next });
  };

  const onUp = () => {
    const d = drag.current; drag.current = null;
    if (d && live && live.id === d.id) { const { id, ...p } = live; onUpdate(id, p); }
    else setLive(null);
  };

  const sel = stickers.find(s => s.id === selectedId);
  const cs = sel ? current(sel) : null;
  const R = cs ? R_BASE * cs.scale : 0;
  const ink = 'var(--color-acid)';

  return (
    <svg
      ref={svg} viewBox="0 0 800 800"
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible', touchAction: 'none', pointerEvents: active ? 'auto' : 'none', cursor: armedKind ? 'copy' : 'default' }}
      onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}
    >
      {stickers.map(s => {
        const c = current(s);
        return (
          <g key={s.id} data-sticker-id={s.id} style={{ cursor: 'grab' }}>
            <StickerShape s={s} override={live?.id === s.id ? live : undefined} />
            <circle cx={c.x * 800} cy={c.y * 800} r={R_BASE * c.scale} fill="transparent" />
          </g>
        );
      })}
      {active && cs && (
        <g transform={`translate(${cs.x * 800} ${cs.y * 800}) rotate(${cs.rotation})`}>
          <circle r={R} fill="none" stroke={ink} strokeWidth={2 * px} strokeDasharray={`${8 * px} ${6 * px}`} pointerEvents="none" />
          <line x1="0" y1={-R} x2="0" y2={-R - 26 * px} stroke={ink} strokeWidth={2 * px} pointerEvents="none" />
          <g data-h="rotate" style={{ cursor: 'grab' }}>
            <circle cx="0" cy={-R - 26 * px} r={20 * px} fill="transparent" />
            <circle cx="0" cy={-R - 26 * px} r={9 * px} fill="#09090b" stroke={ink} strokeWidth={2.5 * px} />
          </g>
          <g data-h="scale" transform={`translate(${R * 0.7071} ${R * 0.7071})`} style={{ cursor: 'nwse-resize' }}>
            <circle r={20 * px} fill="transparent" />
            <rect x={-8 * px} y={-8 * px} width={16 * px} height={16 * px} fill={ink} stroke="#09090b" strokeWidth={2 * px} />
          </g>
          <g data-h="delete" transform={`translate(${R * 0.7071} ${-R * 0.7071})`} style={{ cursor: 'pointer' }}>
            <circle r={20 * px} fill="transparent" />
            <circle r={11 * px} fill="#ff007f" stroke="#09090b" strokeWidth={2 * px} />
            <path d={`M${-5 * px} ${-5 * px}L${5 * px} ${5 * px}M${5 * px} ${-5 * px}L${-5 * px} ${5 * px}`} stroke="#fff" strokeWidth={2.5 * px} strokeLinecap="round" />
          </g>
        </g>
      )}
    </svg>
  );
}
