import { useRef, useEffect, useState } from 'react';
import { LetterID, Stroke, Point } from '../../game/types';
import { boilAmplitude, useBoilPose } from '../../game/boil';
import { paintStrokes } from '../common/StrokePreview';
import { nearGlyph, ownerOfLetterPoint } from '../common/glyphHit';

interface Props {
  letterId: LetterID;
  strokes: Stroke[];
  currentColor: string;
  onAddStroke: (stroke: Stroke) => void;
  enabled?: boolean; // false while the Cat is placing stickers
  brushSize?: number;
  onSwitch?: (id: LetterID) => void; // the pointer went down on a neighbouring letter's glyph (cells overlap)
}

const DEFAULT_BRUSH = 14; // logical units (800 per letter); the Cat can change it with the size slider

export default function DrawingCanvas({ letterId, strokes, currentColor, onAddStroke, enabled = true, onSwitch, brushSize = DEFAULT_BRUSH }: Props) {
  const pose = useBoilPose();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  // The ref is the source of truth while drawing (always current, even between renders).
  // The state copy only exists to trigger a re-render for the live preview.
  const pointsRef = useRef<Point[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [livePoints, setLivePoints] = useState<Point[]>([]);
  // The server confirms strokes a moment after pointer-up. Show the stroke meanwhile so it
  // doesn't flicker; it is dropped as soon as the real list updates (or after 1.5s if rejected).
  const [pending, setPending] = useState<Stroke[]>([]);
  const seen = useRef({ letterId, n: strokes.length });
  useEffect(() => {
    // Each confirmed stroke retires one pending stroke (a drag that leaves the letter is sent as several strokes).
    const prev = seen.current; seen.current = { letterId, n: strokes.length };
    const grew = prev.letterId === letterId ? strokes.length - prev.n : 0;
    setPending(p => (grew > 0 ? p.slice(grew) : []));
  }, [strokes, letterId]);
  useEffect(() => {
    if (!pending.length) return;
    const t = window.setTimeout(() => setPending([]), 1500);
    return () => window.clearTimeout(t);
  }, [pending]);

  // Render all strokes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const drawStroke = (pts: Point[], color: string, size: number) => {
      if (pts.length === 0) return;
      if (pts.length === 1) {
        // A single click becomes a dot
        ctx.beginPath();
        ctx.fillStyle = color;
        ctx.arc(pts[0].x, pts[0].y, size / 2, 0, Math.PI * 2);
        ctx.fill();
        return;
      }
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) {
        ctx.lineTo(pts[i].x, pts[i].y);
      }
      ctx.stroke();
    };

    // Saved strokes boil; the stroke being drawn right now stays exact.
    paintStrokes(ctx, pending.length ? [...strokes, ...pending] : strokes, pose, boilAmplitude());
    if (isDrawing) drawStroke(livePoints, currentColor, brushSize);
  }, [strokes, pending, isDrawing, livePoints, currentColor, letterId, pose]);

  const getCoordinates = (e: React.PointerEvent<HTMLCanvasElement>): Point => {
    const canvas = e.currentTarget;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const first = getCoordinates(e);
    const owner = ownerOfLetterPoint(letterId, first.x, first.y);
    if (owner !== letterId && onSwitch) { onSwitch(owner); return; }
    if (!nearGlyph(letterId, first.x, first.y, brushSize / 2 + 14)) return; // empty space around the letter: nothing to paint on
    e.currentTarget.setPointerCapture(e.pointerId);
    pointsRef.current = [first];
    setLivePoints(pointsRef.current);
    setIsDrawing(true);
  };

  // The brush stays on its own letter: leaving the shape (plus a little slack for the brush's width) ends the stroke,
  // coming back in starts a new one. Cells overlap, so this keeps paint from landing on a neighbour's shape.
  const onShape = (p: Point) => nearGlyph(letterId, p.x, p.y, brushSize / 2 + 14);
  const commit = () => {
    const pts = pointsRef.current;
    if (pts.length > 0) {
      const stroke = { points: pts, color: currentColor, brushSize: brushSize };
      setPending(p => [...p, stroke]);
      onAddStroke(stroke);
    }
    pointsRef.current = [];
    setLivePoints([]);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const p = getCoordinates(e);
    if (onShape(p)) { pointsRef.current = [...pointsRef.current, p]; setLivePoints(pointsRef.current); }
    else if (pointsRef.current.length) commit();
  };

  const finishStroke = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    commit();
  };

  return (
    <canvas
      ref={canvasRef} role="img" aria-label={`Drawing area for letter ${letterId.replace(/\d/, '')}`}
      width={800} // Logical resolution; CSS scales it but keeps it square
      height={800}
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', touchAction: 'none', cursor: 'crosshair', pointerEvents: enabled ? 'auto' : 'none' }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={finishStroke}
      onPointerCancel={finishStroke}
    />
  );
}
