import { useEffect, useRef, useState } from 'react';
import type { GameState, LetterID, PlayerRole, Role } from '../../game/types';
import type { ConnStatus } from '../../game/socketAdapter';
import Wordmark from '../common/Wordmark';
import SoundControl from '../common/SoundControl';
import { CatIcon } from '../cat/CatScreen';
import { WolfIcon } from '../wolf/Maze';
import { sfx } from '../../game/audio';

interface Props {
  solo?: boolean;               // ?mock=1: one browser plays both roles, no seats
  conn: ConnStatus;
  state: GameState | null;
  role: Role;
  onJoin: (r: PlayerRole) => void;
  onLeave: () => void;
}

// What the house whispers. Clicking the letters walks through them; nothing here matters to the game.
const WHISPERS = [
  'the hallway is longer than it was', 'someone repainted the door again', 'do not look at the wallpaper too long',
  'this room was not here yesterday', 'the lights hum a note you almost know', 'the fridge is open. it is always open',
  'you were already here', 'the sign is missing eight letters', 'there are more stairs going down than up',
  'it is warm behind the walls', 'mrrp', 'the carpet remembers your feet',
];
const TYPED: Record<string, { say: string; fx?: () => void }> = {
  meow: { say: 'mrrp. (the Cat heard that)', fx: sfx.meow }, wolf: { say: 'awooo… (something answered)', fx: sfx.howl },
  exit: { say: 'there is no exit. only the next room' }, help: { say: 'nobody is coming. but you have a friend in here' },
  house: { say: 'the house heard you say its name' },
};

const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export default function LobbyScreen({ solo, conn, state, role, onJoin, onLeave }: Props) {
  const [whisper, setWhisper] = useState('the house keeps adding rooms');
  const [glitch, setGlitch] = useState<ReadonlySet<LetterID>>(new Set());
  const [melt, setMelt] = useState(false);
  const [eyeShut, setEyeShut] = useState(false);
  const wi = useRef(0), typed = useRef('');
  const eyeRef = useRef<HTMLButtonElement>(null);
  const [look, setLook] = useState({ x: 0, y: 0 });

  const say = (s: string) => setWhisper(s);
  const poke = (id: LetterID) => {
    sfx.glitch(); say(WHISPERS[wi.current++ % WHISPERS.length]);
    setGlitch(g => new Set(g).add(id));
    window.setTimeout(() => setGlitch(g => { const n = new Set(g); n.delete(id); return n; }), 520);
  };
  // Typing a word anywhere in the lobby (not while a button has focus and is being pressed with Enter).
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key.length !== 1) return;
      typed.current = (typed.current + e.key.toLowerCase()).slice(-5);
      for (const [w, v] of Object.entries(TYPED)) if (typed.current.endsWith(w)) { say(v.say); v.fx?.(); typed.current = ''; }
    };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);
  // The eye follows the pointer.
  useEffect(() => {
    const m = (e: PointerEvent) => {
      const r = eyeRef.current?.getBoundingClientRect(); if (!r) return;
      const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2), d = Math.hypot(dx, dy) || 1;
      setLook({ x: (dx / d) * 6, y: (dy / d) * 4 });
    };
    window.addEventListener('pointermove', m); return () => window.removeEventListener('pointermove', m);
  }, []);
  const doNotPress = () => {
    sfx.howl(); say('you pressed it. the walls are soft now');
    if (!reduced()) { setMelt(true); window.setTimeout(() => setMelt(false), 3200); }
  };

  const seat = (r: PlayerRole): 'free' | 'mine' | 'taken' | 'away' => {
    if (solo) return 'free';
    if (role === r) return 'mine';
    const s = state?.players[r];
    return !s?.occupied ? 'free' : s.connected ? 'taken' : 'away';
  };
  const ready = solo || (conn === 'connected' && !!state);
  const bothTaken = !solo && state?.players.Cat.occupied && state?.players.Wolf.occupied && !role;
  const other: PlayerRole | null = role ? (role === 'Cat' ? 'Wolf' : 'Cat') : null;
  const where = typeof window !== 'undefined' ? window.location.origin : '';

  const card = (r: PlayerRole) => {
    const st = seat(r), isCat = r === 'Cat';
    const label = { free: 'Free', mine: 'You', taken: 'Taken', away: 'Away (reconnecting)' }[st];
    const disabled = !ready || (st !== 'free') || (!solo && role !== null);
    return (
      <button key={r} className={`role-card ${isCat ? 'cat' : 'wolf'} ${st}`} disabled={disabled} onClick={() => onJoin(r)} aria-label={`Play as the ${r}. Seat: ${label}`}>
        <span className="role-art">{isCat ? <CatIcon size={48} /> : <WolfIcon size={48} />}</span>
        <span className="role-name">THE {r.toUpperCase()}</span>
        <span className="role-job">{isCat
          ? 'Stays in the studio. Paints the lost sign and sticks things onto it.'
          : 'Runs the endless halls. Brings back colors and stickers. Four things in the dark are hungry.'}</span>
        <ul className="role-does">
          {isCat ? <><li>Draw on the 8 letters</li><li>Stickers &amp; colors come from the Wolf</li></> : <><li>Arrow keys, WASD, or touch</li><li>Don&rsquo;t get caught (3 lives)</li></>}
        </ul>
        <span className={`seat-chip ${st}`}><i />{label}</span>
      </button>
    );
  };

  return (
    <main className={`lobby ${melt ? 'melt' : ''}`}>
      <div className="lobby-fog" aria-hidden />
      <SoundControl floating="tr" />

      <Wordmark className="lobby-logo" onLetter={poke} glitching={glitch} />
      <p className="whisper" aria-live="polite">{whisper}</p>

      <p className="story">
        Behind the wallpaper there is a house that never finished being built. Its sign lost its letters somewhere in the halls.
        The Cat can paint them back, but cannot leave the studio. The Wolf can leave, and should not linger.
        <b> Put the sign back together. Something is listening.</b>
      </p>

      <div className="roles">{card('Cat')}{card('Wolf')}</div>

      <div className="lobby-status" role="status" aria-live="polite">
        {solo ? <span className="chip ok"><i />Solo test mode: one browser plays both roles. Pick one to start.</span>
          : !state && conn !== 'connected' ? <span className="chip wait"><i />Looking for the server…</span>
          : role ? <span className="chip wait"><i />You are the {role}. Waiting for the {other} to arrive<span className="dots" aria-hidden /></span>
          : bothTaken ? <span className="chip warn"><i />Both seats are taken. A game is already in progress.</span>
          : <span className="chip ok"><i />Server found. Pick a seat. The game starts when both seats are filled.</span>}
        {role && !solo && <button className="btn small" onClick={onLeave}>Leave seat</button>}
      </div>

      {!solo && role && (
        <p className="join-tip">On the other computer open <code>{where}</code> and take the {other} seat.</p>
      )}
      {!solo && !role && state && !bothTaken && <p className="join-tip">Playing on two computers? Open <code>{where}</code> on both and pick different seats.</p>}

      <button ref={eyeRef} className={`peeper ${eyeShut ? 'shut' : ''}`} aria-label="A small eye in the corner" title="…"
        onClick={() => { setEyeShut(true); sfx.blip(); say('it saw you. it pretends it did not'); window.setTimeout(() => setEyeShut(false), 900); }}>
        <svg viewBox="-20 -14 40 28" width="40" height="28" aria-hidden>
          <ellipse rx="18" ry={eyeShut ? 1.5 : 11} fill="#f8f8f8" stroke="#ff007f" strokeWidth="2" />
          {!eyeShut && <><circle cx={look.x} cy={look.y} r="5.5" fill="#00ffff" /><circle cx={look.x} cy={look.y} r="2.4" fill="#09090b" /></>}
        </svg>
      </button>
      <button className="dnp" onClick={doNotPress}>do not press</button>
    </main>
  );
}
