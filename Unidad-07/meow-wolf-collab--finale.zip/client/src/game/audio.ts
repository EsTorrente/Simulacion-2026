// One Web Audio engine for everything: synthesized sound effects, the finale drone, and the music tracks.
// Nothing plays until the user has clicked/pressed a key (browser autoplay rules).
//
//   sfx / drone ──► sfxBus ──┐
//   music tracks ─► musicBus ┴─► master (mute + volume) ─► speakers
//                      └─► analyser (the finale reads it to react to the beat)
import { SCENE_TRACK, TRACKS, type MusicScene, type TrackId } from './musicTracks';

const MUTE_KEY = 'mw-muted';
const VOL_KEY = 'mw-volume';
const MUSIC_KEY = 'mw-music-level';
const SFX_KEY = 'mw-sfx-level';
const readLevel = (key: string, fallback: number) => {
  const v = Number(localStorage.getItem(key) ?? fallback);
  return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : fallback;
};

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfxBus: GainNode | null = null;
let musicBus: GainNode | null = null;
let analyser: AnalyserNode | null = null;
let muted = localStorage.getItem(MUTE_KEY) === '1';
let volume = Number(localStorage.getItem(VOL_KEY) ?? 0.5);
if (!Number.isFinite(volume)) volume = 0.5;
let musicLevel = readLevel(MUSIC_KEY, 0.7); // music vs. effects balance, both sit under the master volume
let sfxLevel = readLevel(SFX_KEY, 1);

function unlock() {
  if (!ctx) {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : volume;
    master.connect(ctx.destination);
    sfxBus = ctx.createGain(); sfxBus.gain.value = sfxLevel; sfxBus.connect(master);
    musicBus = ctx.createGain(); musicBus.gain.value = musicLevel; musicBus.connect(master);
    analyser = ctx.createAnalyser(); analyser.fftSize = 1024; analyser.smoothingTimeConstant = 0.55; musicBus.connect(analyser);
    ctx.onstatechange = () => { if (ctx && (ctx.state as string) === 'interrupted') void ctx.resume().catch(() => {}); };  // 'interrupted' = iOS Safari after a call / lock screen
    applyScene(); // a screen may have asked for music before the first click
  }
  if (ctx.state !== 'running') void ctx.resume().catch(() => {});
}
// Browsers only allow audio after a user gesture, so we wait for the first one.
window.addEventListener('pointerdown', unlock);
window.addEventListener('keydown', unlock);
// Coming back to the tab (or the phone waking up): browsers may have suspended the audio, so wake it again.
document.addEventListener('visibilitychange', () => { if (!document.hidden && ctx && ctx.state !== 'running') void ctx.resume().catch(() => {}); });
window.addEventListener('pageshow', () => { if (ctx && ctx.state !== 'running') void ctx.resume().catch(() => {}); });

export const isMuted = () => muted;
export const getVolume = () => volume;
export function setMuted(m: boolean) {
  muted = m; localStorage.setItem(MUTE_KEY, m ? '1' : '0');
  if (master) master.gain.value = m ? 0 : volume;
}
export function setVolume(v: number) {
  volume = Math.min(1, Math.max(0, v)); localStorage.setItem(VOL_KEY, String(volume));
  if (master && !muted) master.gain.value = volume;
}

export const getMusicLevel = () => musicLevel;
export const getSfxLevel = () => sfxLevel;
export function setMusicLevel(v: number) {
  musicLevel = Math.min(1, Math.max(0, v)); localStorage.setItem(MUSIC_KEY, String(musicLevel));
  if (musicBus && ctx) musicBus.gain.setTargetAtTime(musicLevel, ctx.currentTime, 0.03);
}
export function setSfxLevel(v: number) {
  sfxLevel = Math.min(1, Math.max(0, v)); localStorage.setItem(SFX_KEY, String(sfxLevel));
  if (sfxBus && ctx) sfxBus.gain.setTargetAtTime(sfxLevel, ctx.currentTime, 0.03);
}

interface Tone { freq: number; dur: number; type?: OscillatorType; gain?: number; slideTo?: number; at?: number; }
function play(tones: Tone[]) {
  if (!ctx || !sfxBus || muted || ctx.state !== 'running') return;
  const now = ctx.currentTime;
  for (const t of tones) {
    const start = now + (t.at ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = t.type ?? 'sine';
    osc.frequency.setValueAtTime(t.freq, start);
    if (t.slideTo) osc.frequency.exponentialRampToValueAtTime(t.slideTo, start + t.dur);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(t.gain ?? 0.2, start + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, start + t.dur);
    osc.connect(g); g.connect(sfxBus);
    osc.start(start); osc.stop(start + t.dur + 0.02);
  }
}

/** Quiet evolving drone for the finale. Returns a function that fades it out. */
export function startAmbience(t: { growth: number; fire: number; electric: number; watching: number }): () => void {
  if (!ctx || !sfxBus) return () => {};
  const c = ctx, out = c.createGain();
  out.gain.setValueAtTime(0.0001, c.currentTime);
  // With a real music track underneath, the synth drone is only a faint texture (full strength if the music could not load).
  out.gain.exponentialRampToValueAtTime(musicFailed ? 0.07 : 0.022, c.currentTime + 4); // slow fade-in, never sudden
  const filter = c.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 500;
  filter.connect(out); out.connect(sfxBus);
  const base = t.fire > t.growth ? 49 : 55;
  const voices: [number, OscillatorType, number][] = [
    [base, 'sine', 0.5], [base * 1.498, 'sine', 0.3], [base * 2.01 * (1 + 0.004 * t.electric), 'triangle', 0.1 + 0.15 * (t.electric + t.watching)],
  ];
  const oscs = voices.map(([f, type, gain]) => {
    const o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.value = gain;
    o.connect(g); g.connect(filter); o.start(); return o;
  });
  const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 0.06 + 0.1 * t.fire; lg.gain.value = 260;
  lfo.connect(lg); lg.connect(filter.frequency); lfo.start();
  return () => {
    const now = c.currentTime;
    out.gain.cancelScheduledValues(now); out.gain.setValueAtTime(Math.max(out.gain.value, 0.0001), now);
    out.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);
    [...oscs, lfo].forEach(o => o.stop(now + 1.3));
  };
}


// ---------------------------------------------------------------------------------------------
// Music: one looping track at a time, crossfaded when the screen asks for a different one.
// Screens only say which scene they are (lobby / cat / wolf / finale); musicTracks.ts says which track that is.
// If the next scene uses the track that is already playing, nothing happens (no restart, no gap).
// ---------------------------------------------------------------------------------------------
interface Playing { id: TrackId; src: AudioBufferSourceNode; gain: GainNode; startedAt: number }
const FADE = 1.8; // seconds
let wantedScene: MusicScene | null = null;
let current: Playing | null = null;
let loadToken = 0;
let musicFailed = false;
const buffers = new Map<TrackId, Promise<AudioBuffer>>();

function loadBuffer(id: TrackId): Promise<AudioBuffer> {
  let p = buffers.get(id);
  if (!p) {
    const c = ctx!;
    p = fetch(TRACKS[id].url)
      .then(r => { if (!r.ok) throw new Error(`music ${id}: HTTP ${r.status}`); return r.arrayBuffer(); })
      .then(ab => c.decodeAudioData(ab));
    p.catch(() => buffers.delete(id)); // allow a retry on the next scene change
    buffers.set(id, p);
  }
  return p;
}

const curve = (up: boolean) => Float32Array.from({ length: 48 }, (_, i) => Math.sin((up ? i : 47 - i) / 47 * Math.PI / 2)); // equal-power fade

function startTrack(id: TrackId, buf: AudioBuffer) {
  if (!ctx || !musicBus) return;
  const c = ctx, t = c.currentTime, info = TRACKS[id];
  const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
  src.loopStart = info.loopStart; src.loopEnd = Math.min(info.loopEnd, buf.duration);
  const g = c.createGain(); g.gain.setValueAtTime(0, t); g.gain.setValueCurveAtTime(curve(true), t, FADE);
  src.connect(g); g.connect(musicBus); src.start(t);
  const old = current; current = { id, src, gain: g, startedAt: t };
  if (old) {
    old.gain.gain.cancelScheduledValues(t); old.gain.gain.setValueCurveAtTime(curve(false), t, FADE);
    old.src.stop(t + FADE + 0.05);
    old.src.onended = () => { old.src.disconnect(); old.gain.disconnect(); if (current?.id !== old.id) buffers.delete(old.id); }; // free the decoded audio (~50 MB)
  }
  // Warm the browser cache with the other track, so a later screen change starts instantly.
  window.setTimeout(() => { for (const k of Object.keys(TRACKS) as TrackId[]) if (k !== id) void fetch(TRACKS[k].url).catch(() => {}); }, 4000);
}

function applyScene() {
  if (!ctx || !musicBus || !wantedScene) return;
  const id = SCENE_TRACK[wantedScene], token = ++loadToken; // a newer request always wins over a slower earlier one
  if (current?.id === id) return;
  loadBuffer(id).then(buf => { if (token === loadToken) { musicFailed = false; startTrack(id, buf); } })
    .catch(err => { if (token === loadToken) musicFailed = true; console.warn('[music]', err); });
}

/** Tell the engine which screen is showing. Safe to call before the first click: the music starts once audio is allowed. */
export function setMusicScene(scene: MusicScene) { wantedScene = scene; applyScene(); }

export const isMusicPlaying = () => !!current && !!ctx && ctx.state === 'running';
/** For tests and debugging. */
export function getMusicDebug() {
  return { scene: wantedScene, track: current?.id ?? null, state: ctx?.state ?? 'none', musicFailed, loopSeconds: current ? ((ctx!.currentTime - current.startedAt)) : 0 };
}

/**
 * What the music is doing right now, for visuals. Call once per frame; extra calls in the same frame are free.
 *   energy 0..1: overall loudness (slow), bass 0..1: punch of the low end, beat 0..1: spikes to 1 on a strong low-end hit then decays,
 *   hit: true on the single frame a new beat was detected.
 * Everything is 0 while muted/silent, so visuals follow what the player actually hears.
 */
export const musicPulse = { energy: 0, bass: 0, beat: 0, hit: false };
let freq = new Uint8Array(0), pulseAt = 0, bassAvg = 0, lastBeat = 0;
export function getMusicPulse() {
  const now = performance.now();
  if (now - pulseAt < 8) return musicPulse;
  const dt = Math.min(0.1, (now - pulseAt) / 1000); pulseAt = now; musicPulse.hit = false;
  const live = !!analyser && !!current && !muted && !!ctx && ctx.state === 'running' && musicLevel * volume > 0.01;
  if (!live) {
    const k = Math.exp(-dt * 4); musicPulse.energy *= k; musicPulse.bass *= k; musicPulse.beat *= k; return musicPulse;
  }
  if (freq.length !== analyser!.frequencyBinCount) freq = new Uint8Array(analyser!.frequencyBinCount);
  analyser!.getByteFrequencyData(freq);
  let bass = 0, all = 0;
  for (let i = 1; i <= 5; i++) bass += freq[i]; // roughly 40–250 Hz
  for (let i = 1; i <= 90; i++) all += freq[i]; // up to about 4 kHz
  bass /= 5 * 255; all /= 90 * 255;
  bassAvg += (bass - bassAvg) * Math.min(1, dt * 1.2); // running average, so "punch" means louder than usual
  const punch = Math.min(1, Math.max(0, (bass - bassAvg) * 5));
  musicPulse.bass += (punch - musicPulse.bass) * Math.min(1, dt * 14);
  musicPulse.energy += (Math.min(1, all * 2.2) - musicPulse.energy) * Math.min(1, dt * 3);
  musicPulse.beat = Math.max(0, musicPulse.beat - dt * 4.5);
  if (bass > bassAvg * 1.22 + 0.04 && now - lastBeat > 280) { lastBeat = now; musicPulse.beat = 1; musicPulse.hit = true; }
  return musicPulse;
}

let lastDraw = 0;
let lastZap = 0;
export const sfx = {
  draw() { // soft scratch, throttled so rapid strokes aren't annoying
    const n = performance.now(); if (n - lastDraw < 250) return; lastDraw = n;
    play([{ freq: 180 + Math.random() * 80, slideTo: 120, dur: 0.07, type: 'triangle', gain: 0.1 }]);
  },
  place() { play([{ freq: 520, slideTo: 180, dur: 0.1, gain: 0.25 }, { freq: 90, dur: 0.06, type: 'square', gain: 0.08 }]); },
  collect() { play([262, 330, 392].map((f, i) => ({ freq: f, dur: 0.1, type: 'square' as const, gain: 0.1, at: i * 0.07 }))); },
  hit() { play([{ freq: 300, slideTo: 55, dur: 0.35, type: 'sawtooth', gain: 0.22 }, { freq: 90, slideTo: 40, dur: 0.4, type: 'square', gain: 0.12 }]); },
  revive() { play([392, 523, 659].map((f, i) => ({ freq: f, dur: 0.14, type: 'triangle' as const, gain: 0.12, at: i * 0.08 }))); },
  unlock() { play([880, 1175, 1568].map((f, i) => ({ freq: f, dur: 0.18, gain: 0.12, at: i * 0.09 }))); },
  bloom() { play([{ freq: 330, slideTo: 495, dur: 0.6, gain: 0.05 }, { freq: 660, slideTo: 990, dur: 0.6, gain: 0.025, at: 0.05 }]); },
  zap() { const n = performance.now(); if (n - lastZap < 700) return; lastZap = n; play([{ freq: 900, slideTo: 90, dur: 0.12, type: 'sawtooth', gain: 0.035 }]); },
  meow() { play([{ freq: 430, slideTo: 790, dur: 0.16, type: 'triangle', gain: 0.1 }, { freq: 790, slideTo: 470, dur: 0.26, type: 'triangle', gain: 0.1, at: 0.15 }]); },
  howl() { play([{ freq: 200, slideTo: 540, dur: 0.7, type: 'sine', gain: 0.1 }, { freq: 540, slideTo: 300, dur: 0.9, type: 'sine', gain: 0.09, at: 0.7 }, { freq: 202, slideTo: 545, dur: 0.7, type: 'triangle', gain: 0.03 }]); },
  glitch() { play([{ freq: 1400, slideTo: 120, dur: 0.09, type: 'square', gain: 0.04 }, { freq: 90, slideTo: 900, dur: 0.07, type: 'sawtooth', gain: 0.03, at: 0.06 }]); },
  blip() { play([{ freq: 660, dur: 0.05, type: 'square', gain: 0.05 }]); },
  finish() { play([262, 330, 392, 523].map((f, i) => ({ freq: f, dur: 0.9, type: 'triangle' as const, gain: 0.13, at: i * 0.18 }))); },
};
