// "Boil" = a tiny, discrete wobble applied only when DRAWING strokes. Stroke data is never changed.
// One shared 8 fps timer drives every canvas, independent of network updates.
import { useSyncExternalStore } from 'react';

const BOIL_MS = 125;
const POSES = 3;          // classic hand-drawn boil cycles through a few poses
const AMPLITUDE = 1.6;    // logical units on the 800x800 canvas (~0.2%): subtle

const reduced = typeof window !== 'undefined' ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
export const boilAmplitude = () => (reduced?.matches ? 0 : AMPLITUDE);

let tickCount = 0;
let timer: number | undefined;
const subs = new Set<() => void>();

function subscribe(cb: () => void) {
  subs.add(cb);
  if (timer === undefined && !reduced?.matches) {
    timer = window.setInterval(() => {
      if (document.hidden) return; // pause in background tabs
      tickCount++;
      subs.forEach(f => f());
    }, BOIL_MS);
  }
  return () => {
    subs.delete(cb);
    if (subs.size === 0 && timer !== undefined) { window.clearInterval(timer); timer = undefined; }
  };
}

/** Current boil pose (0..2). Components using it re-render ~8x/second. */
export function useBoilPose(): number {
  return useSyncExternalStore(subscribe, () => tickCount % POSES);
}

/** Smooth along the stroke, different per pose and per stroke (seed). */
export function boilOffset(i: number, seed: number, pose: number, amp: number) {
  return {
    dx: amp * Math.sin(i * 0.23 + pose * 2.1 + seed),
    dy: amp * Math.cos(i * 0.29 + pose * 1.7 + seed * 1.3),
  };
}
