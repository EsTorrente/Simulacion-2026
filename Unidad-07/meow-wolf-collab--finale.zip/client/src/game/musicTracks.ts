// Which music plays where. This is the ONLY place to change the mapping (the engine lives in audio.ts).
//
// The files in client/public/audio are "loop-ready" versions of the originals (tools/prepare-music.py):
//  - cut on the beat, leading/trailing silence removed, loudness matched (about -17 LUFS),
//  - a short crossfade is baked in at the loop point, so looping is seamless and keeps the rhythm.
// A track plays from its start once (the intro), then repeats loopStart..loopEnd forever.
export type TrackId = 'browser-history' | 'backroom-labyrinth';
export type MusicScene = 'lobby' | 'cat' | 'wolf' | 'finale';

export interface TrackInfo { title: string; file: string; url: string; loopStart: number; loopEnd: number; bpm: number }

const url = (file: string) => `${import.meta.env.BASE_URL}audio/${file}`;

export const TRACKS: Record<TrackId, TrackInfo> = {
  'browser-history': { title: 'Browser History', file: 'browser-history.mp3', url: url('browser-history.mp3'), loopStart: 9.142857, loopEnd: 128.0, bpm: 105 },
  'backroom-labyrinth': { title: 'Backroom Labyrinth', file: 'backroom-labyrinth.mp3', url: url('backroom-labyrinth.mp3'), loopStart: 38.0, loopEnd: 134.0, bpm: 180 },
};

// Screens that share a track never restart it when the player moves between them.
export const SCENE_TRACK: Record<MusicScene, TrackId> = {
  lobby: 'browser-history',
  cat: 'browser-history',
  wolf: 'backroom-labyrinth',
  finale: 'backroom-labyrinth',
};
