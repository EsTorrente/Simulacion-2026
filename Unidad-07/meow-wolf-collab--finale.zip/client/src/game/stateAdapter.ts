import type { GameState, LetterID, PlayerRole, StickerPlacement, Stroke } from './types';

/** `found` = the Wolf picked something up (shown with its color); `error` = something was refused. */
export interface Notice { kind: 'info' | 'error' | 'found'; message: string; color?: string; }

/** What the screens are allowed to do. Both the mock and the Socket.IO adapter implement it. */
export interface StateAdapter {
  subscribe(listener: (state: GameState) => void): () => void;
  subscribeNotice(listener: (n: Notice) => void): () => void;
  addStroke(letterId: LetterID, stroke: Stroke): void;
  clearLetter(letterId: LetterID): void;
  /** Undo / redo the last drawing edit on a letter. The server keeps the history; these are intents. */
  undo(letterId: LetterID): void;
  redo(letterId: LetterID): void;
  addSticker(letterId: LetterID, sticker: StickerPlacement & { kind: string }): void;
  updateSticker(letterId: LetterID, id: string, placement: StickerPlacement): void;
  removeSticker(letterId: LetterID, id: string): void;
  replayFinale(): void;
  reopenStudio(): void;
  moveWolf(dx: number, dy: number): void;
  confirmFinish(role: PlayerRole): void;
  cancelFinish(role: PlayerRole): void;
}
