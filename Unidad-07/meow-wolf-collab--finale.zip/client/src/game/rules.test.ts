import { describe, it, expect } from 'vitest';
import { GameSession } from '../../../shared/rules';
import { MAZE_GRID } from '../../../shared/maze';

const stroke = (color = '#ff007f') => ({ points: [{ x: 10, y: 10 }, { x: 20, y: 20 }], color, brushSize: 5 });

function readySession() {
  let n = 0;
  const s = new GameSession(() => `tok${n++}`);
  s.join('Cat'); s.join('Wolf');
  return s;
}

describe('seats', () => {
  it('refuses a second Cat', () => {
    const s = new GameSession(); s.join('Cat');
    expect(s.join('Cat').ok).toBe(false);
  });
  it('lets a token reclaim its seat, and nobody else', () => {
    const s = new GameSession(() => 'secret');
    s.join('Cat');
    expect(s.rejoin('guess').ok).toBe(false);
    expect(s.rejoin('secret').ok).toBe(true);
  });
  it('does not allow play until both seats are filled', () => {
    const s = new GameSession(); s.join('Cat');
    expect(s.addStroke('Cat', 'M', stroke()).ok).toBe(false);
    expect(s.getState().status).toBe('lobby');
  });
  it('never exposes tokens', () => {
    expect(JSON.stringify(readySession().getState()).includes('tok')).toBe(false);
  });
});

describe('drawing', () => {
  it('keeps repeated letters separate', () => {
    const s = readySession();
    s.addStroke('Cat', 'O1', stroke());
    expect(s.getState().letters.O1.length).toBe(1);
    expect(s.getState().letters.O2.length).toBe(0);
  });
  it('rejects the Wolf drawing, and locked colors', () => {
    const s = readySession();
    expect(s.addStroke('Wolf', 'M', stroke()).ok).toBe(false);
    expect(s.addStroke('Cat', 'M', stroke('#00ffff')).ok).toBe(false);
  });
  it('rejects malformed strokes', () => {
    const s = readySession();
    expect(s.addStroke('Cat', 'M', { points: [{ x: 9999, y: 1 }], color: '#ff007f', brushSize: 5 }).ok).toBe(false);
    expect(s.addStroke('Cat', 'ZZ', stroke()).ok).toBe(false);
  });
  it('clears one letter', () => {
    const s = readySession();
    s.addStroke('Cat', 'M', stroke()); s.clearLetter('Cat', 'M');
    expect(s.getState().letters.M.length).toBe(0);
  });
});

describe('maze', () => {
  it('blocks walls and the Cat', () => {
    const s = readySession();
    expect(s.moveWolf('Wolf', -1, 0).ok).toBe(false);
    expect(s.moveWolf('Cat', 1, 0).ok).toBe(false);
    expect(s.moveWolf('Wolf', 1, 1).ok).toBe(false);
  });
  it('collects an item once and unlocks it (dodging enemies on the way)', () => {
    const s = new GameSession(() => 'x', () => 1, () => 0.5); s.join('Cat'); s.join('Wolf');
    s.moveWolf('Wolf', 1, 0); // first step wakes the enemies
    const target = s.getState().collectibles.find(c => c.id === 'c1')!;
    for (let i = 0; i < 3000 && !s.getState().collectibles.find(c => c.id === 'c1')!.collected; i++) {
      const path = pathTo(s, target.pos, true);
      if (path.length) s.moveWolf('Wolf', path[0][0], path[0][1]);
      s.tick();
    }
    const st = s.getState();
    expect(st.collectibles.find(c => c.id === 'c1')!.collected).toBe(true);
    expect(st.unlockedColors.includes(target.value)).toBe(true);
  });
});

/** Shortest list of unit steps from the Wolf's position to `to` (test helper). */
function pathTo(s: GameSession, to: { x: number; y: number }, avoidEnemies = false): [number, number][] {
  const from = s.getState().wolfPos, bad = new Set(avoidEnemies ? s.getState().enemies.map(e => `${e.pos.x},${e.pos.y}`) : []), key = (p: { x: number; y: number }) => `${p.x},${p.y}`;
  const prev = new Map<string, { p: { x: number; y: number }; step: [number, number] } | null>([[key(from), null]]);
  const q = [from];
  for (let i = 0; i < q.length; i++) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as [number, number][]) {
    const n = { x: q[i].x + dx, y: q[i].y + dy };
    if (MAZE_GRID[n.y]?.[n.x] !== 0 || prev.has(key(n)) || bad.has(key(n))) continue;
    prev.set(key(n), { p: q[i], step: [dx, dy] }); q.push(n);
  }
  const out: [number, number][] = [];
  for (let c = prev.get(key(to)); c; c = prev.get(key(c.p))) out.unshift(c.step);
  return out;
}

describe('enemies and lives', () => {
  const live = () => { const s = new GameSession(() => 'x', () => 1, () => 0.5); s.join('Cat'); s.join('Wolf'); return s; };
  const enemyAt = (s: GameSession, id: string) => s.getState().enemies.find(e => e.id === id)!.pos;
  it('starts with 3 lives, four enemies, and every pickup reachable', () => {
    const s = live(); const st = s.getState();
    expect(st.lives).toBe(3); expect(st.enemies.length).toBe(4);
    for (const c of st.collectibles) expect(pathTo(s, c.pos).length).toBeGreaterThan(0);
  });
  it('keeps enemies still until the Wolf first moves', () => {
    const s = live(); const before = JSON.stringify(s.getState().enemies);
    s.tick(); s.tick();
    expect(JSON.stringify(s.getState().enemies)).toBe(before);
    s.moveWolf('Wolf', 1, 0); s.tick();
    expect(JSON.stringify(s.getState().enemies)).not.toBe(before);
  });
  it('only ever moves enemies one open cell per tick', () => {
    const s = live(); s.moveWolf('Wolf', 1, 0);
    let prev = s.getState().enemies;
    for (let i = 0; i < 60; i++) {
      s.tick();
      if (s.getState().catches) break; // a catch teleports everybody home, which is correct
      const now = s.getState().enemies;
      now.forEach((e, k) => {
        expect(MAZE_GRID[e.pos.y][e.pos.x]).toBe(0);
        expect(Math.abs(e.pos.x - prev[k].pos.x) + Math.abs(e.pos.y - prev[k].pos.y)).toBeLessThanOrEqual(1);
      });
      prev = now;
    }
  });
  it('a hunter that is close really does close in on the Wolf', () => {
    const s = live(); s.moveWolf('Wolf', 1, 0);
    // walk the Wolf toward the hunter's start until it is inside its range, then it must not drift away
    const path = pathTo(s, { x: 13, y: 5 }); // stops short of (13,7)
    const hunterDist = () => { const e = enemyAt(s, 'e1'), w = s.getState().wolfPos; return Math.abs(e.x - w.x) + Math.abs(e.y - w.y); };
    for (const [dx, dy] of path.slice(0, path.length)) { s.moveWolf('Wolf', dx, dy); s.tick(); if (s.getState().catches) break; }
    expect(s.getState().catches > 0 || hunterDist() <= 6).toBe(true);
  });
  it('catching the Wolf costs a life, sends it home and grants safety', () => {
    const s = live(); s.moveWolf('Wolf', 1, 0);
    let guard = 0;
    while (!s.getState().catches && guard++ < 400) { s.tick(); }
    // Enemies wander randomly (rng fixed) and may never reach a still Wolf; force a catch by walking into the hunter instead.
    if (!s.getState().catches) {
      for (const [dx, dy] of pathTo(s, enemyAt(s, 'e1'))) { s.moveWolf('Wolf', dx, dy); s.tick(); if (s.getState().catches) break; }
    }
    const st = s.getState();
    expect(st.catches).toBe(1); expect(st.lives).toBe(2);
    expect(st.wolfPos).toEqual({ x: 1, y: 1 });
    expect(st.wolfCondition).toBe('invulnerable');
  });
  it('after the last life the Wolf is stunned, then revived with full lives; found items stay found', () => {
    const s = live();
    for (const [dx, dy] of pathTo(s, { x: 7, y: 8 }, true)) { s.moveWolf('Wolf', dx, dy); }
    const found = s.getState().unlockedColors.length;
    let safety = 0;
    while (s.getState().lives > 0 && safety++ < 20000) {
      const w = s.getState().wolfPos; const target = enemyAt(s, 'e1');
      const p = pathTo(s, target);
      if (s.getState().wolfCondition === 'invulnerable') { s.tick(); continue; }
      if (!p.length) { s.tick(); continue; }
      s.moveWolf('Wolf', p[0][0], p[0][1]); s.tick(); void w;
    }
    expect(s.getState().wolfCondition).toBe('stunned');
    expect(s.moveWolf('Wolf', 1, 0).ok).toBe(false);
    for (let i = 0; i < 25; i++) s.tick();
    expect(s.getState().lives).toBe(3);
    expect(s.getState().unlockedColors.length).toBe(found);
  });
  it('does not run while the Wolf is disconnected or the finale has begun', () => {
    const s = live(); s.moveWolf('Wolf', 1, 0);
    s.setConnected('Wolf', false); expect(s.tick()).toBe(false);
    s.setConnected('Wolf', true); s.confirm('Cat'); s.confirm('Wolf'); expect(s.tick()).toBe(false);
  });
});

describe('finalization', () => {
  it('needs both players', () => {
    const s = readySession();
    s.confirm('Cat');
    expect(s.getState().status).toBe('playing');
    s.confirm('Wolf');
    expect(s.getState().status).toBe('finalizing');
  });
  it('drawing after confirming invalidates confirmations', () => {
    const s = readySession();
    s.confirm('Wolf'); s.addStroke('Cat', 'M', stroke());
    expect(s.getState().wolfConfirmed).toBe(false);
  });
  it('freezes the artwork once finalizing', () => {
    const s = readySession(); s.confirm('Cat'); s.confirm('Wolf');
    expect(s.addStroke('Cat', 'M', stroke()).ok).toBe(false);
  });
});

describe('stickers', () => {
  const place = { kind: 'skull', x: 0.5, y: 0.5, scale: 1, rotation: 0 };
  it('refuses locked stickers and the Wolf', () => {
    const s = readySession();
    expect(s.addSticker('Cat', 'M', place).ok).toBe(false);
    expect(s.addSticker('Wolf', 'M', place).ok).toBe(false);
  });
  it('places, updates and removes with stable ids', () => {
    const s = readySession();
    (s as unknown as { unlockedStickers: string[] }).unlockedStickers.push('skull');
    const r = s.addSticker('Cat', 'O1', place);
    expect(r.ok).toBe(true);
    const id = (r as { id: string }).id;
    expect(s.getState().stickers.O1.length).toBe(1);
    expect(s.getState().stickers.O2.length).toBe(0);
    expect(s.updateSticker('Cat', 'O1', id, { x: 0.2, y: 0.3, scale: 2, rotation: 45 }).ok).toBe(true);
    expect(s.updateSticker('Cat', 'O1', id, { x: 5, y: 0.3, scale: 2, rotation: 45 }).ok).toBe(false);
    expect(s.removeSticker('Cat', 'O1', id).ok).toBe(true);
    expect(s.getState().stickers.O1.length).toBe(0);
  });
  it('resets confirmations when a sticker is placed', () => {
    const s = readySession();
    (s as unknown as { unlockedStickers: string[] }).unlockedStickers.push('skull');
    s.confirm('Wolf'); s.addSticker('Cat', 'M', place);
    expect(s.getState().wolfConfirmed).toBe(false);
  });
});

describe('finale', () => {
  const finished = () => { let n = 0; const s = new GameSession(() => `t${n++}`, () => 111); s.join('Cat'); s.join('Wolf'); s.confirm('Cat'); s.confirm('Wolf'); return s; };
  it('picks one server seed when both confirm', () => {
    const s = readySession();
    expect(s.getState().seed).toBe(0);
    s.confirm('Cat'); s.confirm('Wolf');
    expect(s.getState().seed > 0).toBe(true);
  });
  it('replay changes the seed; only during the finale', () => {
    let k = 0; const s = new GameSession(() => 'a', () => 100 + k++); s.join('Cat'); s.join('Wolf');
    expect(s.replayFinale('Cat').ok).toBe(false);
    s.confirm('Cat'); s.confirm('Wolf');
    const first = s.getState().seed; s.replayFinale('Wolf');
    expect(s.getState().seed === first).toBe(false);
  });
  it('reopening keeps the artwork and resets confirmations', () => {
    const s = readySession(); s.addStroke('Cat', 'M', stroke()); s.confirm('Cat'); s.confirm('Wolf');
    expect(s.reopenStudio('Cat').ok).toBe(true);
    const st = s.getState();
    expect(st.status).toBe('playing'); expect(st.letters.M.length).toBe(1); expect(st.catConfirmed).toBe(false); expect(st.seed).toBe(0);
    expect(finished().getState().seed).toBe(111);
  });
});

describe('undo / redo (server-side history)', () => {
  it('undoes and redoes strokes per letter, Cat only', () => {
    const s = readySession();
    s.addStroke('Cat', 'M', stroke()); s.addStroke('Cat', 'M', stroke()); s.addStroke('Cat', 'E', stroke());
    expect(s.getState().history.M).toEqual({ undo: 2, redo: 0 });
    expect(s.undo('Wolf', 'M').ok).toBe(false);
    expect(s.undo('Cat', 'M').ok).toBe(true);
    expect(s.getState().letters.M.length).toBe(1); expect(s.getState().letters.E.length).toBe(1);
    expect(s.getState().history.M).toEqual({ undo: 1, redo: 1 });
    expect(s.redo('Cat', 'M').ok).toBe(true);
    expect(s.getState().letters.M.length).toBe(2);
    expect(s.redo('Cat', 'M').ok).toBe(false);
  });
  it('a new stroke discards the redo list; nothing to undo is an error', () => {
    const s = readySession();
    expect(s.undo('Cat', 'M').ok).toBe(false);
    s.addStroke('Cat', 'M', stroke()); s.undo('Cat', 'M'); s.addStroke('Cat', 'M', stroke());
    expect(s.getState().history.M.redo).toBe(0);
  });
  it('Clear can be undone and redone', () => {
    const s = readySession();
    s.addStroke('Cat', 'M', stroke()); s.addStroke('Cat', 'M', stroke());
    s.clearLetter('Cat', 'M'); expect(s.getState().letters.M.length).toBe(0);
    s.undo('Cat', 'M'); expect(s.getState().letters.M.length).toBe(2);
    s.redo('Cat', 'M'); expect(s.getState().letters.M.length).toBe(0);
  });
  it('undo resets both players\' confirmations like any artwork change', () => {
    const s = readySession(); s.addStroke('Cat', 'M', stroke()); s.confirm('Wolf');
    s.undo('Cat', 'M'); expect(s.getState().wolfConfirmed).toBe(false);
  });
});
