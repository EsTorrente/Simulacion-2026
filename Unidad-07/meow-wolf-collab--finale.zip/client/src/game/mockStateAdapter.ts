// Offline, single-browser adapter (open the app with ?mock=1). It runs the same
// shared rules as the server, with both seats pre-filled.
import { GameSession } from '../../../shared/rules';
import { ENEMY_STEP_MS, MAZE_GRID, WOLF_STEP_MS } from '../../../shared/maze';
import type { GameState, LetterID, PlayerRole, StickerPlacement, Stroke } from './types';
import type { Notice, StateAdapter } from './stateAdapter';
import { foundNotice } from './notices';

export { MAZE_GRID };

class MockStateAdapter implements StateAdapter {
  private session = new GameSession();
  private listeners = new Set<(state: GameState) => void>();
  private noticeListeners = new Set<(n: Notice) => void>();

  private lastMove = 0;

  constructor() {
    this.session.join('Cat'); this.session.join('Wolf');
    // Same clock the server uses for the enemies.
    setInterval(() => { if (this.session.tick()) { const s = this.session.getState(); this.listeners.forEach(l => l(s)); } }, ENEMY_STEP_MS);
  }

  subscribe(listener: (state: GameState) => void) {
    this.listeners.add(listener);
    listener(this.session.getState());
    return () => { this.listeners.delete(listener); };
  }

  subscribeNotice(listener: (n: Notice) => void) {
    this.noticeListeners.add(listener);
    return () => { this.noticeListeners.delete(listener); };
  }

  private done(r: { ok: boolean; error?: string; collected?: { type: string; value: string } }) {
    if (!r.ok && r.error && r.error !== 'Wall.') this.noticeListeners.forEach(l => l({ kind: 'error', message: r.error! }));
    if (r.ok && r.collected) this.noticeListeners.forEach(l => l(foundNotice(r.collected!)));
    const s = this.session.getState();
    this.listeners.forEach(l => l(s));
  }

  addStroke(letterId: LetterID, stroke: Stroke) { this.done(this.session.addStroke('Cat', letterId, stroke)); }
  clearLetter(letterId: LetterID) { this.done(this.session.clearLetter('Cat', letterId)); }
  undo(letterId: LetterID) { this.done(this.session.undo('Cat', letterId)); }
  redo(letterId: LetterID) { this.done(this.session.redo('Cat', letterId)); }
  addSticker(letterId: LetterID, sticker: StickerPlacement & { kind: string }) { this.done(this.session.addSticker('Cat', letterId, sticker)); }
  updateSticker(letterId: LetterID, id: string, p: StickerPlacement) { this.done(this.session.updateSticker('Cat', letterId, id, p)); }
  removeSticker(letterId: LetterID, id: string) { this.done(this.session.removeSticker('Cat', letterId, id)); }
  replayFinale() { this.done(this.session.replayFinale('Cat')); }
  reopenStudio() { this.done(this.session.reopenStudio('Cat')); }
  moveWolf(dx: number, dy: number) {
    const now = Date.now();
    if (now - this.lastMove < WOLF_STEP_MS - 20) return;
    this.lastMove = now;
    this.done(this.session.moveWolf('Wolf', dx, dy));
  }
  confirmFinish(role: PlayerRole) { this.done(this.session.confirm(role)); }
  cancelFinish(role: PlayerRole) { this.done(this.session.cancelConfirm(role)); }
}

export const gameStateManager = new MockStateAdapter();
