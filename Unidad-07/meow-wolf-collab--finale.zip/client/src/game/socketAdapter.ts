import { io, type Socket } from 'socket.io-client';
import { LETTER_IDS, type GameState, type LetterID, type PlayerRole, type Role, type StickerPlacement, type Stroke } from './types';
import type { Notice, StateAdapter } from './stateAdapter';
import { foundNotice } from './notices';

// Where is the Socket.IO server? By default: the same computer that served this web page,
// on port 4000. That is why a second computer that opens http://<host-ip>:3000 automatically
// talks to <host-ip>:4000. Override with VITE_SERVER_URL in client/.env if needed.
const SERVER_URL: string =
  import.meta.env.VITE_SERVER_URL ?? `${window.location.protocol}//${window.location.hostname}:4000`;

const TOKEN_KEY = 'mw-session-token'; // sessionStorage: one per browser tab (handy for testing)

export type ConnStatus = 'connecting' | 'connected' | 'disconnected';
export interface SessionInfo { conn: ConnStatus; role: Role; }

type WireState = Omit<GameState, 'letters' | 'stickers'> & { letters?: GameState['letters']; stickers?: GameState['stickers'] };
type Result = { ok: boolean; error?: string; role?: PlayerRole; token?: string; collected?: { type: string; value: string } };

const SILENT_ERRORS = new Set(['Wall.', 'Too fast.']); // normal gameplay, not worth a popup

class SocketStateAdapter implements StateAdapter {
  private socket: Socket = io(SERVER_URL, { autoConnect: false });
  private state: GameState | null = null;
  private info: SessionInfo = { conn: 'connecting', role: null };
  private listeners = new Set<(s: GameState) => void>();
  private sessionListeners = new Set<(i: SessionInfo) => void>();
  private noticeListeners = new Set<(n: Notice) => void>();

  constructor() {
    const s = this.socket;
    s.on('connect', () => {
      this.setInfo({ conn: 'connected' });
      const token = sessionStorage.getItem(TOKEN_KEY);
      if (token) {
        s.emit('lobby:rejoin', { token }, (r: Result) => {
          if (r?.ok && r.role) this.setInfo({ role: r.role });
          else {
            sessionStorage.removeItem(TOKEN_KEY);
            this.setInfo({ role: null });
            this.notice('error', 'Your seat was released while you were away.');
          }
        });
      }
    });
    s.on('disconnect', () => this.setInfo({ conn: 'disconnected' }));
    s.on('connect_error', () => this.setInfo({ conn: 'disconnected' }));
    s.io.on('reconnect_attempt', () => this.setInfo({ conn: 'connecting' }));

    s.on('state', (incoming: WireState) => {
      // Strokes are only sent when they change; otherwise keep the ones we have.
      const emptyLetters = Object.fromEntries(LETTER_IDS.map(id => [id, []])) as unknown as GameState['letters'];
      const emptyStickers = emptyLetters; // same shape: an empty list per letter
      this.state = {
        ...incoming,
        letters: incoming.letters ?? this.state?.letters ?? emptyLetters,
        stickers: incoming.stickers ?? this.state?.stickers ?? emptyStickers,
      } as GameState;
      this.listeners.forEach(l => l(this.state!));
    });
    s.on('notice', (n: Notice) => this.notice(n.kind, n.message));
    s.on('seat:lost', () => { sessionStorage.removeItem(TOKEN_KEY); this.setInfo({ role: null }); });
  }

  connect() { if (!this.socket.connected) this.socket.connect(); }
  get serverUrl() { return SERVER_URL; }

  // ----- subscriptions -----
  subscribe(l: (s: GameState) => void) {
    this.listeners.add(l);
    if (this.state) l(this.state);
    return () => { this.listeners.delete(l); };
  }
  subscribeSession(l: (i: SessionInfo) => void) {
    this.sessionListeners.add(l); l(this.info);
    return () => { this.sessionListeners.delete(l); };
  }
  subscribeNotice(l: (n: Notice) => void) {
    this.noticeListeners.add(l);
    return () => { this.noticeListeners.delete(l); };
  }
  private setInfo(patch: Partial<SessionInfo>) {
    this.info = { ...this.info, ...patch };
    this.sessionListeners.forEach(l => l(this.info));
  }
  private notice(kind: Notice['kind'], message: string) {
    this.noticeListeners.forEach(l => l({ kind, message }));
  }

  // ----- seats -----
  join(role: PlayerRole) {
    this.send('lobby:join', { role }, r => {
      if (r.token && r.role) { sessionStorage.setItem(TOKEN_KEY, r.token); this.setInfo({ role: r.role }); }
    });
  }
  leave() {
    this.send('lobby:leave', {}, () => { sessionStorage.removeItem(TOKEN_KEY); this.setInfo({ role: null }); });
  }
  resync() { this.socket.emit('state:request'); }

  // ----- game actions: nothing happens locally; we wait for the server's answer -----
  addStroke(letterId: LetterID, stroke: Stroke) { this.send('cat:stroke', { letterId, stroke }); }
  clearLetter(letterId: LetterID) { this.send('cat:clear', { letterId }); }
  undo(letterId: LetterID) { this.send('cat:undo', { letterId }); }
  redo(letterId: LetterID) { this.send('cat:redo', { letterId }); }
  addSticker(letterId: LetterID, sticker: StickerPlacement & { kind: string }) { this.send('cat:sticker:add', { letterId, sticker }); }
  updateSticker(letterId: LetterID, id: string, placement: StickerPlacement) { this.send('cat:sticker:update', { letterId, id, placement }); }
  removeSticker(letterId: LetterID, id: string) { this.send('cat:sticker:remove', { letterId, id }); }
  moveWolf(dx: number, dy: number) { this.send('wolf:move', { dx, dy }); }
  replayFinale() { this.send('finale:replay', {}); }
  reopenStudio() { this.send('finale:reopen', {}); }
  confirmFinish() { this.send('finalize:confirm', {}); }
  cancelFinish() { this.send('finalize:cancel', {}); }

  private send(event: string, payload: object, onOk?: (r: Result) => void) {
    if (!this.socket.connected) { this.notice('error', 'Not connected to the server.'); return; }
    this.socket.timeout(5000).emit(event, payload, (err: Error | null, r: Result) => {
      if (err) { this.notice('error', 'The server did not answer. Try again.'); return; }
      if (!r.ok) { if (r.error && !SILENT_ERRORS.has(r.error)) this.notice('error', r.error); return; }
      if (r.collected) this.noticeListeners.forEach(l => l(foundNotice(r.collected!)));
      onOk?.(r);
    });
  }
}

export const socketAdapter = new SocketStateAdapter();
