import { useEffect, useState } from 'react';
import type { GameState } from './types';
import type { Notice, StateAdapter } from './stateAdapter';

export function useGameState(adapter: StateAdapter): GameState | null {
  const [state, setState] = useState<GameState | null>(null);
  useEffect(() => adapter.subscribe(setState), [adapter]);
  return state;
}

export function useNotice(adapter: StateAdapter): Notice | null {
  const [notice, setNotice] = useState<Notice | null>(null);
  useEffect(() => {
    let timer: number | undefined;
    const unsub = adapter.subscribeNotice(n => {
      setNotice(n);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setNotice(null), n.kind === 'error' ? 4200 : 2800);
    });
    return () => { unsub(); window.clearTimeout(timer); };
  }, [adapter]);
  return notice;
}
