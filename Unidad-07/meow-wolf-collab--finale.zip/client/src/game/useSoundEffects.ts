import { useEffect, useRef } from 'react';
import type { GameState, Role } from './types';
import type { StateAdapter } from './stateAdapter';
import { sfx, setMusicScene } from './audio';
import type { MusicScene } from './musicTracks';

const sum = (r: Record<string, unknown[]>) => Object.values(r).reduce((n, a) => n + a.length, 0);

/** Plays sounds when the *confirmed* shared state changes (never before the server agrees). */
export function useSoundEffects(adapter: StateAdapter, role: Role) {
  const prev = useRef<GameState | null>(null);
  useEffect(() => adapter.subscribe(s => {
    const p = prev.current; prev.current = s;
    if (!p) return; // first snapshot: stay quiet
    if (role === 'Cat' && sum(s.letters) > sum(p.letters)) sfx.draw();
    if (sum(s.stickers) > sum(p.stickers)) sfx.place();
    const got = (g: GameState) => g.collectibles.filter(c => c.collected).length;
    if (role === 'Wolf' && got(s) > got(p)) sfx.collect();
    const unlocked = (g: GameState) => g.unlockedColors.length + g.unlockedStickers.length;
    if (role === 'Cat' && unlocked(s) > unlocked(p)) sfx.unlock();
    if (s.catches > p.catches) sfx.hit();
    if (p.wolfCondition === 'stunned' && s.wolfCondition !== 'stunned') sfx.revive();
    if (s.status === 'finalizing' && p.status !== 'finalizing') sfx.finish();
  }), [adapter, role]);
}

/** Tells the audio engine which screen is showing; it picks (and crossfades to) that screen's music. */
export function useMusicScene(scene: MusicScene) {
  useEffect(() => { setMusicScene(scene); }, [scene]);
}
