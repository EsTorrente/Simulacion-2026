import { describe, expect, it } from 'vitest';
import { existsSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import { SCENE_TRACK, TRACKS, type MusicScene } from './musicTracks';

const scenes: MusicScene[] = ['lobby', 'cat', 'wolf', 'finale'];

describe('music manifest', () => {
  it('maps every scene to a known track', () => {
    for (const s of scenes) expect(TRACKS[SCENE_TRACK[s]]).toBeTruthy();
  });
  it('has the audio files, with sane loop points', () => {
    for (const t of Object.values(TRACKS)) {
      const f = resolve(__dirname, '../../public/audio', t.file);
      expect(existsSync(f)).toBe(true);
      expect(statSync(f).size).toBeLessThan(3_500_000); // keep the repo small
      expect(t.loopStart).toBeGreaterThanOrEqual(0);
      expect(t.loopEnd - t.loopStart).toBeGreaterThan(30); // a long loop, not a stutter
    }
  });
  it('loop lengths are whole bars, so the beat never slips', () => {
    for (const t of Object.values(TRACKS)) {
      const bars = (t.loopEnd - t.loopStart) / ((60 / t.bpm) * 4);
      expect(Math.abs(bars - Math.round(bars))).toBeLessThan(0.01);
    }
  });
  it('screens that should share a track really do (so it never restarts between them)', () => {
    expect(SCENE_TRACK.lobby).toBe(SCENE_TRACK.cat);
    expect(SCENE_TRACK.wolf).toBe(SCENE_TRACK.finale);
  });
});
