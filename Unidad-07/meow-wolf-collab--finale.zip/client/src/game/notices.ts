// One place that decides what a notice says, so the solo and online adapters stay in sync.
import type { Notice } from './stateAdapter';

const COLOR_NAMES: Record<string, string> = { '#ccff00': 'acid green', '#00ffff': 'electric cyan', '#ff007f': 'hot pink' };
const STICKER_NAMES: Record<string, string> = { skull: 'skull', eye: 'eye', flower: 'flower', bolt: 'bolt' };

export const colorName = (hex: string) => COLOR_NAMES[hex.toLowerCase()] ?? 'new color';

/** The Wolf touched a collectible. Short, and names what the Cat just received. */
export function foundNotice(c: { type: string; value: string }): Notice {
  if (c.type === 'color') return { kind: 'found', message: `Found ${colorName(c.value)}. The Cat can paint with it now.`, color: c.value };
  return { kind: 'found', message: `Found the ${STICKER_NAMES[c.value] ?? c.value} sticker. Sent to the Cat.`, color: '#00ffff' };
}
