import { useEffect, useState } from 'react';
import type { PlayerRole, Role } from '../game/types';
import type { StateAdapter } from '../game/stateAdapter';
import { gameStateManager } from '../game/mockStateAdapter';
import { socketAdapter, type SessionInfo } from '../game/socketAdapter';
import { useGameState, useNotice } from '../game/useAdapter';
import LobbyScreen from '../features/lobby/LobbyScreen';
import CatScreen from '../features/cat/CatScreen';
import WolfScreen from '../features/wolf/WolfScreen';
import { useMusicScene, useSoundEffects } from '../game/useSoundEffects';
import FinaleScreen from '../finale/FinaleScreen';
import { ConnectionVeil, PartnerAway, Toast } from '../features/common/Overlays';

function Game({ role, adapter, onExit }: { role: PlayerRole; adapter: StateAdapter; onExit: () => void }) {
  useSoundEffects(adapter, role);
  return role === 'Cat' ? <CatScreen adapter={adapter} onExit={onExit} /> : <WolfScreen adapter={adapter} onExit={onExit} />;
}

/** Offline mode (?mock=1): the original one-browser flow using the mock adapter. */
function SoloApp() {
  const [role, setRole] = useState<Role>(null);
  const notice = useNotice(gameStateManager);
  const state = useGameState(gameStateManager);
  useMusicScene(state?.status === 'finalizing' ? 'finale' : role ? (role === 'Cat' ? 'cat' : 'wolf') : 'lobby');
  return (
    <>
      {state?.status === 'finalizing' ? <FinaleScreen adapter={gameStateManager} />
        : role ? <Game role={role} adapter={gameStateManager} onExit={() => setRole(null)} /> : <LobbyScreen solo conn="connected" state={null} role={null} onJoin={setRole} onLeave={() => setRole(null)} />}
      <Toast notice={notice} />
    </>
  );
}

/** Real multiplayer. */
function OnlineApp() {
  const [info, setInfo] = useState<SessionInfo>({ conn: 'connecting', role: null });
  const state = useGameState(socketAdapter);
  const notice = useNotice(socketAdapter);

  useEffect(() => {
    const unsub = socketAdapter.subscribeSession(setInfo);
    socketAdapter.connect();
    return unsub;
  }, []);

  const playing = info.role && state && state.status !== 'lobby';
  useMusicScene(info.role && state?.status === 'finalizing' ? 'finale' : playing ? (info.role === 'Cat' ? 'cat' : 'wolf') : 'lobby');
  return (
    <>
      {info.role && state?.status === 'finalizing' ? <FinaleScreen adapter={socketAdapter} />
        : playing
          ? <Game role={info.role!} adapter={socketAdapter} onExit={() => socketAdapter.leave()} />
          : <LobbyScreen conn={info.conn} state={state} role={info.role} onJoin={r => socketAdapter.join(r)} onLeave={() => socketAdapter.leave()} />}
      <ConnectionVeil conn={info.conn} hasRole={!!info.role} />
      <PartnerAway conn={info.conn} state={state} role={info.role} />
      <Toast notice={notice} />
    </>
  );
}

export default function App() {
  const solo = new URLSearchParams(window.location.search).has('mock');
  return solo ? <SoloApp /> : <OnlineApp />;
}
