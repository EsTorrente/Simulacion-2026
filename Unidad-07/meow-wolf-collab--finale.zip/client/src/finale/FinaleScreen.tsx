import { useEffect, useMemo, useRef, useState } from 'react';
import { COMP_ASPECT, fitRect } from '../../../shared/composition';
import { TRAIT_NAMES, analyzeArtwork, hexToHsl } from '../../../shared/world';
import type { StateAdapter } from '../game/stateAdapter';
import { useGameState } from '../game/useAdapter';
import SoundControl from '../features/common/SoundControl';
import { sfx, startAmbience } from '../game/audio';
import { Cosmos } from './Cosmos';
import { loadSprites, placedStickers, renderArt, type Sprites } from './artCanvas';

const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** The shared finale. Both computers get the same artwork and the server's seed, then grow the same world locally. */
export default function FinaleScreen({ adapter }: { adapter: StateAdapter }) {
  const state = useGameState(adapter);
  const calm = reducedMotion();
  const [light, setLight] = useState(calm);
  const [logo, setLogo] = useState<'white' | 'black' | null>(null); // null = pick from the artwork
  const [stage, setStage] = useState(1);
  const [ui, setUi] = useState(true);
  const [run, setRun] = useState(0);                 // bump to replay the transformation
  const [sprites, setSprites] = useState<Sprites | null>(null);
  const [box, setBox] = useState({ w: window.innerWidth, h: window.innerHeight });
  const wrap = useRef<HTMLDivElement>(null), cv = useRef<HTMLCanvasElement>(null), cosmos = useRef<Cosmos | null>(null), tNow = useRef(0), hideTimer = useRef(0);
  const stateRef = useRef(state); stateRef.current = state;
  const lastRun = useRef(0);

  const seed = state?.seed ?? 0;
  const profile = useMemo(() => (stateRef.current ? analyzeArtwork(stateRef.current.letters, stateRef.current.stickers) : null), [seed]); // eslint-disable-line react-hooks/exhaustive-deps
  // Light artwork gets a black logo, dark/saturated artwork a white one; the viewer can flip it.
  const autoLogo: 'white' | 'black' = useMemo(() => {
    if (!profile) return 'white';
    const tot = profile.palette.reduce((n, p) => n + p.weight, 0) || 1;
    return profile.palette.reduce((n, p) => n + hexToHsl(p.color).l * (p.weight / tot), 0) > 0.72 ? 'black' : 'white';
  }, [profile]);
  const logoMode = logo ?? autoLogo;
  const logoRef = useRef(logoMode); logoRef.current = logoMode;

  useEffect(() => {
    const el = wrap.current; if (!el) return;
    const ro = new ResizeObserver(() => setBox({ w: el.clientWidth, h: el.clientHeight })); ro.observe(el); return () => ro.disconnect();
  }, []);
  useEffect(() => {
    const s = stateRef.current; if (!s) return;
    const kinds = Object.values(s.stickers).flat().map(x => x.kind);
    let live = true; loadSprites(kinds).then(sp => { if (live) setSprites(sp); }); return () => { live = false; };
  }, [seed]);

  useEffect(() => {
    const s = stateRef.current, canvas = cv.current;
    if (!s || !profile || !sprites || !canvas || !box.w || !box.h) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5), rect = fitRect(box.w, box.h, COMP_ASPECT, 0.8);
    canvas.width = Math.round(box.w * dpr); canvas.height = Math.round(box.h * dpr);
    const art = renderArt(s, rect, box.w, box.h, dpr, sprites);
    const keep = tNow.current > 9 && run === lastRun.current ? tNow.current : undefined; lastRun.current = run;   // a window resize must not replay the intro
    const c = new Cosmos({ seed, profile, w: box.w, h: box.h, dpr, rect, art, stickers: placedStickers(s, rect), calm, light, startAt: keep, logo: logoRef.current });
    cosmos.current = c; if (!keep) tNow.current = 0;
    const ctx = canvas.getContext('2d')!, stopAmbience = startAmbience(profile.traits);
    let last = performance.now(), raf = 0, lastStage = 0;
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      c.update((now - last) / 1000); last = now; tNow.current = c.t;
      c.render(ctx);
      for (const e of c.events.splice(0, 6)) { if (e === 'bloom') sfx.bloom(); else if (e === 'zap') sfx.zap(); else if (e === 'blip') sfx.blip(); else if (e === 'meow') sfx.meow(); else if (e === 'howl') sfx.howl(); }
      if (c.stage !== lastStage) { lastStage = c.stage; setStage(c.stage); }
    };
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); stopAmbience(); cosmos.current = null; };
  }, [seed, profile, sprites, box.w, box.h, light, calm, run]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { cosmos.current?.setLogo(logoMode); }, [logoMode]);

  // The controls fade away while you play with the world, and come back when you move or press a key.
  const wake = () => { setUi(true); window.clearTimeout(hideTimer.current); hideTimer.current = window.setTimeout(() => setUi(false), 3800); };
  useEffect(() => { wake(); return () => window.clearTimeout(hideTimer.current); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    let typed = '';
    const k = (e: KeyboardEvent) => {
      if (e.key.length === 1) { // easter eggs: type a word while the world is on screen
        typed = (typed + e.key.toLowerCase()).slice(-4);
        const word = (['meow', 'awoo', 'eyes'] as const).find(w => typed.endsWith(w)); if (word) { typed = ''; cosmos.current?.delight(word); }
      }
      if (e.key === 'l' || e.key === 'L') setLogo(logoRef.current === 'white' ? 'black' : 'white'); if (e.key === 'r' || e.key === 'R') setRun(n => n + 1); wake(); };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (!state || !profile) return null;
  const traitText = TRAIT_NAMES.filter(k => profile.traits[k] > 0.3).sort((a, b) => profile.traits[b] - profile.traits[a]).map(k => `${k} ${Math.round(profile.traits[k] * 100)}%`).join('  ·  ');
  const pos = (e: React.PointerEvent) => { const r = e.currentTarget.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top] as const; };
  const onBtn = (e: React.PointerEvent) => (e.target as HTMLElement).closest('button');

  return (
    <div ref={wrap} style={{ position: 'fixed', inset: 0, zIndex: 20, background: '#04020a', overflow: 'hidden', touchAction: 'none', cursor: stage === 3 ? 'none' : 'default' }}
      onPointerMove={e => { const [x, y] = pos(e); cosmos.current?.move(x, y); wake(); }}
      onPointerDown={e => { if (onBtn(e)) return; const [x, y] = pos(e); cosmos.current?.down(x, y); }}
      onPointerUp={() => cosmos.current?.up()} onPointerLeave={() => cosmos.current?.leave()} onPointerCancel={() => cosmos.current?.leave()}>
      <canvas ref={cv} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
      <div style={{ position: 'absolute', top: 62, left: 0, right: 0, textAlign: 'center', pointerEvents: 'none', opacity: ui || stage < 3 ? 1 : 0, transition: 'opacity .8s' }}>
        <div style={{ color: '#fff', textShadow: '0 0 14px #ff2d9b, 0 0 30px #8a2be2', letterSpacing: '0.34em', fontSize: '0.85rem', fontWeight: 600 }}>
          {stage === 1 ? 'YOUR CREATION' : stage === 2 ? 'IT COMES ALIVE' : 'YOUR COLORS · YOUR STICKERS · YOUR WORLD'}
        </div>
        {stage === 3 && <div style={{ fontSize: '0.72rem', color: '#b9b2d6', marginTop: 6 }}>grown from: {traitText || 'your colors'}</div>}
      </div>
      {stage === 3 && (
        <div style={{ position: 'absolute', bottom: 18, left: 0, right: 0, textAlign: 'center', fontSize: '0.78rem', color: '#cfc8ee', pointerEvents: 'none', opacity: ui ? 0.9 : 0, transition: 'opacity .8s', textShadow: '0 0 8px #000' }}>
          move to stir it · click to grow something · hold &amp; drag to paint · touch the letters · poke an eye · try typing a sound
        </div>
      )}
      <div className="theme-cat" style={{ position: 'absolute', top: 12, right: 12, display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end', opacity: ui ? 1 : 0, pointerEvents: ui ? 'auto' : 'none', transition: 'opacity .6s' }}>
        <button className="btn small" onClick={() => setRun(n => n + 1)} title="Watch the transformation again (R)">Replay</button>
        <button className="btn small" onClick={() => setLogo(logoMode === 'white' ? 'black' : 'white')} title="Flip the logo color (L)">Logo: {logoMode}</button>
        <button className="btn small" onClick={() => adapter.replayFinale()}>Grow another</button>
        <button className="btn small" onClick={() => setLight(l => !l)}>{light ? 'Full quality' : 'Light mode'}</button>
        <button className="btn small" onClick={() => adapter.reopenStudio()}>Back to studio</button>
      </div>
      <SoundControl floating="bl" />
    </div>
  );
}
