import { describe, it, expect } from 'vitest';
import { COMP_ASPECT, LETTER_CELL, fitRect, stickerToComp } from '../../../shared/composition';
import { analyzeArtwork, type Traits } from '../../../shared/world';
import { LETTER_IDS, type GameState, type PlacedSticker, type Stroke } from '../../../shared/types';
import { WorldSim } from './WorldSim';

const empty = <T,>() => Object.fromEntries(LETTER_IDS.map(id => [id, [] as T[]])) as unknown as Record<(typeof LETTER_IDS)[number], T[]>;
const line = (color: string): Stroke => ({ color, brushSize: 5, points: Array.from({ length: 30 }, (_, i) => ({ x: 100 + i * 15, y: 300 + (i % 5) * 10 })) });
const sticker = (kind: string, i = 0): PlacedSticker => ({ id: `st${i}`, kind, x: 0.3 + 0.1 * i, y: 0.5, scale: 1, rotation: 0 });

function art(color: string | null, kinds: string[] = []) {
  const letters = empty<Stroke>() as GameState['letters'];
  const stickers = empty<PlacedSticker>() as GameState['stickers'];
  if (color) letters.M.push(line(color));
  kinds.forEach((k, i) => stickers.E.push(sticker(k, i)));
  return analyzeArtwork(letters, stickers);
}
const top = (t: Traits) => (Object.keys(t) as (keyof Traits)[]).sort((a, b) => t[b] - t[a])[0];

describe('composition layout', () => {
  it('gives every letter its own cell in a 4x2 grid', () => {
    const cells = new Set(LETTER_IDS.map(id => `${LETTER_CELL[id].col},${LETTER_CELL[id].row}`));
    expect(cells.size).toBe(8);
    expect(COMP_ASPECT).toBe(2);
  });
  it('fits any viewport without cropping and keeps the aspect', () => {
    for (const [w, h] of [[1920, 1080], [400, 800], [1000, 300]]) {
      const r = fitRect(w, h, COMP_ASPECT);
      expect(r.w <= w && r.h <= h && r.x >= 0 && r.y >= 0).toBe(true);
      expect(Math.abs(r.w / r.h - 2) < 1e-9).toBe(true);
    }
  });
  it('maps stickers into 0..1 composition space', () => {
    const p = stickerToComp('F', 1, 1);
    expect(p.x).toBe(1); expect(p.y).toBe(1);
  });
});

describe('artwork analysis', () => {
  it('plain pink ink is a flowing world', () => expect(top(art('#ff007f').traits)).toBe('flow'));
  it('flowers + green grow', () => expect(top(art('#ccff00', ['flower']).traits)).toBe('growth'));
  it('skulls + red burn', () => expect(top(art('#ff2200', ['skull']).traits)).toBe('fire'));
  it('bolts + cyan spark', () => expect(top(art('#00ffff', ['bolt']).traits)).toBe('electric'));
  it('eyes watch', () => expect(top(art(null, ['eye', 'eye']).traits)).toBe('watching'));
  it('mixed art blends influences', () => {
    const t = art('#ccff00', ['flower', 'skull']).traits;
    expect(t.growth > 0.5 && t.fire > 0.5).toBe(true);
  });
  it('keeps ink sources inside the composition', () => {
    const p = art('#ff007f');
    expect(p.ink.length > 0 && p.ink.every(s => s.x >= 0 && s.x <= 1 && s.y >= 0 && s.y <= 1)).toBe(true);
  });
});

const make = (profile: ReturnType<typeof art>, seed = 42, calm = false) =>
  new WorldSim({ seed, profile, width: 96, height: 54, agents: 500, compRect: { x: 0.15, y: 0.25, w: 0.7, h: 0.5 }, calm });
function run(s: WorldSim, steps: number) { for (let i = 0; i < steps; i++) s.step(0.05); return s; }

describe('procedural world', () => {
  it('same seed + artwork => same world', () => {
    const p = art('#ccff00', ['flower']);
    expect(run(make(p), 40).checksum()).toBe(run(make(p), 40).checksum());
  });
  it('different seed or artwork => different world', () => {
    const p = art('#ccff00', ['flower']);
    expect(run(make(p, 1), 40).checksum() === run(make(p, 2), 40).checksum()).toBe(false);
    expect(run(make(art('#ff2200', ['skull'])), 40).checksum() === run(make(p), 40).checksum()).toBe(false);
  });
  it('flower art blooms, bolt art zaps, and calm mode never flashes', () => {
    expect(run(make(art('#ccff00', ['flower'])), 200).events.includes('bloom')).toBe(true);
    expect(run(make(art('#00ffff', ['bolt'])), 200).events.includes('zap')).toBe(true);
    expect(run(make(art('#00ffff', ['bolt']), 42, true), 200).events.includes('zap')).toBe(false);
  });
  it('different art activates different behaviors', () => {
    const on = (s: WorldSim) => s.behaviors.filter(x => x.w > 0.5).map(x => x.b.id).sort().join();
    expect(on(make(art('#ccff00', ['flower'])))).toBe('bloom');
    expect(on(make(art('#ff2200', ['skull'])))).toBe('fire');
  });
  it('paints valid pixels', () => {
    const s = run(make(art('#ff007f')), 10); const px = new Uint8ClampedArray(96 * 54 * 4); s.paint(px);
    expect(px[3]).toBe(255);
  });
});
