// Pluggable behaviors layered on top of the Physarum core. Each one has a weight (0..1) taken from
// the artwork's traits and can (a) change agents/trails in update() and (b) paint effects in draw().
// To add one: write a class, add it to createBehaviors(), pick which trait drives it.
import type { Traits } from '../../../shared/world';
import type { WorldSim } from './WorldSim';

export interface Behavior {
  id: string;
  weight(t: Traits): number;
  update(sim: WorldSim, dt: number, w: number): void;
  draw?(ctx: CanvasRenderingContext2D, sim: WorldSim, w: number, view: { w: number; h: number }): void;
}

const TAU = Math.PI * 2;
const angleDiff = (to: number, from: number) => Math.atan2(Math.sin(to - from), Math.cos(to - from));
/** Cheap deterministic smooth-ish noise in 0..1. */
const noise = (x: number, y: number, t: number) => {
  const v = Math.sin(x * 12.9898 + y * 78.233 + t * 37.719) * 43758.5453;
  return v - Math.floor(v);
};
const smoothNoise = (x: number, y: number, t: number) => {
  const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
  const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
  const a = noise(xi, yi, t), b = noise(xi + 1, yi, t), c = noise(xi, yi + 1, t), d = noise(xi + 1, yi + 1, t);
  return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
};

/** Growth: flowers and green ink stamp petal-shaped blooms and seed new branches there. */
class Bloom implements Behavior {
  id = 'bloom'; private next = 1.2;
  weight(t: Traits) { return t.growth; }
  update(sim: WorldSim, dt: number, w: number) {
    this.next -= dt; if (this.next > 0) return;
    this.next = (2.2 + sim.rng() * 2.5) / (0.4 + w);
    const src = sim.pickSource('flower') ?? sim.pickSource(null); if (!src) return;
    const sp = sim.speciesFor('growth'), petals = 5 + Math.floor(sim.rng() * 3), R = 6 + sim.rng() * 10 * (0.5 + w);
    for (let i = 0; i < 260; i++) {
      const th = (i / 260) * TAU, r = R * Math.abs(Math.cos((petals * th) / 2));
      sim.deposit(sp, src.gx + Math.cos(th) * r, src.gy + Math.sin(th) * r, 1.8);
    }
    sim.relocate(sp, src.gx, src.gy, 40);
    sim.emit('bloom');
  }
}

/** Fire: skulls and red/dark ink make agents turbulent and rising, with drifting embers. */
class Fire implements Behavior {
  id = 'fire';
  private embers: { x: number; y: number; vx: number; vy: number; life: number; hue: number }[] = [];
  weight(t: Traits) { return t.fire; }
  update(sim: WorldSim, dt: number, w: number) {
    const { N, ax, ay, aa, time } = sim;
    for (let i = 0; i < N; i++) {
      const n = smoothNoise(ax[i] * 0.06, ay[i] * 0.06, time * 0.25);
      aa[i] += (n - 0.5) * 0.7 * w;                                   // turbulence
      aa[i] += Math.sin(-Math.PI / 2 - aa[i]) * 0.04 * w;             // flames rise
    }
    const max = sim.calm ? 40 : 140;
    const skulls = sim.sourcesOf('skull');
    while (this.embers.length < max * w && sim.rng() < 0.5) {
      const s = skulls.length && sim.rng() < 0.7 ? skulls[Math.floor(sim.rng() * skulls.length)] : sim.pickSource(null);
      if (!s) break;
      this.embers.push({ x: s.gx, y: s.gy, vx: (sim.rng() - 0.5) * 4, vy: -(2 + sim.rng() * 5), life: 1.5 + sim.rng() * 2, hue: 8 + sim.rng() * 30 });
    }
    for (const e of this.embers) {
      e.vx += (smoothNoise(e.x * 0.08, e.y * 0.08, time * 0.5) - 0.5) * 10 * dt;
      e.x += e.vx * dt * 3; e.y += e.vy * dt * 3; e.life -= dt;
    }
    this.embers = this.embers.filter(e => e.life > 0 && e.y > -5);
  }
  draw(ctx: CanvasRenderingContext2D, sim: WorldSim, w: number, view: { w: number; h: number }) {
    const sx = view.w / sim.W, sy = view.h / sim.H;
    ctx.globalCompositeOperation = 'lighter';
    for (const e of this.embers) {
      const a = Math.min(1, e.life) * 0.7 * w;
      ctx.fillStyle = `hsla(${e.hue},100%,55%,${a * 0.25})`; ctx.beginPath(); ctx.arc(e.x * sx, e.y * sy, 6, 0, TAU); ctx.fill();
      ctx.fillStyle = `hsla(${e.hue + 15},100%,70%,${a})`; ctx.beginPath(); ctx.arc(e.x * sx, e.y * sy, 1.8, 0, TAU); ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  }
}

/** Electric: lightning stickers and bright ink fire arcs that also leave glowing trails agents follow. */
class Electric implements Behavior {
  id = 'electric'; private next = 1;
  private arcs: { pts: { x: number; y: number }[]; life: number; color: string }[] = [];
  weight(t: Traits) { return t.electric; }
  update(sim: WorldSim, dt: number, w: number) {
    for (const a of this.arcs) a.life -= dt * 3.5;
    this.arcs = this.arcs.filter(a => a.life > 0);
    this.next -= dt; if (this.next > 0) return;
    this.next = (1.6 + sim.rng() * 2.4) / (0.4 + w);
    const a = sim.pickSource('bolt') ?? sim.pickSource(null), b = sim.pickSource(null); if (!a || !b) return;
    const pts = [{ x: a.gx, y: a.gy }]; const segs = 14;
    for (let i = 1; i < segs; i++) {
      const f = i / segs;
      pts.push({ x: a.gx + (b.gx - a.gx) * f + (sim.rng() - 0.5) * 12, y: a.gy + (b.gy - a.gy) * f + (sim.rng() - 0.5) * 12 });
    }
    pts.push({ x: b.gx, y: b.gy });
    const sp = sim.speciesFor('electric');
    for (let i = 1; i < pts.length; i++) {
      for (let k = 0; k < 4; k++) sim.deposit(sp, pts[i - 1].x + ((pts[i].x - pts[i - 1].x) * k) / 4, pts[i - 1].y + ((pts[i].y - pts[i - 1].y) * k) / 4, 3);
    }
    sim.relocate(sp, a.gx, a.gy, 30);
    if (!sim.calm) { this.arcs.push({ pts, life: 1, color: '#e8ffff' }); sim.emit('zap'); } // no flashes in calm mode
  }
  draw(ctx: CanvasRenderingContext2D, sim: WorldSim, w: number, view: { w: number; h: number }) {
    const sx = view.w / sim.W, sy = view.h / sim.H;
    ctx.globalCompositeOperation = 'lighter'; ctx.lineJoin = 'round';
    for (const a of this.arcs) {
      ctx.strokeStyle = `rgba(0,255,255,${a.life * 0.35 * w})`; ctx.lineWidth = 7;
      ctx.beginPath(); a.pts.forEach((p, i) => (i ? ctx.lineTo(p.x * sx, p.y * sy) : ctx.moveTo(p.x * sx, p.y * sy))); ctx.stroke();
      ctx.strokeStyle = `rgba(240,255,255,${a.life * 0.9})`; ctx.lineWidth = 1.5; ctx.stroke();
    }
    ctx.globalCompositeOperation = 'source-over';
  }
}

/** Watching: agents spiral around eye stickers; the eyes follow the pointer. */
class Watchers implements Behavior {
  id = 'watchers';
  weight(t: Traits) { return t.watching; }
  update(sim: WorldSim, _dt: number, w: number) {
    const eyes = sim.sourcesOf('eye').slice(0, 6); if (!eyes.length) return;
    const { N, ax, ay, aa } = sim, R2 = 18 * 18;
    for (let i = 0; i < N; i++) {
      for (const e of eyes) {
        const dx = ax[i] - e.gx, dy = ay[i] - e.gy, d2 = dx * dx + dy * dy;
        if (d2 < R2 && d2 > 1) { aa[i] += angleDiff(Math.atan2(dy, dx) + Math.PI / 2 + 0.3, aa[i]) * 0.08 * w; break; }
      }
    }
  }
  draw(ctx: CanvasRenderingContext2D, sim: WorldSim, w: number, view: { w: number; h: number }) {
    const sx = view.w / sim.W, sy = view.h / sim.H, t = sim.time;
    for (const e of sim.sourcesOf('eye').slice(0, 6)) {
      const cx = e.gx * sx, cy = e.gy * sy, r = 16 + Math.sin(t * 1.3 + cx) * 2;
      const dx = sim.pointer.x * view.w - cx, dy = sim.pointer.y * view.h - cy, d = Math.hypot(dx, dy) || 1, off = Math.min(r * 0.45, d * 0.1);
      ctx.fillStyle = `rgba(248,248,248,${0.85 * w})`; ctx.beginPath(); ctx.ellipse(cx, cy, r * 1.5, r, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = `rgba(0,255,255,${0.9 * w})`; ctx.beginPath(); ctx.arc(cx + (dx / d) * off, cy + (dy / d) * off, r * 0.55, 0, TAU); ctx.fill();
      ctx.fillStyle = '#09090b'; ctx.beginPath(); ctx.arc(cx + (dx / d) * off, cy + (dy / d) * off, r * 0.25, 0, TAU); ctx.fill();
    }
  }
}

/** Flow: a slow, drifting vortex over the whole world (always present, strongest for plain pink/violet art). */
class Spiral implements Behavior {
  id = 'spiral';
  weight(t: Traits) { return 0.25 + 0.75 * t.flow; }
  update(sim: WorldSim, _dt: number, w: number) {
    const { N, ax, ay, aa, W, H, time } = sim;
    const cx = W * (0.5 + 0.18 * Math.sin(time * 0.11)), cy = H * (0.5 + 0.18 * Math.cos(time * 0.09));
    for (let i = 0; i < N; i++) {
      aa[i] += angleDiff(Math.atan2(ay[i] - cy, ax[i] - cx) + Math.PI / 2 + 0.4, aa[i]) * 0.012 * w;
    }
  }
}

export const createBehaviors = (): Behavior[] => [new Spiral(), new Bloom(), new Fire(), new Electric(), new Watchers()];
