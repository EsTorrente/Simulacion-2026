// Physarum-inspired world. Thousands of agents sense trails left by their own kind, turn toward
// stronger trails, move, and leave more trail; trails diffuse and fade. The artwork picks the
// colors (species), where agents start, and which behaviors (see behaviors.ts) are active.
// Everything random goes through the seeded rng, so a seed + artwork always grows the same world.
// No DOM in here: it can be tested in Node.
import { TRAIT_COLOR, TRAIT_NAMES, hexToHsl, mulberry32, type ArtworkProfile, type TraitName, type Traits } from '../../../shared/world';
import { createBehaviors, type Behavior } from './behaviors';

export interface Rect { x: number; y: number; w: number; h: number; } // normalized 0..1 of the viewport
export interface SimOptions {
  seed: number; profile: ArtworkProfile;
  width: number; height: number;   // grid cells
  agents: number; compRect: Rect;
  calm?: boolean;                  // reduced motion: slower, no flashes
}
export interface GridSource { gx: number; gy: number; kind: string; color: string; }

const hexToRgb = (hex: string): [number, number, number] => {
  const n = parseInt(hex.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const colorDist = (a: [number, number, number], b: [number, number, number]) =>
  (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2;

export interface Species { rgb: [number, number, number]; tag: TraitName | null; }

export class WorldSim {
  readonly W: number; readonly H: number; readonly N: number;
  readonly traits: Traits; readonly profile: ArtworkProfile; readonly calm: boolean;
  readonly rng: () => number;
  readonly species: Species[] = [];
  readonly trails: Float32Array[] = [];
  private scratch: Float32Array;
  readonly ax: Float32Array; readonly ay: Float32Array; readonly aa: Float32Array; readonly as: Uint8Array;
  readonly inkSources: GridSource[] = [];
  readonly stickerSources: GridSource[] = [];
  readonly events: string[] = [];
  readonly behaviors: { b: Behavior; w: number }[] = [];
  pointer = { x: 0.5, y: 0.5 }; // normalized, set by the UI (eyes follow it)
  time = 0;
  p = { sensorAngle: 0.5, sensorDist: 7, turn: 0.4, speed: 1, decay: 0.94, noise: 0.1, deposit: 0.8 };

  constructor(o: SimOptions) {
    this.W = o.width; this.H = o.height; this.N = o.agents;
    this.profile = o.profile; this.traits = o.profile.traits; this.calm = !!o.calm;
    this.rng = mulberry32(o.seed);
    this.buildSpecies();
    for (let i = 0; i < this.species.length; i++) this.trails.push(new Float32Array(this.W * this.H));
    this.scratch = new Float32Array(this.W * this.H);
    this.ax = new Float32Array(this.N); this.ay = new Float32Array(this.N);
    this.aa = new Float32Array(this.N); this.as = new Uint8Array(this.N);

    const t = this.traits;
    this.p = {
      sensorAngle: 0.35 + 0.35 * t.fire + 0.25 * t.electric - 0.1 * t.growth,
      sensorDist: 5 + 5 * t.growth + 3 * t.flow,
      turn: 0.3 + 0.3 * t.fire,
      speed: (0.7 + 0.9 * t.electric + 0.4 * t.fire) * (this.calm ? 0.6 : 1),
      decay: Math.min(0.975, Math.max(0.88, 0.94 - 0.05 * t.fire + 0.03 * t.growth)),
      noise: 0.05 + 0.4 * t.fire + 0.1 * t.watching,
      deposit: 0.6 + 0.4 * t.growth,
    };

    for (const s of o.profile.ink) this.inkSources.push(this.toGrid(s.x, s.y, s.kind, s.color, o.compRect));
    for (const s of o.profile.stickers) this.stickerSources.push(this.toGrid(s.x, s.y, s.kind, s.color, o.compRect));
    this.seedArtwork(o.compRect);
    for (const b of createBehaviors()) this.behaviors.push({ b, w: Math.min(1, b.weight(t)) });
  }

  private toGrid(x: number, y: number, kind: string, color: string, r: Rect): GridSource {
    return { gx: (r.x + x * r.w) * this.W, gy: (r.y + y * r.h) * this.H, kind, color };
  }

  /** Species = the artwork's top colors, plus a color for each strong trait so behaviors have ink to use. */
  private buildSpecies() {
    const add = (hex: string, tag: TraitName | null) => {
      if (this.species.length >= 4) return;
      const rgb = hexToRgb(hex);
      if (this.species.some(s => colorDist(s.rgb, rgb) < 3000)) return;
      this.species.push({ rgb, tag });
    };
    const familyTag = (hex: string): TraitName | null => {
      const { h, s, l } = hexToHsl(hex);
      if (s < 0.15 || l < 0.22) return null;
      if (h >= 55 && h < 170) return 'growth';
      if (h >= 170 && h < 255) return 'electric';
      if (h >= 255 && h < 335) return 'flow';
      return 'fire';
    };
    this.profile.palette.slice(0, 3).forEach(p => add(p.color, familyTag(p.color)));
    [...TRAIT_NAMES].sort((a, b) => this.traits[b] - this.traits[a]).forEach(k => { if (this.traits[k] > 0.3) add(TRAIT_COLOR[k], k); });
    if (this.species.length === 0) add('#ff007f', 'flow');
  }

  speciesFor(tag: TraitName): number {
    const i = this.species.findIndex(s => s.tag === tag);
    return i >= 0 ? i : 0;
  }
  nearestSpecies(hex: string): number {
    const rgb = hexToRgb(hex);
    let best = 0, bd = Infinity;
    this.species.forEach((s, i) => { const d = colorDist(s.rgb, rgb); if (d < bd) { bd = d; best = i; } });
    return best;
  }

  /** The typography itself becomes the first trails, and most agents start on it. */
  private seedArtwork(r: Rect) {
    const all = [...this.inkSources, ...this.stickerSources];
    for (const s of all) {
      const sp = this.nearestSpecies(s.color);
      this.deposit(sp, s.gx, s.gy, 1.5);
      this.deposit(sp, s.gx + 1, s.gy, 0.8); this.deposit(sp, s.gx, s.gy + 1, 0.8);
    }
    for (let i = 0; i < this.N; i++) {
      if (all.length && this.rng() < 0.75) {
        const s = all[Math.floor(this.rng() * all.length)];
        this.ax[i] = s.gx + (this.rng() - 0.5) * 2; this.ay[i] = s.gy + (this.rng() - 0.5) * 2;
        this.as[i] = this.nearestSpecies(s.color);
      } else {
        this.ax[i] = (r.x + this.rng() * r.w) * this.W; this.ay[i] = (r.y + this.rng() * r.h) * this.H;
        this.as[i] = Math.floor(this.rng() * this.species.length);
      }
      this.aa[i] = this.rng() * Math.PI * 2;
    }
  }

  deposit(sp: number, x: number, y: number, amount: number) {
    const ix = Math.round(x), iy = Math.round(y);
    if (ix < 0 || iy < 0 || ix >= this.W || iy >= this.H) return;
    const t = this.trails[sp], k = iy * this.W + ix;
    t[k] = Math.min(6, t[k] + amount);
  }

  pickSource(kind: string | null): GridSource | null {
    const list = kind ? this.stickerSources.filter(s => s.kind === kind) : this.inkSources.length ? this.inkSources : this.stickerSources;
    return list.length ? list[Math.floor(this.rng() * list.length)] : null;
  }
  sourcesOf(kind: string) { return this.stickerSources.filter(s => s.kind === kind); }

  /** Move some agents of one species to a point, so new growth starts there. */
  relocate(sp: number, x: number, y: number, count: number) {
    let moved = 0;
    for (let tries = 0; tries < count * 6 && moved < count; tries++) {
      const i = Math.floor(this.rng() * this.N);
      if (this.as[i] !== sp) continue;
      this.ax[i] = x + (this.rng() - 0.5) * 3; this.ay[i] = y + (this.rng() - 0.5) * 3;
      this.aa[i] = this.rng() * Math.PI * 2; moved++;
    }
  }
  emit(name: string) { if (this.events.length < 16) this.events.push(name); }

  private sample(t: Float32Array, x: number, y: number) {
    const ix = ((Math.round(x) % this.W) + this.W) % this.W, iy = ((Math.round(y) % this.H) + this.H) % this.H;
    return t[iy * this.W + ix];
  }

  /** One fixed time step. */
  step(dt: number) {
    this.time += dt;
    const { W, H, N, p } = this;
    for (const { b, w } of this.behaviors) if (w > 0.05) b.update(this, dt, w);

    for (let i = 0; i < N; i++) {
      const t = this.trails[this.as[i]];
      let a = this.aa[i], x = this.ax[i], y = this.ay[i];
      const l = this.sample(t, x + Math.cos(a - p.sensorAngle) * p.sensorDist, y + Math.sin(a - p.sensorAngle) * p.sensorDist);
      const f = this.sample(t, x + Math.cos(a) * p.sensorDist, y + Math.sin(a) * p.sensorDist);
      const r = this.sample(t, x + Math.cos(a + p.sensorAngle) * p.sensorDist, y + Math.sin(a + p.sensorAngle) * p.sensorDist);
      if (f > l && f > r) { /* keep going straight */ }
      else if (f < l && f < r) a += (this.rng() - 0.5) * 2 * p.turn;
      else if (l < r) a += p.turn;
      else if (r < l) a -= p.turn;
      a += (this.rng() - 0.5) * p.noise;
      x += Math.cos(a) * p.speed; y += Math.sin(a) * p.speed;
      x = (x + W) % W; y = (y + H) % H;
      this.aa[i] = a; this.ax[i] = x; this.ay[i] = y;
      const k = (y | 0) * W + (x | 0);
      t[k] = Math.min(6, t[k] + p.deposit);
    }

    // Diffuse and fade every species' trail.
    for (const t of this.trails) {
      const s = this.scratch;
      for (let y = 1; y < H - 1; y++) {
        for (let x = 1; x < W - 1; x++) {
          const k = y * W + x;
          s[k] = (t[k] * 0.5 + (t[k - 1] + t[k + 1] + t[k - W] + t[k + W]) * 0.125) * p.decay;
        }
      }
      t.set(s);
    }
  }

  /** Write the trails as RGBA pixels (one pixel per grid cell). */
  paint(out: Uint8ClampedArray) {
    const n = this.W * this.H, K = this.trails.length;
    for (let k = 0; k < n; k++) {
      let r = 0, g = 0, b = 0;
      for (let s = 0; s < K; s++) {
        const v = this.trails[s][k]; if (v < 0.01) continue;
        const rgb = this.species[s].rgb; r += rgb[0] * v; g += rgb[1] * v; b += rgb[2] * v;
      }
      const o = k * 4;
      // soft tone-map: dark violet-black background, colors bloom toward white when dense
      out[o] = 9 + 246 * (1 - Math.exp(-r / 110));
      out[o + 1] = 9 + 246 * (1 - Math.exp(-g / 110));
      out[o + 2] = 14 + 241 * (1 - Math.exp(-b / 110));
      out[o + 3] = 255;
    }
  }

  /** A number summarizing the trails (used by tests to compare worlds). */
  checksum(): number {
    let sum = 0;
    for (const t of this.trails) for (let i = 0; i < t.length; i += 7) sum += t[i] * ((i % 13) + 1);
    return Math.round(sum * 1000) / 1000;
  }
}
