// Procedural pieces of the final world. Which of them appear, and how many, comes from the artwork's traits.
import type { Traits } from '../../../shared/world';

const TAU = Math.PI * 2;
type Rng = () => number;
const pickW = <T,>(items: [T, number][], rng: Rng): T => {
  const total = items.reduce((n, [, w]) => n + w, 0); let r = rng() * total;
  for (const [t, w] of items) { r -= w; if (r <= 0) return t; }
  return items[0][0];
};

// ---------- glow sprite (cheap soft light, used instead of expensive shadowBlur) ----------
const glowCache = new Map<string, HTMLCanvasElement>();
export function glowSprite(css: string): HTMLCanvasElement {
  let c = glowCache.get(css);
  if (!c) {
    c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d')!, g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, '#fff'); g.addColorStop(0.18, css); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64); glowCache.set(css, c);
  }
  return c;
}

// ---------- parallax silhouette layers ----------
type Shape = 'mushroom' | 'flame' | 'crystal' | 'kelp' | 'fern' | 'root' | 'tuft';

function shapePath(kind: Shape, x: number, by: number, hgt: number, rng: Rng): { path: Path2D; spots: [number, number, number][]; detail: Path2D } {
  const p = new Path2D(), spots: [number, number, number][] = [], detail = new Path2D(); // detail = thin inner lines (gills, facets, veins)
  if (kind === 'mushroom') {
    const sw = hgt * (0.07 + rng() * 0.05), rx = hgt * (0.2 + rng() * 0.24), ch = hgt * (0.22 + rng() * 0.14), top = by - hgt, lean = (rng() - 0.5) * hgt * 0.34, bulge = 1 + rng() * 0.9;
    p.moveTo(x - sw * bulge, by);
    p.bezierCurveTo(x - sw * 0.4 + lean * 0.3, by - hgt * 0.3, x - sw * 0.5 + lean, by - hgt * 0.62, x - sw * 0.7 + lean * 0.8, top + ch); // curved stem, flared foot
    const lx = lean * 0.8; // the cap sits on top of the leaning stem
    p.lineTo(x - rx * 0.92 + lx, top + ch * 1.1);
    for (let i = 0; i < 5; i++) { const a = x - rx * 0.92 + lx + (rx * 1.84 * (i + 0.5)) / 5; p.quadraticCurveTo(a, top + ch * (1.34 + 0.12 * (i % 2)), x - rx * 0.92 + lx + (rx * 1.84 * (i + 1)) / 5, top + ch * 1.1); } // ruffled gill edge
    p.bezierCurveTo(x + rx * 1.25 + lx, top + ch * 0.25, x + rx * 0.55 + lx, top - ch * 0.3, x + lx * 0.2, top);
    p.bezierCurveTo(x - rx * 0.55 + lx, top - ch * 0.3, x - rx * 1.25 + lx, top + ch * 0.25, x - rx * 0.92 + lx, top + ch * 1.1);
    p.moveTo(x + sw * 0.7 + lx, top + ch); p.quadraticCurveTo(x + sw * 0.5 + lean, by - hgt * 0.62, x + sw * bulge, by); p.lineTo(x - sw * bulge, by); p.closePath();
    for (let i = 0; i < 6; i++) { const gx = x + lx + (i - 2.5) * rx * 0.3; detail.moveTo(gx, top + ch * 1.15); detail.lineTo(x + lx * 0.6 + (gx - x - lx) * 0.3, top + ch * 0.55); } // gills
    for (let i = 0; i < 5; i++) spots.push([x + lx + (rng() - 0.5) * rx * 1.3, top + ch * (0.2 + rng() * 0.45), 1.5 + rng() * hgt * 0.03]);
    if (rng() < 0.45) { const sx = x + (rng() < 0.5 ? -1 : 1) * rx * 0.9, sh = hgt * (0.3 + rng() * 0.2), sr = rx * 0.38; // a little baby mushroom beside it
      p.moveTo(sx - sw * 0.4, by); p.quadraticCurveTo(sx, by - sh * 0.5, sx - sw * 0.3, by - sh); p.bezierCurveTo(sx - sr * 1.2, by - sh - sr * 0.4, sx + sr * 1.2, by - sh - sr * 0.4, sx + sw * 0.3, by - sh); p.quadraticCurveTo(sx, by - sh * 0.5, sx + sw * 0.4, by); p.closePath(); }
  } else if (kind === 'flame') {
    for (let k = -1; k <= 1; k++) {
      const bx = x + k * hgt * 0.1, h = hgt * (k === 0 ? 1 : 0.55 + rng() * 0.25), w = hgt * 0.1, sway = (rng() - 0.5) * hgt * 0.25;
      p.moveTo(bx - w, by); p.quadraticCurveTo(bx - w * 0.2 + sway, by - h * 0.55, bx + sway * 1.4, by - h);
      p.quadraticCurveTo(bx + w * 0.8 + sway, by - h * 0.5, bx + w, by); p.closePath();
    }
  } else if (kind === 'crystal') {
    const n = 3 + Math.floor(rng() * 3);
    for (let i = 0; i < n; i++) {
      const cx = x + (i - n / 2) * hgt * 0.1, h = hgt * (0.45 + rng() * 0.55), bw = hgt * (0.08 + rng() * 0.07), tilt = (rng() - 0.5) * hgt * 0.18;
      p.moveTo(cx - bw, by); p.lineTo(cx - bw * 0.9 + tilt, by - h * 0.82); p.lineTo(cx + tilt, by - h);
      p.lineTo(cx + bw * 0.9 + tilt, by - h * 0.82); p.lineTo(cx + bw, by); p.closePath();
      detail.moveTo(cx + tilt, by - h); detail.lineTo(cx + bw * 0.1, by - h * 0.1); detail.moveTo(cx - bw * 0.9 + tilt, by - h * 0.82); detail.lineTo(cx + bw * 0.1, by - h * 0.1); // facet lines
    }
  } else { // kelp: a swaying tapering ribbon
    const ph = rng() * TAU, L: [number, number][] = [], R: [number, number][] = [];
    for (let i = 0; i <= 14; i++) {
      const t = i / 14, cx = x + Math.sin(t * 4 + ph) * hgt * 0.1 * t, cy = by - hgt * t, w = hgt * 0.06 * (1 - t) + 2;
      L.push([cx - w, cy]); R.push([cx + w, cy]);
    }
    p.moveTo(L[0][0], L[0][1]); L.forEach(q => p.lineTo(q[0], q[1])); R.reverse().forEach(q => p.lineTo(q[0], q[1])); p.closePath();
    for (let i = 0; i < 3; i++) spots.push([x + Math.sin((0.3 + i * 0.2) * 4 + ph) * hgt * 0.03, by - hgt * (0.3 + i * 0.2), 2.4]);
  }
  if (kind === 'fern') { // an arching stem with paired leaflets
    const ph = (rng() - 0.5) * 2, n = 11, dir = rng() < 0.5 ? -1 : 1; let px = x, py = by;
    const L: [number, number][] = [[x, by]];
    for (let i = 1; i <= n; i++) { const t = i / n; px = x + dir * Math.sin(t * 1.6 + ph * 0.3) * hgt * 0.34 * t; py = by - hgt * Math.pow(t, 0.8) * 0.95; L.push([px, py]); }
    p.moveTo(L[0][0] - 3, L[0][1]); L.forEach(q => p.lineTo(q[0] - 2.2 * (1 - q[1] / by) - 1.4, q[1])); for (let i = L.length - 1; i >= 0; i--) p.lineTo(L[i][0] + 2.2 * (1 - L[i][1] / by) + 1.4, L[i][1]); p.closePath();
    for (let i = 2; i < L.length; i++) { const [qx, qy] = L[i], t = i / n, ll = hgt * 0.17 * (1 - t * 0.7); for (const sd of [-1, 1]) { p.moveTo(qx, qy); p.quadraticCurveTo(qx + sd * ll * 0.6, qy - ll * 0.55, qx + sd * ll, qy - ll * 0.1); p.quadraticCurveTo(qx + sd * ll * 0.6, qy - ll * 0.15, qx, qy + 2); p.closePath(); } }
    spots.push([L[n][0], L[n][1], 2.4]);
  } else if (kind === 'root') { // forking tendrils reaching up
    const twig = (bx: number, by0: number, a: number, len: number, w: number, depth: number) => {
      const steps = 7; let cx = bx, cy = by0, ang = a; const R: [number, number][] = [];
      for (let i = 0; i <= steps; i++) { R.push([cx, cy]); ang += (rng() - 0.5) * 0.7; cx += Math.cos(ang) * len / steps; cy += Math.sin(ang) * len / steps; }
      p.moveTo(R[0][0] - w, R[0][1]); R.forEach((q, i) => p.lineTo(q[0] - w * (1 - i / steps), q[1])); for (let i = R.length - 1; i >= 0; i--) p.lineTo(R[i][0] + w * (1 - i / steps), R[i][1]); p.closePath();
      if (depth < 2) for (let k = 2; k < steps - 1; k += 2) if (rng() < 0.7) twig(R[k][0], R[k][1], ang + (rng() < 0.5 ? -1 : 1) * (0.5 + rng() * 0.5), len * 0.55, w * 0.6, depth + 1);
      spots.push([cx, cy, 1.8]);
    };
    for (let i = 0; i < 2 + Math.floor(rng() * 2); i++) twig(x + (i - 1) * hgt * 0.08, by, -Math.PI / 2 + (rng() - 0.5) * 1.1, hgt * (0.55 + rng() * 0.4), hgt * 0.035 + 2, 0);
  } else if (kind === 'tuft') { // small blades of glowing grass, the mid-ground texture
    const n = 5 + Math.floor(rng() * 5);
    for (let i = 0; i < n; i++) { const bx = x + (i - n / 2) * hgt * 0.06, h = hgt * (0.45 + rng() * 0.55), sway = (rng() - 0.5) * hgt * 0.5, w = 1.6 + hgt * 0.025; p.moveTo(bx - w, by); p.quadraticCurveTo(bx + sway * 0.3, by - h * 0.6, bx + sway, by - h); p.quadraticCurveTo(bx + sway * 0.4 + w, by - h * 0.5, bx + w, by); p.closePath(); }
  }
  return { path: p, spots, detail };
}

/** Three depth layers (far -> near). Bigger/darker/brighter-rimmed toward the viewer; wider than the screen so they can shift. */
export function makeLayers(w: number, h: number, dpr: number, rims: string[], t: Traits, rng: Rng): HTMLCanvasElement[] {
  const mix: [Shape, number][] = [
    ['mushroom', 0.3 + 0.7 * (t.watching + t.growth) / 2], ['flame', 0.9 * t.fire], ['crystal', 0.9 * t.electric], ['kelp', 0.3 + 0.6 * t.flow],
    ['fern', 0.15 + 0.8 * t.growth], ['root', 0.15 + 0.45 * (t.flow + t.watching) / 2],
  ];
  return [0, 1, 2].map(depth => {
    const cv = document.createElement('canvas'), W = w * 1.3;
    cv.width = Math.round(W * dpr); cv.height = Math.round(h * dpr);
    const ctx = cv.getContext('2d')!; ctx.scale(dpr, dpr);
    const count = [18, 12, 6][depth], size = [0.26, 0.38, 0.52][depth] * h, fill = ['#0b0720', '#070413', '#030209'][depth], rimA = [0.4, 0.65, 0.95][depth];
    const draw = (flip: boolean, n: number, sizeMul: number) => {
      ctx.save(); if (flip) { ctx.translate(0, h); ctx.scale(1, -1); }
      for (let i = 0; i < n; i++) {
        const kind = pickW(mix, rng), x = rng() * W, giant = depth === 2 && rng() < 0.22 ? 1.4 : 1, hgt = size * sizeMul * giant * (0.4 + Math.pow(rng(), 1.3) * 1.1), rim = rims[Math.floor(rng() * rims.length)]; // a few tall giants, many small ones
        const { path, spots, detail } = shapePath(kind, x, h + 4, hgt, rng);
        ctx.globalAlpha = depth === 0 ? 0.8 : 1; ctx.fillStyle = fill; ctx.fill(path);
        ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = rim; ctx.lineJoin = 'round';
        ctx.globalAlpha = rimA * 0.18; ctx.lineWidth = 9; ctx.stroke(path);
        ctx.globalAlpha = rimA; ctx.lineWidth = 1.8 + depth * 0.5; ctx.stroke(path);
        ctx.globalAlpha = rimA * 0.5; ctx.lineWidth = 1; ctx.stroke(detail);
        ctx.globalAlpha = 0.9; ctx.fillStyle = rim;
        for (const [sx, sy, sr] of spots) { ctx.beginPath(); ctx.arc(sx, sy, sr, 0, TAU); ctx.fill(); }
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
      ctx.restore();
    };
    draw(false, count, 1);
    if (depth === 1) { // mid-ground detail: low glowing grass and little growths between the big shapes
      const saved = mix.slice(); mix.length = 0; mix.push(['tuft', 1], ['mushroom', 0.35], ['fern', 0.3]);
      draw(false, 26, 0.42); mix.length = 0; mix.push(...saved);
    }
    if (depth > 0) draw(true, depth === 2 ? 3 : 3, 0.5); // hanging growths from the top edge frame the scene
    return cv;
  });
}

// ---------- vines and blooms ----------
export interface Seg { x1: number; y1: number; x2: number; y2: number; t: number; d: number; }
export interface BloomT { x: number; y: number; r: number; t: number; col: string; petals: number; rot: number; }
export interface Vine { segs: Seg[]; blooms: BloomT[]; born: number; dur: number; col: string; } // col: the artwork color this vine is grown in
export const MAX_DEPTH = 4;

export function growVine(x: number, y: number, ang: number, scale: number, rng: Rng, cols: string[], born: number, len = 150): Vine {
  const v: Vine = { segs: [], blooms: [], born, dur: 3.4 + rng() * 1.6, col: cols[Math.floor(rng() * cols.length)] };
  const branch = (x0: number, y0: number, a0: number, L: number, d: number, t0: number) => {
    const steps = Math.max(4, Math.round(L / 8)), curl = (rng() - 0.5) * 0.38, stepT = 8 / (L * 2.4 + 120);
    let cx = x0, cy = y0, a = a0, t = t0;
    for (let i = 0; i < steps; i++) {
      a += curl + (rng() - 0.5) * 0.3;
      const nx = cx + Math.cos(a) * 8 * scale, ny = cy + Math.sin(a) * 8 * scale; t += stepT;
      v.segs.push({ x1: cx, y1: cy, x2: nx, y2: ny, t, d });
      if (d < MAX_DEPTH && i > 2 && i < steps - 1 && rng() < 0.1) branch(nx, ny, a + (rng() < 0.5 ? -1 : 1) * (0.55 + rng() * 0.6), L * 0.62, d + 1, t);
      cx = nx; cy = ny;
    }
    if (d >= MAX_DEPTH - 1 || rng() < 0.22) v.blooms.push({ x: cx, y: cy, r: (15 + rng() * 15) * scale, t, col: cols[Math.floor(rng() * cols.length)], petals: 5 + Math.floor(rng() * 4), rot: rng() * TAU });
  };
  branch(x, y, ang, len * scale, 0, 0);
  return v;
}

export function drawBloom(ctx: CanvasRenderingContext2D, b: BloomT, open: number, time: number) {
  const r = b.r * open; if (r < 1) return;
  const pulse = 1 + 0.07 * Math.sin(time * 2 + b.rot), n = b.petals;
  ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.rot + Math.sin(time * 0.5 + b.rot) * 0.18); ctx.fillStyle = b.col;
  ctx.globalAlpha = 0.2; ctx.beginPath(); ctx.arc(0, 0, r * 2.3 * pulse, 0, TAU); ctx.fill();           // soft halo
  ctx.strokeStyle = 'rgba(6,2,16,0.55)'; ctx.lineWidth = 1.2;
  ctx.globalAlpha = 0.95;                                                                              // outer petals: full color, dark outline so they read on any background
  for (let i = 0; i < n; i++) { ctx.rotate(TAU / n); ctx.beginPath(); ctx.ellipse(r * 0.7 * pulse, 0, r * 0.7 * pulse, r * 0.3, 0, 0, TAU); ctx.fill(); ctx.stroke(); }
  ctx.rotate(TAU / n / 2);
  for (let i = 0; i < n; i++) {                                                                        // inner petals: same color, lightened
    ctx.rotate(TAU / n); ctx.globalAlpha = 0.95; ctx.fillStyle = b.col; ctx.beginPath(); ctx.ellipse(r * 0.45 * pulse, 0, r * 0.45 * pulse, r * 0.21, 0, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.4; ctx.fillStyle = '#fff'; ctx.fill();
  }
  ctx.globalAlpha = 1; ctx.fillStyle = '#2a0f3a'; ctx.beginPath(); ctx.arc(0, 0, r * 0.24, 0, TAU); ctx.fill();   // dark heart with golden stamens
  ctx.fillStyle = '#ffe48a'; for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU; ctx.beginPath(); ctx.arc(Math.cos(a) * r * 0.15, Math.sin(a) * r * 0.15, Math.max(1, r * 0.06), 0, TAU); ctx.fill(); }
  ctx.restore();
}

// ---------- lightning ----------
export interface Bolt { pts: [number, number][]; branches: [number, number][][]; ttl: number; max: number; }
export function makeBolt(x1: number, y1: number, x2: number, y2: number, rng: Rng): Bolt {
  const jag = (a: [number, number], b: [number, number], disp: number): [number, number][] => {
    let pts: [number, number][] = [a, b];
    for (let lvl = 0; lvl < 6; lvl++) {
      const next: [number, number][] = [pts[0]];
      for (let i = 1; i < pts.length; i++) {
        const [ax, ay] = pts[i - 1], [bx, by] = pts[i], dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1, o = (rng() - 0.5) * disp / (1 << lvl);
        next.push([(ax + bx) / 2 - (dy / L) * o, (ay + by) / 2 + (dx / L) * o], pts[i]);
      }
      pts = next;
    }
    return pts;
  };
  const len = Math.hypot(x2 - x1, y2 - y1), pts = jag([x1, y1], [x2, y2], len * 0.45), branches: [number, number][][] = [];
  for (let i = 0; i < 4; i++) {
    const s = pts[8 + Math.floor(rng() * (pts.length - 16))], a = Math.atan2(y2 - y1, x2 - x1) + (rng() - 0.5) * 2.2, L = len * (0.12 + rng() * 0.18);
    branches.push(jag(s, [s[0] + Math.cos(a) * L, s[1] + Math.sin(a) * L], L * 0.5));
  }
  const ttl = 0.22 + rng() * 0.18;
  return { pts, branches, ttl, max: ttl };
}

// ---------- eyes ----------
export interface Eye { x: number; y: number; r: number; iris: string; phase: number; born: number; wink?: number; } // wink: 1 right after being poked, fades to 0
const hash = (n: number) => { const v = Math.sin(n * 127.1) * 43758.5453; return v - Math.floor(v); };
/** px/py < -4000 means "no pointer": the eye then glances around on its own, curious. */
export function drawEye(ctx: CanvasRenderingContext2D, e: Eye, time: number, px: number, py: number, open: number) {
  const wink = e.wink ?? 0, bt = (time * 0.55 + e.phase) % 4.2, blink = bt < 0.2 ? Math.sin((bt / 0.2) * Math.PI) : 0;
  const h = open * (1 - 0.92 * blink) * (1 + 0.22 * wink), ry = e.r * 0.64 * h; if (ry < 1.2) return;
  const bob = Math.sin(time * 0.9 + e.phase * 3) * e.r * 0.06, x = e.x, y = e.y + bob;
  let a: number, dist: number;
  if (px < -4000) { // idle: quick glances (saccades) to a new spot every couple of seconds
    const tk = time * 0.42 + e.phase * 7, k = Math.floor(tk), f = Math.min(1, (tk - k) * 7), ease = f * f * (3 - 2 * f);
    const ax = hash(k + e.phase * 9) * TAU, bx = hash(k - 1 + e.phase * 9) * TAU, ad = 0.35 + 0.65 * hash(k * 3 + e.phase), bd = 0.35 + 0.65 * hash((k - 1) * 3 + e.phase);
    const vx = Math.cos(bx) * bd + (Math.cos(ax) * ad - Math.cos(bx) * bd) * ease, vy = Math.sin(bx) * bd + (Math.sin(ax) * ad - Math.sin(bx) * bd) * ease;
    a = Math.atan2(vy, vx); dist = Math.min(1, Math.hypot(vx, vy));
  } else { const dx = px - x, dy = py - y; dist = Math.min(1, Math.hypot(dx, dy) / 320); a = Math.atan2(dy, dx); }
  ctx.save(); ctx.translate(x, y);
  ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.18 + 0.2 * wink; ctx.fillStyle = e.iris; ctx.beginPath(); ctx.ellipse(0, 0, e.r * 1.7, ry * 1.9, 0, 0, TAU); ctx.fill();
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  ctx.beginPath(); ctx.ellipse(0, 0, e.r, ry, 0, 0, TAU); ctx.save(); ctx.clip();
  const sc = ctx.createRadialGradient(0, 0, e.r * 0.2, 0, 0, e.r); sc.addColorStop(0, '#fbf4ff'); sc.addColorStop(1, '#b9a3d8');
  ctx.fillStyle = sc; ctx.fillRect(-e.r, -ry, e.r * 2, ry * 2);
  ctx.strokeStyle = 'rgba(255,60,120,0.35)'; ctx.lineWidth = 1;
  for (let i = 0; i < 6; i++) { const s = i < 3 ? -1 : 1; ctx.beginPath(); ctx.moveTo(s * e.r, (i % 3 - 1) * ry * 0.4); ctx.quadraticCurveTo(s * e.r * 0.6, (i % 3 - 1) * ry * 0.7, s * e.r * 0.4, (i % 3 - 1) * ry * 0.2); ctx.stroke(); }
  const ix = Math.cos(a) * dist * e.r * 0.34, iy = Math.sin(a) * dist * ry * 0.4, ir = Math.min(e.r * 0.52, ry * 1.05);
  const ig = ctx.createRadialGradient(ix, iy, ir * 0.1, ix, iy, ir); ig.addColorStop(0, '#fff'); ig.addColorStop(0.35, e.iris); ig.addColorStop(1, '#10061f');
  ctx.fillStyle = ig; ctx.beginPath(); ctx.arc(ix, iy, ir, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = 1; ctx.beginPath(); // iris fibres
  for (let i = 0; i < 16; i++) { const f = (i / 16) * TAU + e.phase; ctx.moveTo(ix + Math.cos(f) * ir * 0.4, iy + Math.sin(f) * ir * 0.4); ctx.lineTo(ix + Math.cos(f) * ir * 0.94, iy + Math.sin(f) * ir * 0.94); } ctx.stroke();
  ctx.strokeStyle = 'rgba(8,2,20,0.55)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(ix, iy, ir * 0.96, 0, TAU); ctx.stroke(); // dark limbal ring
  const pw = 0.3 + 0.2 * wink; ctx.fillStyle = '#05020c'; ctx.beginPath(); ctx.ellipse(ix, iy, ir * pw, ir * (0.62 + 0.15 * wink), 0, 0, TAU); ctx.fill(); // pupil widens when startled
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ix - ir * 0.3, iy - ir * 0.32, ir * 0.16, 0, TAU); ctx.fill();
  const lid = ctx.createLinearGradient(0, -ry, 0, -ry * 0.25); lid.addColorStop(0, 'rgba(14,4,30,0.6)'); lid.addColorStop(1, 'rgba(14,4,30,0)'); // the upper lid shades the eyeball
  ctx.fillStyle = lid; ctx.fillRect(-e.r, -ry, e.r * 2, ry * 1.1);
  ctx.restore();
  ctx.strokeStyle = e.iris; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, e.r, ry, 0, 0, TAU); ctx.stroke();
  ctx.lineWidth = Math.max(2, e.r * 0.07); ctx.lineCap = 'round'; ctx.beginPath(); ctx.ellipse(0, -ry * 0.04, e.r * 1.02, ry * 1.04, 0, Math.PI * 1.08, Math.PI * 1.92); ctx.stroke(); // heavier upper lid
  ctx.lineWidth = Math.max(1.2, e.r * 0.035); ctx.beginPath(); // lashes fan out along the upper lid
  for (let i = 0; i < 7; i++) { const t = Math.PI * (1.14 + (i / 6) * 0.72), lx = Math.cos(t) * e.r * 1.02, ly = Math.sin(t) * ry * 1.04, L = e.r * (0.16 + 0.07 * (i % 2)); ctx.moveTo(lx, ly); ctx.lineTo(lx + Math.cos(t) * L * 0.8, ly + Math.sin(t) * L * 1.1 - L * 0.2); }
  ctx.stroke();
  ctx.restore();
}
