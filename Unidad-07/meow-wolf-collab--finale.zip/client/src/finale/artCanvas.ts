// Renders the players' finished composition to a canvas (real strokes, real sticker art, real logo glyphs),
// and samples its pixels so the break-apart uses the artwork's own colors and positions.
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { CELL_H, CELL_W, stickerToComp } from '../../../shared/composition';
import { LOGO } from '../../../shared/logo';
import { LETTER_IDS, type GameState } from '../game/types';
import { STICKERS } from '../features/common/stickerArt';
import { paintStrokes } from '../features/common/StrokePreview';

export type Sprites = Record<string, HTMLImageElement>;
export interface Rect { x: number; y: number; w: number; h: number; } // css px
export interface PlacedSticker { kind: string; x: number; y: number; size: number; rot: number; }
export interface InkSample { x: number; y: number; r: number; g: number; b: number; }

const ART_UNITS = 100 * 1.2; // sticker art is ~100 units, drawn at BASE_SCALE 1.2 in the 800-unit letter space

/** Rasterize each sticker kind once (the SVG art is plain colors, so it survives as an image). */
export async function loadSprites(kinds: string[]): Promise<Sprites> {
  const out: Sprites = {};
  await Promise.all([...new Set(kinds)].map(k => new Promise<void>(res => {
    const Art = (STICKERS[k] ?? STICKERS.skull).Art;
    const svg = renderToStaticMarkup(createElement('svg', { xmlns: 'http://www.w3.org/2000/svg', viewBox: '-55 -55 110 110', width: 220, height: 220 }, createElement(Art)));
    const img = new Image();
    img.onload = () => { out[k] = img; res(); };
    img.onerror = () => res();
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  })));
  return out;
}

export const placedStickers = (state: Pick<GameState, 'stickers'>, rect: Rect): PlacedSticker[] => {
  const cellPx = CELL_W * rect.w, out: PlacedSticker[] = [];
  for (const id of LETTER_IDS) for (const s of state.stickers[id] ?? []) {
    const c = stickerToComp(id, s.x, s.y);
    out.push({ kind: s.kind, x: rect.x + c.x * rect.w, y: rect.y + c.y * rect.h, size: ART_UNITS * s.scale * (cellPx / 800), rot: s.rotation });
  }
  return out;
};

/** The finished artwork on a transparent canvas the size of the viewport. */
export function renderArt(state: Pick<GameState, 'letters' | 'stickers'>, rect: Rect, w: number, h: number, dpr: number, sprites: Sprites): HTMLCanvasElement {
  const cv = document.createElement('canvas');
  cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
  (cv as HTMLCanvasElement & { __dpr?: number }).__dpr = dpr;
  const ctx = cv.getContext('2d')!;
  ctx.scale(dpr, dpr);
  const k = (CELL_W * rect.w) / 800;
  for (const id of LETTER_IDS) {
    const g = LOGO[id];
    ctx.save();
    ctx.translate(rect.x + (g.cx - CELL_W / 2) * rect.w, rect.y + (g.cy - CELL_H / 2) * rect.h);
    ctx.scale(k, k);
    const glyph = new Path2D(g.d);
    ctx.globalAlpha = 0.3; ctx.fillStyle = g.color; ctx.fill(glyph);                       // the real logo shape, tinted
    ctx.globalAlpha = 1; ctx.strokeStyle = g.color; ctx.lineWidth = 6; ctx.lineCap = 'round';
    ctx.setLineDash([0.1, 15]); ctx.stroke(glyph); ctx.setLineDash([]);
    paintStrokes(ctx, state.letters[id] ?? [], 0, 0, 0);
    for (const s of state.stickers[id] ?? []) {
      const img = sprites[s.kind]; if (!img) continue;
      ctx.save(); ctx.translate(s.x * 800, s.y * 800); ctx.rotate((s.rotation * Math.PI) / 180); ctx.scale(s.scale * 1.2, s.scale * 1.2);
      ctx.drawImage(img, -55, -55, 110, 110); ctx.restore();
    }
    ctx.restore();
  }
  return cv;
}

/** Random opaque pixels of the artwork (the tinted glyph fill is translucent, so only real ink and stickers qualify). */
export function sampleInk(art: HTMLCanvasElement, count: number, rng: () => number): InkSample[] {
  const ctx = art.getContext('2d')!, W = art.width, H = art.height;
  const d = ctx.getImageData(0, 0, W, H).data, hit: number[] = [];
  const stride = 3;
  for (let y = 0; y < H; y += stride) for (let x = 0; x < W; x += stride) if (d[(y * W + x) * 4 + 3] > 235) hit.push(y * W + x);
  const out: InkSample[] = [];
  if (!hit.length) return out;
  const scale = (art as HTMLCanvasElement & { __dpr?: number }).__dpr ?? 1;
  for (let i = 0; i < count; i++) {
    const p = hit[Math.floor(rng() * hit.length)];
    out.push({ x: (p % W) / scale, y: Math.floor(p / W) / scale, r: d[p * 4], g: d[p * 4 + 1], b: d[p * 4 + 2] });
  }
  return out;
}
