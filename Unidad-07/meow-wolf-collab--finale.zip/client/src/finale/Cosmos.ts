// The final world. Timeline: 1) the finished logo, alive  2) it shatters into particles carrying its exact colors
// 3) a layered world grows from what the players made, with the logo in the middle, and the mouse can play with it.
// Everything that appears is chosen by the artwork: its colors (particle species), its sticker types and where they
// sat (flowers -> vines and blooms, skulls -> embers, bolts -> lightning, eyes -> eyes), its ink positions (where life spawns).
import { LOGO } from '../../../shared/logo';
import { CELL_H, CELL_W } from '../../../shared/composition';
import { mulberry32, type ArtworkProfile, type Traits } from '../../../shared/world';
import { letterAtComp } from '../features/common/glyphHit';
import type { LetterID } from '../game/types';
import { WorldSim } from './WorldSim';
import { getMusicPulse } from '../game/audio';
import { sampleInk, type InkSample, type PlacedSticker, type Rect } from './artCanvas';
import { MAX_DEPTH, drawBloom, drawEye, glowSprite, growVine, makeBolt, makeLayers, type Bolt, type Eye, type Seg, type Vine } from './scenery';

const TAU = Math.PI * 2;
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));
const smooth = (a: number, b: number, x: number) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

// ---- noise (value noise, cheap) ----
const hash = (x: number, y: number) => { let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
const vnoise = (x: number, y: number) => {
  const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
  const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
  return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
};

// ---- color helpers ----
const rgbToHsl = (r: number, g: number, b: number) => {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  if (d === 0) return { h: 0, s: 0, l };
  const s = d / (1 - Math.abs(2 * l - 1)); let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return { h: (h * 60 + 360) % 360, s, l };
};
const hsl = (h: number, s: number, l: number) => `hsl(${Math.round((h + 360) % 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%)`;
/** Make a color glow-ready without changing its hue (greys/whites stay neutral). */
const glow = (r: number, g: number, b: number) => { const c = rgbToHsl(r, g, b); return c.s < 0.15 ? hsl(0, 0, clamp(c.l, 0.78, 0.95)) : hsl(c.h, Math.max(c.s, 0.8), clamp(c.l, 0.5, 0.66)); };

interface Group { css: string; rgb: [number, number, number]; share: number; accent: boolean; }
function clusterColors(samples: InkSample[], max: number) {
  const m = new Map<number, { r: number; g: number; b: number; n: number }>();
  for (const s of samples) {
    const k = ((s.r >> 5) << 6) | ((s.g >> 5) << 3) | (s.b >> 5), e = m.get(k) ?? { r: 0, g: 0, b: 0, n: 0 };
    e.r += s.r; e.g += s.g; e.b += s.b; e.n++; m.set(k, e);
  }
  const out: { rgb: [number, number, number]; n: number }[] = [];
  for (const e of [...m.values()].sort((a, b) => b.n - a.n)) {
    const rgb: [number, number, number] = [e.r / e.n, e.g / e.n, e.b / e.n];
    if (out.some(o => (o.rgb[0] - rgb[0]) ** 2 + (o.rgb[1] - rgb[1]) ** 2 + (o.rgb[2] - rgb[2]) ** 2 < 4800)) continue; // too similar
    out.push({ rgb, n: e.n }); if (out.length >= max) break;
  }
  return out;
}
const hexToRgb = (hex: string): [number, number, number] => { const n = parseInt(hex.replace('#', ''), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };

export interface CosmosOpts {
  seed: number; profile: ArtworkProfile; w: number; h: number; dpr: number; rect: Rect; art: HTMLCanvasElement;
  stickers: PlacedSticker[]; calm: boolean; light: boolean; startAt?: number; logo: 'white' | 'black';
}
interface Ember { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; css: string; rise: number; }
interface Ripple { x: number; y: number; r: number; vr: number; str: number; life: number; }
interface Vortex { x: number; y: number; s: number; life: number; }

export class Cosmos {
  t = 0; stage = 1; readonly events: string[] = [];
  private o: CosmosOpts; private W: number; private H: number; private dpr: number; private sc: number;
  private rng: () => number; private tr: Traits;
  private T: { burst: number; world: number; logo: number; free: number };
  // particles
  private N: number; private nActive: number; private px: Float32Array; private py: Float32Array; private x: Float32Array; private y: Float32Array;
  private vx: Float32Array; private vy: Float32Array; private age: Float32Array; private life: Float32Array; private grp: Uint8Array;
  private groups: Group[] = []; private ranges: [number, number][] = []; private buckets: InkSample[][] = [];
  private bursted = false;
  // canvases
  private trail: HTMLCanvasElement; private tctx: CanvasRenderingContext2D; private bloomA: HTMLCanvasElement; private bloomB: HTMLCanvasElement;
  private nebula: HTMLCanvasElement; private layers: HTMLCanvasElement[]; private vignette: HTMLCanvasElement;
  private sim: WorldSim; private phys: HTMLCanvasElement; private pctx: CanvasRenderingContext2D; private pimg: ImageData; private frame = 0;
  // world features
  private src: { x: number; y: number }[] = []; private vines: Vine[] = []; private embers: Ember[] = []; private fireSrc: { x: number; y: number }[] = [];
  private boltSrc: { x: number; y: number }[] = []; private bolts: Bolt[] = []; private eyes: Eye[] = []; private ripples: Ripple[] = []; private vortices: Vortex[] = [];
  private nextBolt = 3; private flash = 0;
  private mus = { energy: 0, bass: 0, beat: 0 }; private lastBeatRipple = -9; // the music's pulse (stays 0 in reduced-motion/calm mode)
  // logo + interaction
  private logoRect: Rect; private mask = new Float32Array(0); private mw = 0; private mh = 0; private logoMode: 'white' | 'black';
  private hover: Record<string, number> = {}; private pulse: Record<string, number> = {};
  private ptr = { x: -9999, y: -9999, has: false, down: false, sx: 0, sy: 0, speed: 0, lx: 0, ly: 0, spawnD: 0 };
  private par = { x: 0, y: 0 }; private slow = 0; private fpsAvg = 1 / 60;

  constructor(o: CosmosOpts) {
    this.o = o; this.W = o.w; this.H = o.h; this.dpr = o.dpr; this.sc = Math.min(o.w, o.h) / 900;
    this.rng = mulberry32(o.seed ^ 0x9e3779b9); this.tr = o.profile.traits; this.logoMode = o.logo;
    const calm = o.calm; this.T = calm ? { burst: 1.2, world: 1.6, logo: 3, free: 4.5 } : { burst: 2.8, world: 3.6, logo: 6.4, free: 9 };
    this.N = calm ? 1600 : o.light ? 2600 : 5200; this.nActive = this.N;
    const N = this.N; this.px = new Float32Array(N); this.py = new Float32Array(N); this.x = new Float32Array(N); this.y = new Float32Array(N);
    this.vx = new Float32Array(N); this.vy = new Float32Array(N); this.age = new Float32Array(N); this.life = new Float32Array(N); this.grp = new Uint8Array(N);

    const mk = (w: number, h: number) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };
    this.trail = mk(this.W * this.dpr, this.H * this.dpr); this.tctx = this.trail.getContext('2d')!; this.tctx.scale(this.dpr, this.dpr);
    this.bloomA = mk(this.W / 7, this.H / 7); this.bloomB = mk(this.W / 22, this.H / 22);
    this.logoRect = this.fit(0.56);

    this.buildGroups(); this.assignParticles();
    const rims = this.groups.filter(g => !g.css.includes(' 0%')).map(g => g.css); if (!rims.length) rims.push('#ff2d9b');
    this.layers = makeLayers(this.W, this.H, this.dpr, rims, this.tr, this.rng);
    this.nebula = this.makeNebula(rims); this.vignette = this.makeVignette();

    const sw = o.light || calm ? 200 : 300, sh = clamp(Math.round((sw * this.H) / this.W), 100, 300);
    this.sim = new WorldSim({ seed: o.seed, profile: o.profile, width: sw, height: sh, agents: calm ? 1200 : o.light ? 1500 : 3200, calm,
      compRect: { x: o.rect.x / this.W, y: o.rect.y / this.H, w: o.rect.w / this.W, h: o.rect.h / this.H } });
    this.phys = mk(sw, sh); this.pctx = this.phys.getContext('2d')!; this.pimg = this.pctx.createImageData(sw, sh);

    this.buildMask(); this.buildFeatures();
    for (const id of Object.keys(LOGO)) { this.hover[id] = 0; this.pulse[id] = 0; }
    if (o.startAt && o.startAt > this.T.free) { this.t = o.startAt; this.bursted = true; this.scatter(); this.stage = 3; }
  }

  // ---------- setup ----------
  private fit(fill: number): Rect { const w = Math.min(this.W * fill, this.H * fill * 2), h = w / 2; return { x: (this.W - w) / 2, y: (this.H - h) / 2, w, h }; }
  /** Where something that sat at (x,y) in the artwork lives in the full-screen world (same arrangement, spread out). */
  private proj(x: number, y: number) {
    const nx = (x - this.o.rect.x) / this.o.rect.w, ny = (y - this.o.rect.y) / this.o.rect.h;
    return { x: this.W * (0.06 + 0.88 * clamp(nx, 0, 1)), y: this.H * (0.1 + 0.8 * clamp(ny, 0, 1)) };
  }
  /** Nudge a point out from under the logo so things grown from the middle of the artwork stay visible. */
  private vinePalette() { const c = ['#ff2d9b', ...this.groups.map(g => g.css)].filter(x => !x.includes(' 0%')); return c.length ? c : ['#ff2d9b']; }
  private clear(p: { x: number; y: number }, pad = 1.12) {
    const lr = this.logoRect, cx = lr.x + lr.w / 2, cy = lr.y + lr.h / 2, dx = (p.x - cx) / (lr.w / 2), dy = (p.y - cy) / (lr.h / 2);
    if (Math.abs(dx) < pad && Math.abs(dy) < pad * 1.15) { const k = pad / Math.max(Math.abs(dx), Math.abs(dy), 0.05); return { x: cx + dx * k * (lr.w / 2), y: cy + dy * k * (lr.h / 2) * 1.15 }; }
    return p;
  }

  private buildGroups() {
    const samples = sampleInk(this.o.art, 3000, this.rng);
    let cl = clusterColors(samples, 7);
    if (!cl.length) cl = this.o.profile.palette.map(p => ({ rgb: hexToRgb(p.color), n: p.weight }));
    const tot = cl.reduce((n, c) => n + c.n, 0);
    cl.forEach(c => this.groups.push({ css: glow(...c.rgb), rgb: c.rgb, share: (c.n / tot) * 0.82, accent: false }));
    // a few accent hues next to the artwork's main color keep the world from going flat
    const lead = rgbToHsl(...cl[0].rgb);
    [lead.h + 38, lead.h - 38, lead.h + 180].slice(0, 3).forEach((h, i) => this.groups.push({ css: hsl(h, 0.9, 0.6), rgb: [0, 0, 0], share: i === 2 ? 0.03 : 0.075, accent: true }));
    this.buckets = this.groups.map(() => []);
    for (const s of samples) {
      let best = 0, bd = Infinity;
      this.groups.forEach((g, i) => { if (g.accent) return; const d = (g.rgb[0] - s.r) ** 2 + (g.rgb[1] - s.g) ** 2 + (g.rgb[2] - s.b) ** 2; if (d < bd) { bd = d; best = i; } });
      this.buckets[best].push(s);
    }
  }
  private assignParticles() {
    let at = 0; const tot = this.groups.reduce((n, g) => n + g.share, 0);
    this.groups.forEach((g, gi) => {
      const n = gi === this.groups.length - 1 ? this.N - at : Math.round((g.share / tot) * this.N);
      this.ranges.push([at, at + n]); for (let i = at; i < at + n; i++) this.grp[i] = gi; at += n;
    });
  }
  private makeNebula(rims: string[]) {
    const c = document.createElement('canvas'); c.width = Math.round(this.W * 1.2 * this.dpr * 0.5); c.height = Math.round(this.H * 1.2 * this.dpr * 0.5);
    const x = c.getContext('2d')!; x.scale(this.dpr * 0.5, this.dpr * 0.5);
    for (let i = 0; i < 9; i++) {
      const cx = this.rng() * this.W * 1.2, cy = this.rng() * this.H * 1.2, r = (0.25 + this.rng() * 0.3) * this.W, g = x.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, rims[i % rims.length]); g.addColorStop(1, 'rgba(0,0,0,0)'); x.globalAlpha = 0.17; x.fillStyle = g; x.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
    return c;
  }
  private makeVignette() {
    const c = document.createElement('canvas'); c.width = 256; c.height = 160; const x = c.getContext('2d')!;
    const g = x.createRadialGradient(128, 80, 40, 128, 80, 150); g.addColorStop(0, 'rgba(3,2,8,0)'); g.addColorStop(1, 'rgba(3,2,8,0.82)'); x.fillStyle = g; x.fillRect(0, 0, 256, 160); return c;
  }
  /** A blurred copy of the logo's shape; particles are pushed down its gradient so the river flows around the letters. */
  private buildMask() {
    const cell = 4, mw = Math.ceil(this.W / cell), mh = Math.ceil(this.H / cell);
    const c = document.createElement('canvas'); c.width = mw; c.height = mh; const x = c.getContext('2d')!; x.scale(1 / cell, 1 / cell);
    this.drawLogoShapes(x, this.logoRect, (ctx, p) => { ctx.fillStyle = '#fff'; ctx.fill(p); });
    const a = x.getImageData(0, 0, mw, mh).data; let m = new Float32Array(mw * mh); for (let i = 0; i < m.length; i++) m[i] = a[i * 4 + 3] / 255;
    for (let pass = 0; pass < 4; pass++) { const n = new Float32Array(m.length); for (let yy = 1; yy < mh - 1; yy++) for (let xx = 1; xx < mw - 1; xx++) { const k = yy * mw + xx; n[k] = (m[k] * 4 + m[k - 1] + m[k + 1] + m[k - mw] + m[k + mw]) / 8; } m = n; }
    this.mask = m; this.mw = mw; this.mh = mh;
  }
  private drawLogoShapes(ctx: CanvasRenderingContext2D, r: Rect, fn: (ctx: CanvasRenderingContext2D, p: Path2D, id: LetterID) => void) {
    const k = (CELL_W * r.w) / 800;
    for (const id of Object.keys(LOGO) as LetterID[]) {
      const g = LOGO[id]; ctx.save(); ctx.translate(r.x + (g.cx - CELL_W / 2) * r.w, r.y + (g.cy - CELL_H / 2) * r.h); ctx.scale(k, k); fn(ctx, new Path2D(g.d), id); ctx.restore();
    }
  }

  private buildFeatures() {
    const o = this.o, t = this.tr, r = this.rng, sc = this.sc;
    const proj = (s: { x: number; y: number }) => this.proj(s.x, s.y);
    this.src = [...o.stickers, ...o.profile.ink.filter((_, i) => i % 6 === 0).map(p => ({ x: o.rect.x + p.x * o.rect.w, y: o.rect.y + p.y * o.rect.h }))].map(proj);
    if (!this.src.length) this.src = [{ x: this.W / 2, y: this.H / 2 }];
    const of = (kind: string) => o.stickers.filter(s => s.kind === kind).map(proj);
    const bloomCols = this.vinePalette();
    // growth: every flower sticker sprouts vines from where it sat; green-leaning art adds more from its ink
    const flowers = of('flower'), extra = Math.round(t.growth * 6) + (flowers.length ? 0 : t.growth > 0.2 ? 2 : 0);
    flowers.forEach(p => { const q = this.clear(p); for (let i = 0; i < 3; i++) this.vines.push(growVine(q.x, q.y, r() * TAU, sc, r, bloomCols, this.T.world + r() * 1.6, 250 + r() * 120)); });
    for (let i = 0; i < extra; i++) { const p = this.clear(this.src[Math.floor(r() * this.src.length)]); this.vines.push(growVine(p.x, p.y, r() * TAU, sc, r, bloomCols, this.T.world + r() * 2, 220 + r() * 120)); }
    // fire: skulls are emitters; fiery art adds more
    this.fireSrc = of('skull').map(p => this.clear(p, 1.05));
    for (let i = 0, n = Math.round(t.fire * 3); i < n; i++) this.fireSrc.push(this.clear(this.src[Math.floor(r() * this.src.length)], 1.05));
    // electric: bolts strike from bolt stickers
    this.boltSrc = of('bolt').map(p => this.clear(p, 1.05));
    // watching: every eye sticker becomes a living eye; watchful art adds more around the edges
    of('eye').forEach((p, i) => this.addEye(this.clear(p, 1.2), this.T.world + 0.4 * i, 1.2));
    for (let i = 0, n = Math.round(t.watching * 5); i < n; i++) this.addEye(this.clear({ x: this.W * (0.08 + r() * 0.84), y: this.H * (0.12 + r() * 0.76) }, 1.25), this.T.world + 0.8 + i * 0.5, 1);
  }
  private addEye(p: { x: number; y: number }, born: number, size: number) {
    if (this.eyes.length >= 26) this.eyes.shift();
    this.eyes.push({ x: p.x, y: p.y, r: (20 + this.rng() * 26) * this.sc * size, iris: this.groups[Math.floor(this.rng() * this.groups.length)].css, phase: this.rng() * 5, born });
  }

  // ---------- timeline events ----------
  private respawn(i: number) {
    const r = Math.random;
    if (r() < 0.5) { const s = this.src[Math.floor(r() * this.src.length)]; this.x[i] = s.x + (r() - 0.5) * 50 * this.sc; this.y[i] = s.y + (r() - 0.5) * 50 * this.sc; }
    else { this.x[i] = r() * this.W; this.y[i] = r() * this.H; }
    this.px[i] = this.x[i]; this.py[i] = this.y[i]; this.vx[i] = this.vy[i] = 0; this.age[i] = 0; this.life[i] = 3 + r() * 7;
  }
  private scatter() { for (let i = 0; i < this.N; i++) { this.respawn(i); this.age[i] = Math.random() * this.life[i]; } }
  private burst() {
    this.bursted = true; const cx = this.o.rect.x + this.o.rect.w / 2, cy = this.o.rect.y + this.o.rect.h / 2, r = Math.random;
    for (let i = 0; i < this.N; i++) {
      const b = this.buckets[this.grp[i]], any = this.buckets.find(x => x.length) ?? [];
      const s = (b.length ? b : any)[Math.floor(r() * (b.length ? b.length : any.length))];
      const x = s ? s.x : cx, y = s ? s.y : cy, dx = x - cx, dy = y - cy, d = Math.hypot(dx, dy) || 1, sp = (140 + r() * 380) * this.sc;
      this.x[i] = this.px[i] = x; this.y[i] = this.py[i] = y; this.vx[i] = (dx / d) * sp + (r() - 0.5) * 90; this.vy[i] = (dy / d) * sp + (r() - 0.5) * 90;
      this.age[i] = 0; this.life[i] = 4 + r() * 8;
    }
    this.ripples.push({ x: cx, y: cy, r: 0, vr: 700 * this.sc, str: 700, life: 1.6 });
    if (!this.o.calm) this.flash = 0.5;
  }

  // ---------- input ----------
  setLogo(m: 'white' | 'black') { this.logoMode = m; }
  move(x: number, y: number) {
    const p = this.ptr, d = Math.hypot(x - p.lx, y - p.ly); p.x = x; p.y = y; p.has = true; p.speed = d; p.spawnD += d;
    if (this.stage < 3 && this.t < this.T.world) { p.lx = x; p.ly = y; return; }
    if (p.down && d > 0) {   // hold + drag paints a glowing ribbon that the world then carries away
      const g = this.groups[Math.floor(this.t * 2.2) % this.groups.length], c = this.tctx;
      c.save(); c.globalCompositeOperation = 'lighter'; c.strokeStyle = g.css; c.lineCap = 'round'; c.globalAlpha = 0.85; c.lineWidth = 7 * this.sc;
      c.beginPath(); c.moveTo(p.lx, p.ly); c.lineTo(x, y); c.stroke(); c.restore();
    }
    if (p.spawnD > 22) { p.spawnD = 0; this.sparkle(x, y, 2); }
    p.lx = x; p.ly = y;
  }
  private sparkle(x: number, y: number, n: number) {
    for (let i = 0; i < n && this.embers.length < 700; i++) {
      const a = Math.random() * TAU, sp = (30 + Math.random() * 90) * this.sc, g = this.groups[Math.floor(Math.random() * this.groups.length)];
      this.embers.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.9, max: 0.9, size: (10 + Math.random() * 14) * this.sc, css: g.css, rise: 0 });
    }
  }
  /** Typed easter eggs (see FinaleScreen): small, cheap surprises. */
  delight(word: 'meow' | 'awoo' | 'eyes') {
    if (this.t < this.T.world) return; const sc = this.sc, rng = Math.random;
    if (word === 'meow') { this.eyes.forEach((e, i) => window.setTimeout(() => { e.wink = 1; }, i * 90)); this.ripples.push({ x: this.W / 2, y: this.H / 2, r: 0, vr: 520 * sc, str: 500, life: 1.4 }); this.events.push('meow'); }
    else if (word === 'awoo') { for (let i = 0; i < 4; i++) this.bolts.push(makeBolt(this.W * (0.15 + 0.7 * rng()), 0, this.W * (0.15 + 0.7 * rng()), this.H * (0.5 + 0.4 * rng()), rng)); if (!this.o.calm) this.flash = 0.4; this.events.push('howl'); }
    else { for (let i = 0; i < 5; i++) this.addEye({ x: this.W * (0.1 + 0.8 * rng()), y: this.H * (0.12 + 0.76 * rng()) }, this.t + i * 0.2, 0.9); this.events.push('blip'); }
  }
  up() { this.ptr.down = false; }
  leave() { this.ptr.down = false; this.ptr.has = false; }
  down(x: number, y: number) {
    this.ptr.down = true; this.ptr.lx = x; this.ptr.ly = y; if (this.t < this.T.world) return;
    const sc = this.sc, rng = Math.random, tr = this.tr;
    const poked = this.eyes.find(e => Math.hypot(e.x - x, e.y - y) < e.r * 1.4);
    if (poked) { poked.wink = 1; this.events.push('blip'); for (let i = 0; i < 14; i++) this.ember(poked.x, poked.y, 0.8); return; } // easter egg: poke an eye and it startles
    this.ripples.push({ x, y, r: 0, vr: 520 * sc, str: 800, life: 1.1 });
    for (let k = 0; k < 90; k++) { const i = Math.floor(rng() * this.nActive), a = rng() * TAU, sp = (160 + rng() * 280) * sc; this.x[i] = this.px[i] = x; this.y[i] = this.py[i] = y; this.vx[i] = Math.cos(a) * sp; this.vy[i] = Math.sin(a) * sp; this.age[i] = 0; }
    const hit = letterAtComp((x - this.logoRect.x) / this.logoRect.w, (y - this.logoRect.y) / this.logoRect.h); if (hit) this.pulse[hit] = 1;
    // what grows here depends on what the players made
    const w: [string, number][] = [['growth', tr.growth + 0.12], ['fire', tr.fire + 0.12], ['electric', tr.electric + 0.12], ['watching', tr.watching + 0.12], ['flow', tr.flow + 0.12]];
    let pick = rng() * w.reduce((n, [, v]) => n + v, 0), kind = 'flow'; for (const [k, v] of w) { pick -= v; if (pick <= 0) { kind = k; break; } }
    if (kind === 'growth') {
      if (this.vines.length >= 18) this.vines.shift();
      this.vines.push(growVine(x, y, -Math.PI / 2 + (rng() - 0.5) * 2.4, sc, rng, this.vinePalette(), this.t, 200 + rng() * 100));
      this.sim.relocate(this.sim.speciesFor('growth'), (x / this.W) * this.sim.W, (y / this.H) * this.sim.H, 160); this.events.push('bloom');
    } else if (kind === 'fire') {
      for (let i = 0; i < 70; i++) this.ember(x, y, 1.6);
    } else if (kind === 'electric') {
      this.bolts.push(makeBolt(x + (rng() - 0.5) * 240 * sc, 0, x, y, rng)); if (!this.o.calm) this.flash = 0.35; this.events.push('zap');
    } else if (kind === 'watching') {
      this.addEye({ x, y }, this.t, 1);
    } else {
      this.vortices.push({ x, y, s: rng() < 0.5 ? 1 : -1, life: 7 });
    }
  }
  private ember(x: number, y: number, spread = 1) {
    if (this.embers.length >= 700) return;
    const r = Math.random, warm = ['#ff5e00', '#ff2a00', '#ffb300'], css = r() < 0.5 ? this.groups[Math.floor(r() * this.groups.length)].css : warm[Math.floor(r() * 3)], a = r() * TAU;
    this.embers.push({ x: x + (r() - 0.5) * 16, y, vx: Math.cos(a) * 70 * spread * this.sc, vy: (-90 - r() * 120) * this.sc, life: 1.3 + r() * 1.6, max: 2.6, size: (8 + r() * 16) * this.sc, css, rise: 40 });
  }

  // ---------- simulation ----------
  update(rawDt: number) {
    const dt = Math.min(0.05, rawDt), T = this.T, sc = this.sc; this.t += dt;
    this.fpsAvg += (dt - this.fpsAvg) * 0.03;
    if (this.fpsAvg > 0.034 && this.nActive > this.N * 0.35 && ++this.slow > 60) { this.nActive = Math.floor(this.nActive * 0.82); this.slow = 0; }   // keep it smooth on slow machines
    this.stage = this.t < T.burst ? 1 : this.t < T.logo ? 2 : 3;
    if (!this.bursted && this.t >= T.burst) this.burst();
    const w = smooth(T.world, T.free, this.t), tr = this.tr, t = this.t;
    this.par.x += ((this.ptr.has ? (this.ptr.x - this.W / 2) / this.W : 0) - this.par.x) * Math.min(1, dt * 2.5);
    this.par.y += ((this.ptr.has ? (this.ptr.y - this.H / 2) / this.H : 0) - this.par.y) * Math.min(1, dt * 2.5);
    this.flash = Math.max(0, this.flash - dt * 1.6);
    for (const e of this.eyes) if (e.wink) e.wink = Math.max(0, e.wink - dt * 1.4);
    if (!this.o.calm) { // the world breathes with the music: bloom swells on the low end, the logo glows on beats, a gentle ring on strong ones
      const mp = getMusicPulse(); this.mus.energy = mp.energy; this.mus.bass = mp.bass; this.mus.beat = mp.beat;
      if (mp.hit && this.stage === 3 && mp.bass > 0.45 && this.t - this.lastBeatRipple > 2.4) {
        this.lastBeatRipple = this.t; this.ripples.push({ x: this.W / 2, y: this.H / 2, r: 0, vr: 380 * sc, str: 240, life: 1.2 });
      }
    }
    const hovered = this.ptr.has && this.stage === 3 ? letterAtComp((this.ptr.x - this.logoRect.x) / this.logoRect.w, (this.ptr.y - this.logoRect.y) / this.logoRect.h) : null;
    for (const id of Object.keys(this.hover)) { this.hover[id] += ((hovered === id ? 1 : 0) - this.hover[id]) * Math.min(1, dt * 9); this.pulse[id] = Math.max(0, this.pulse[id] - dt * 1.6); }

    // physarum veins (the soft living network behind everything)
    this.sim.step(1 / 40); if ((this.frame++ & 1) === 0) { this.sim.paint(this.pimg.data); this.pctx.putImageData(this.pimg, 0, 0); }
    for (const e of this.sim.events.splice(0)) this.events.push(e);

    // fade the trails, then move particles
    const c = this.tctx; c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1; c.fillStyle = `rgba(3,2,8,${1 - Math.pow(0.925, dt * 60)})`; c.fillRect(0, 0, this.W, this.H);
    if (this.bursted) this.moveParticles(dt, w);
    this.updateFeatures(dt, w);
    void sc; void tr; void t;
  }

  private moveParticles(dt: number, w: number) {
    const { x, y, px, py, vx, vy, age, life, tr, sc, W, H, t } = this, p = this.ptr, mw = this.mw, m = this.mask;
    const fs = (0.0016 + 0.0016 * tr.electric + 0.001 * tr.fire) / Math.max(sc, 0.5), base = (46 + 60 * tr.electric + 40 * tr.fire + 20 * tr.flow) * sc * (this.o.calm ? 0.6 : 1);
    const quant = tr.electric * 0.8, R = 190 * sc, relax = Math.min(1, dt * 1.4 + 0.02);
    for (let i = 0; i < this.nActive; i++) {
      px[i] = x[i]; py[i] = y[i];
      let X = x[i], Y = y[i], VX = vx[i], VY = vy[i];
      const n1 = vnoise(X * fs + t * 0.06, Y * fs - t * 0.045), n2 = vnoise(X * fs * 2.3 + 11 - t * 0.05, Y * fs * 2.3 + t * 0.04);
      let a = (n1 * 0.75 + n2 * 0.25) * TAU * 2.1;
      if (quant > 0.05) { const q = Math.round(a / (Math.PI / 4)) * (Math.PI / 4); a += (q - a) * quant; }
      const spd = base * (0.5 + n2 * 1.1);
      VX += (Math.cos(a) * spd - VX) * relax; VY += (Math.sin(a) * spd - VY - tr.fire * 14 * sc) * relax;
      if (p.has) {
        const dx = p.x - X, dy = p.y - Y, d2 = dx * dx + dy * dy;
        if (d2 < R * R) { const d = Math.sqrt(d2) + 1e-3, f = (1 - d / R) ** 2, sw = 620 + p.speed * 18, ga = p.down ? 1100 : 70; VX += ((-dy / d) * sw + (dx / d) * ga) * f * dt; VY += ((dx / d) * sw + (dy / d) * ga) * f * dt; }
      }
      for (const r of this.ripples) { const dx = X - r.x, dy = Y - r.y, d = Math.hypot(dx, dy) + 1e-3, e = Math.abs(d - r.r); if (e < 60 * sc) { const f = (1 - e / (60 * sc)) * r.str * (r.life > 0 ? 1 : 0); VX += (dx / d) * f * dt; VY += (dy / d) * f * dt; } }
      for (const v of this.vortices) { const dx = X - v.x, dy = Y - v.y, d = Math.hypot(dx, dy) + 1e-3, R2 = 280 * sc; if (d < R2) { const f = (1 - d / R2) ** 2 * 520 * v.s * Math.min(1, v.life); VX += (-dy / d) * f * dt; VY += (dx / d) * f * dt; } }
      if (m.length && this.t > this.T.logo - 1.5) {
        const mx = (X / 4) | 0, my = (Y / 4) | 0;
        if (mx > 1 && my > 1 && mx < mw - 2 && my < this.mh - 2) { const k = my * mw + mx, gx = m[k + 1] - m[k - 1], gy = m[k + mw] - m[k - mw], s = 3600 * (m[k] > 0.8 ? 1.6 : 1); VX -= gx * s * dt; VY -= gy * s * dt; }
      }
      X += VX * dt; Y += VY * dt; age[i] += dt;
      if (X < -20 || X > W + 20 || Y < -20 || Y > H + 20 || age[i] > life[i]) { x[i] = X; this.respawn(i); continue; }
      x[i] = X; y[i] = Y; vx[i] = VX; vy[i] = VY;
    }
    const c = this.tctx, alpha = 0.5 + 0.2 * w; c.globalCompositeOperation = 'lighter'; c.lineCap = 'round'; c.lineWidth = 1.2 + 0.5 * sc; c.globalAlpha = alpha;
    this.ranges.forEach(([a, b], gi) => {
      c.strokeStyle = this.groups[gi].css; c.beginPath();
      for (let i = a; i < Math.min(b, this.nActive); i++) { if (age[i] === 0) continue; c.moveTo(px[i], py[i]); c.lineTo(x[i], y[i]); }
      c.stroke();
    });
    c.globalAlpha = 1;
  }

  private updateFeatures(dt: number, w: number) {
    const { tr, sc } = this, rng = Math.random;
    for (const r of this.ripples) { r.r += r.vr * dt; r.life -= dt; r.str *= 0.985; } this.ripples = this.ripples.filter(r => r.life > 0);
    for (const v of this.vortices) v.life -= dt; this.vortices = this.vortices.filter(v => v.life > 0);
    if (w > 0.25) {
      for (const s of this.fireSrc) if (rng() < (6 + 26 * tr.fire) * dt) this.ember(s.x, s.y);
      if (tr.fire > 0.3 && rng() < tr.fire * 14 * dt) this.ember(rng() * this.W, this.H + 4, 0.6); // fiery art lights the ground
      this.nextBolt -= dt;
      if (this.nextBolt <= 0 && (tr.electric > 0.12 || this.boltSrc.length)) {
        this.nextBolt = (2.6 - 2 * tr.electric) * (0.6 + rng() * 0.9);
        const s = this.boltSrc.length ? this.boltSrc[Math.floor(rng() * this.boltSrc.length)] : { x: rng() * this.W, y: 0 };
        const near = this.ptr.has && Math.hypot(this.ptr.x - s.x, this.ptr.y - s.y) < 520 * sc, tx = near ? this.ptr.x : s.x + (rng() - 0.5) * 700 * sc, ty = near ? this.ptr.y : s.y + (rng() - 0.5) * 500 * sc;
        const b = makeBolt(s.x, s.y, tx, ty, rng); this.bolts.push(b); this.events.push('zap');
        for (let k = 0; k < 40; k++) { const i = Math.floor(rng() * this.nActive), q = b.pts[Math.floor(rng() * b.pts.length)]; this.x[i] = this.px[i] = q[0]; this.y[i] = this.py[i] = q[1]; this.age[i] = 0.01; this.vx[i] = (rng() - 0.5) * 160 * sc; this.vy[i] = (rng() - 0.5) * 160 * sc; }
        if (!this.o.calm && tr.electric > 0.4) this.flash = Math.max(this.flash, 0.18);
      }
    }
    for (const b of this.bolts) b.ttl -= dt; this.bolts = this.bolts.filter(b => b.ttl > 0);
    for (const e of this.embers) { e.life -= dt; e.x += e.vx * dt; e.y += e.vy * dt; e.vx += (rng() - 0.5) * 140 * dt * sc; e.vy -= e.rise * dt * sc; e.vx *= 0.985; e.vy *= 0.985; }
    this.embers = this.embers.filter(e => e.life > 0);
  }

  // ---------- drawing ----------
  render(ctx: CanvasRenderingContext2D) {
    const { W, H, t, T, tr, sc } = this, w = smooth(T.world, T.free, t), par = this.par;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#04020a'; ctx.fillRect(0, 0, W, H);
    const shift = (d: number) => [-par.x * W * d, -par.y * H * d * 0.6] as const;
    const stageFade = smooth(0, 1.6, t);
    { const [sx, sy] = shift(0.012); ctx.globalAlpha = (0.25 + 0.75 * w) * stageFade * 0.9; ctx.drawImage(this.nebula, -W * 0.1 + sx, -H * 0.1 + sy, W * 1.2, H * 1.2); }
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.48 * smooth(T.burst, T.world + 1.5, t); ctx.imageSmoothingEnabled = true; ctx.drawImage(this.phys, 0, 0, W, H);
    ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
    const layer = (i: number, d: number, a: number) => { if (a <= 0.01) return; const [sx, sy] = shift(d); ctx.globalAlpha = a; ctx.drawImage(this.layers[i], -W * 0.15 + sx, sy, W * 1.3, H); ctx.globalAlpha = 1; };
    layer(0, 0.02, w);
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.8; ctx.drawImage(this.trail, 0, 0, W, H); ctx.globalAlpha = 1;
    // bloom: blurry upscaled copies of the trails, added back on top
    const a = this.bloomA.getContext('2d')!, b = this.bloomB.getContext('2d')!;
    a.clearRect(0, 0, this.bloomA.width, this.bloomA.height); a.drawImage(this.trail, 0, 0, this.bloomA.width, this.bloomA.height);
    b.clearRect(0, 0, this.bloomB.width, this.bloomB.height); b.drawImage(this.bloomA, 0, 0, this.bloomB.width, this.bloomB.height);
    ctx.globalAlpha = 0.34 + 0.14 * this.mus.bass; ctx.drawImage(this.bloomA, 0, 0, W, H); ctx.globalAlpha = 0.38 + 0.14 * this.mus.bass; ctx.drawImage(this.bloomB, 0, 0, W, H);
    ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
    layer(1, 0.04, w);

    // life: vines + blooms, embers, lightning, eyes
    ctx.globalCompositeOperation = 'lighter';
    this.drawVines(ctx);
    for (const e of this.embers) { const k = clamp(e.life / e.max, 0, 1), s = e.size * (0.4 + k); ctx.globalAlpha = Math.min(1, k * 1.3); ctx.drawImage(glowSprite(e.css), e.x - s, e.y - s, s * 2, s * 2); }
    ctx.globalAlpha = 1;
    for (const bo of this.bolts) {
      const k = bo.ttl / bo.max, paths = [bo.pts, ...bo.branches], col = this.groups[0].css;
      for (const [lw, al, st] of [[9 * sc, 0.12, col], [4 * sc, 0.4, col], [1.6 * sc, 0.95, '#fff']] as const) {
        ctx.strokeStyle = st; ctx.lineWidth = lw; ctx.globalAlpha = al * k; ctx.lineJoin = 'round'; ctx.beginPath();
        for (const pts of paths) { ctx.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]); }
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    for (const e of this.eyes) { const open = smooth(0, 1.2, t - e.born) * (0.15 + 0.85 * w); if (open > 0.02) drawEye(ctx, e, t, this.ptr.has ? this.ptr.x : -9999, this.ptr.has ? this.ptr.y : -9999, open); }
    layer(2, 0.075, w);

    ctx.drawImage(this.vignette, 0, 0, W, H);
    { const la = smooth(T.logo - 0.6, T.logo + 1.5, t) * (this.logoMode === 'white' ? 0.42 : 0.12), lr = this.logoRect; // soft dark pool behind a white logo (bright pool for a black one)
      if (la > 0.01) { const g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, lr.w * 0.62), c = this.logoMode === 'white' ? '3,2,10' : '255,255,255'; g.addColorStop(0, `rgba(${c},${la})`); g.addColorStop(1, `rgba(${c},0)`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); } }
    this.drawLogo(ctx);
    // shockwave rings
    ctx.globalCompositeOperation = 'lighter';
    for (const r of this.ripples) { ctx.globalAlpha = clamp(r.life, 0, 1) * 0.5; ctx.strokeStyle = this.groups[0].css; ctx.lineWidth = 3 * sc; ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, TAU); ctx.stroke(); }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // stage 1/2: the real artwork, then it dissolves into the particles above
    const artA = 1 - smooth(T.burst, T.burst + 1.4, t);
    if (artA > 0.01) {
      const grow = 1 + 0.025 * smooth(T.burst - 0.4, T.burst + 1.4, t) + 0.008 * Math.sin(t * 2.2), cx = W / 2, cy = H / 2;
      ctx.save(); ctx.translate(cx, cy); ctx.scale(grow, grow); ctx.translate(-cx, -cy);
      ctx.globalAlpha = artA * stageFade; ctx.drawImage(this.o.art, 0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = artA * stageFade * (0.22 + 0.1 * Math.sin(t * 3)); ctx.drawImage(this.o.art, 0, 0, W, H);
      ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    }
    if (this.flash > 0.01) { ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = `rgba(255,255,255,${this.flash * 0.35})`; ctx.fillRect(0, 0, W, H); ctx.globalCompositeOperation = 'source-over'; }
    void tr;
  }

  private drawVines(ctx: CanvasRenderingContext2D) {
    const sc = this.sc, t = this.t, ease = (x: number) => 1 - Math.pow(1 - x, 2.2);
    for (const v of this.vines) {
      const u = clamp((t - v.born) / v.dur, 0, 1.3); if (u <= 0) continue;
      const p = (ease(Math.min(u, 1)) + Math.max(0, u - 1)) * 1.4;           // fast start, slow settle
      const root = v.segs[0]; ctx.save();
      if (root) { ctx.translate(root.x1, root.y1); ctx.rotate(Math.sin(t * 0.7 + v.born * 3) * 0.012 * smooth(1, 1.4, u)); ctx.translate(-root.x1, -root.y1); } // the whole vine sways gently once grown
      let tip: Seg | null = null;
      for (let d = 0; d <= MAX_DEPTH; d++) {
        const wd = (5.4 - d * 0.95) * sc; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        for (const [lw, al, st] of [[wd * 3.4, 0.16, v.col], [wd * 1.25, 0.95, v.col], [wd * 0.42, 0.5, '#ffffff']] as const) {   // glow, colored body, bright core
          ctx.strokeStyle = st; ctx.lineWidth = lw; ctx.globalAlpha = al; ctx.beginPath(); let any = false;
          for (const s of v.segs) if (s.d === d && s.t < p) { ctx.moveTo(s.x1, s.y1); ctx.lineTo(s.x2, s.y2); any = true; if (lw === wd * 3.4 && (!tip || s.t > tip.t)) tip = s; }
          if (any) ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
      if (tip && u < 1.05) { const k = 1 - smooth(0.85, 1.05, u), z = 22 * sc * (0.6 + 0.4 * k); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.9 * k; ctx.drawImage(glowSprite(v.col), tip.x2 - z, tip.y2 - z, z * 2, z * 2); ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1; } // the growing tip shines
      for (const b of v.blooms) {
        const o = clamp((p - b.t) * 4, 0, 1); if (o <= 0) continue;
        const open = 1 + 2.70158 * Math.pow(o - 1, 3) + 1.70158 * Math.pow(o - 1, 2);     // opens with a little overshoot
        const near = this.ptr.has ? clamp(1 - Math.hypot(this.ptr.x - b.x, this.ptr.y - b.y) / (140 * sc), 0, 1) : 0;
        drawBloom(ctx, b, open * (1 + 0.45 * near), t);
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawLogo(ctx: CanvasRenderingContext2D) {
    const T = this.T, a = smooth(T.logo - 0.6, T.logo + 1.2, this.t); if (a <= 0.01) return;
    const white = this.logoMode === 'white', lr = this.logoRect, cx = this.W / 2, cy = this.H / 2, s = 0.9 + 0.1 * a;
    ctx.save(); ctx.globalAlpha = a; ctx.translate(cx - this.par.x * this.W * 0.012, cy - this.par.y * this.H * 0.01); ctx.scale(s, s); ctx.translate(-cx, -cy);
    ctx.lineJoin = 'round';
    let i = 0;
    this.drawLogoShapes(ctx, lr, (c, path, id) => {
      const h = this.hover[id], pu = this.pulse[id], k = 1 + 0.04 * h + 0.07 * pu;
      // entrance: each letter flies in from its own direction, spinning, one after another (calm mode: a plain fade)
      const ei = smooth(this.T.logo - 0.9 + i * 0.16, this.T.logo + 1.3 + i * 0.16, this.t), inv = Math.pow(1 - ei, 2), la = a * Math.min(1, ei * 1.6), dir = i * 2.4 + 0.7, far = this.o.calm ? 0 : 560;
      c.translate(Math.cos(dir) * far * inv, Math.sin(dir) * far * inv);
      c.translate(400, 400); c.rotate(Math.sin(this.t * 1.1 + i * 1.7) * 0.0035 + pu * 0.03 * Math.sin(this.t * 30) + (this.o.calm ? 0 : (i % 2 ? 1 : -1) * 0.9 * inv)); c.scale(k, k); c.translate(-400, -400);
      const lc = LOGO[id].color, glowCol = this.groups[i % this.groups.length].css; i++;
      c.globalCompositeOperation = 'lighter'; c.globalAlpha = la * (0.1 + 0.25 * h + 0.3 * pu + 0.16 * this.mus.beat + 0.7 * inv * ei * 4 * (1 - ei)); c.strokeStyle = glowCol; c.lineWidth = 46; c.stroke(path);
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = la;
      // a contrasting rim keeps the letters readable on top of any pattern
      c.strokeStyle = white ? 'rgba(4,2,12,0.92)' : 'rgba(255,255,255,0.95)'; c.lineWidth = white ? 24 : 18; c.stroke(path);
      c.fillStyle = h > 0.02 || pu > 0.02 ? mix(white ? '#ffffff' : '#07040f', lc, Math.max(h * 0.85, pu)) : white ? '#ffffff' : '#07040f'; c.fill(path);
    });
    ctx.restore();
  }
}

/** Blend two #rrggbb colors. */
function mix(a: string, b: string, t: number) {
  const A = hexToRgb(a), B = hexToRgb(b);
  return `rgb(${Math.round(A[0] + (B[0] - A[0]) * t)},${Math.round(A[1] + (B[1] - A[1]) * t)},${Math.round(A[2] + (B[2] - A[2]) * t)})`;
}
